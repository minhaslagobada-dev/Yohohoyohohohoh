# Experimento V13: batalhas online 1v1

## Estado atual

**Pesquisa inicial; ainda não é uma batalha online jogável.** A pasta `servidor/` é uma cópia do conteúdo da R122, sem mudanças em seus arquivos originais. A implementação da fila 1v1, simulação compartilhada, movimentação, ataques, transporte de batalha, encerramento e resultados continua pendente.

Não substituir a R122 de produção por este experimento. Não iniciar simultaneamente duas instâncias na mesma porta. A configuração foi copiada da R122, incluindo referências a serviços existentes; não executar contra dados ou serviços reais sem planejamento e backups. Nenhum banco de jogadores de produção acompanha este pacote.

## Fontes e identificação

- R122 de origem: SHA-256 `ec86802e675724fd041e639ea557b9adb428e3bd396e0c54662a3831c1a1c808`.
- LIB V13/R101 analisada: `libg.so`, ARM64, SHA-256 `ccba455df76597e1d0ff081a07bf5e0537ad555229ad1166588d66d75ebff4ae`.
- Referência V26: `https://github.com/LekmaDev/BS-26`, commit `93bfd843a27d99abcf8aea71f53fffd5f88b266e`.
- Guia: `https://hacc.natesworks.com/guides/frida/online-battles/`.
- Método: tutorial do Jordi adaptado ao Ghidra, com análise estática dirigida. A V26 é referência de organização, não especificação de payload. Não foi usado IDA nem instrumentado/modificado o cliente.

## Evidências de protocolo

Endereços abaixo são relativos à imagem ELF. Nos dumps do Ghidra, somar `0x100000` (image base). Em `evidencias/` há assembly e decompilações; alguns dumps contêm avisos do decompilador e nomes **candidatos**, portanto inspecionar o assembly em conjunto com o pseudocódigo.

- `10555`: getter `0x3e0018`, vtable com ponteiro do objeto em `0x73c1f0`, `encode` em `0x287328` e `decode` em `0x31828c`. O corpo ByteStream tem **três VInts, um VInt de quantidade e uma sequência de entradas**. Cada entrada tem seis VInts e um booleano; o decoder nativo limita a quantidade a 30. O código experimental rejeita quantidades fora do intervalo, em vez de reproduzir o clamp nativo.
- A leitura de VInt da LIB está em `0x283258`. A vtable do ByteStream aponta o slot `+0xe0` para esse leitor e `+0xb8` para `readBoolean` (`0x3ca774`).
- O construtor de entrada `0x0f2d9c` recebe valores para `+0x04` e `+0x08`; funções do cliente criam uma entrada com valor `100` em `+0x08` e coordenadas em `+0x0c` e `+0x10`. O papel exato de cada campo e das ações ainda precisa ser confirmado. Outros IDs encontrados não devem ser rotulados sem análise adicional.
- `14103`: há duas vtables com o mesmo getter de ID. A variante cujo construtor `0x435ce0` é chamado pela fábrica tem vptr `0x72e508`, getter em `0x300038`, encoder `0x46292c` e decoder `0x4cb1f4`. O corpo contém uma referência de dados/SCID seguida de quatro VInts. O significado dos campos continua pendente. A cópia mantém o fluxo `OnPlay` original até que seja possível integrar sem regressões.
- `24109`: encoder `0x1d36d0` escreve quatro VInts e um bloco de bytes com comprimento; os dados internos ainda precisam ser validados em todas as condições.
- Seguindo o construtor `10555` e seus chamadores até a atualização da batalha, a rotina `0x20a7b8` é uma candidata forte a codificação de visão/objetos. Seus wrappers levam a `BitStream.writePositiveInt` em `0x3b90b0`, que escreve do bit menos significativo para o mais significativo. A rotina possui ramificações e dependências de mapa/estado; não se deve substituir seu payload por valores arbitrários da V26.
- A função de envio `0x4e64fc` tem um caminho para serialização de datagrama e outro para mensagens. O formato completo do envelope, sua autenticação e o caminho usado por este APK ainda não foram validados. Não foi criada uma porta UDP nem foi desativada criptografia.

O código existente em `ClientInputMessage.py` lê bits e usa `Helpers.game1`; não foi substituído ainda porque fazê-lo sem identificar os campos, ciclo de vida da partida e transporte seria uma mudança incompleta. O estado de posições e HP no `LogicCharacter.py` existente é estático e não constitui simulação online.

## Código de pesquisa e testes

`experimentos/codec_v13.py` contém decoders isolados, sem ligação ao servidor. Eles usam o leitor nativo existente da R122. Os nomes desconhecidos preservam offsets; não atribuem semântica a campos ainda não comprovados. Os testes usam vetores sintéticos para conferir a decodificação e limites, não são capturas reais nem demonstram funcionamento no APK.

Na raiz deste pacote:

```bash
cd servidor
PYTHONPATH="$PWD:$PWD/../experimentos" python3 -m unittest discover -s ../experimentos/tests -v
python3 -m unittest discover -s tests -v
```

## Próximas etapas

1. Relacionar os campos e IDs das entradas às ações usando as funções nativas de criação e consumo.
2. Identificar estrutura de objetos, posição, vida, projéteis e diferenças por jogador no decodificador/encoder da LIB; obter vetores verificáveis, sem copiar layouts V26.
3. Determinar transporte, envelope, autenticação e fallback esperados pelo cliente, preservando criptografia e validações.
4. Implementar partida compartilhada 1v1 e fila isolada, sincronização, cancelamento, desconexão, encerramento e resultados, integrando com sessões e ledger existentes.
5. Testar unitária e integradamente contra o protocolo e os fluxos R122. Só depois validar o jogo real com dois clientes no APK.
