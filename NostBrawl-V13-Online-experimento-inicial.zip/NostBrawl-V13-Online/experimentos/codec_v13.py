"""Codecs de pesquisa da LIB R101; não conectados ao servidor de jogo."""
from dataclasses import dataclass

from Utils.Reader import BSMessageReader


@dataclass(frozen=True)
class ClientInputEntry:
    field_00: int
    field_04: int
    action: int
    field_0c: int
    field_10: int
    field_14: int
    flag_18: bool


@dataclass(frozen=True)
class ClientInput:
    field_4c: int
    field_50: int
    field_54: int
    entries: tuple


@dataclass(frozen=True)
class PlayRequest:
    data_class: int
    data_instance: int
    field_58: int
    field_5c: int
    field_60: int
    field_64: int


def decode_client_input(payload):
    """Decodifica o corpo ByteStream 10555, não o envelope UDP."""
    reader = BSMessageReader(payload).enable_native_v13()
    first, second, third = (reader.read_Vint() for _ in range(3))
    count = reader.read_Vint()
    if not 0 <= count <= 30:
        raise ValueError("Quantidade de entradas ClientInput fora do intervalo 0..30")
    entries = []
    for _ in range(count):
        values = [reader.read_Vint() for _ in range(6)]
        entries.append(ClientInputEntry(*values, reader.read_boolean()))
    reader.ensure_end()
    return ClientInput(first, second, third, tuple(entries))


def decode_play_request(payload):
    """Decodifica a variante 14103 da vtable 0x72e508 na LIB R101."""
    reader = BSMessageReader(payload).enable_native_v13()
    data_class, data_instance = reader.readScId()
    fields = [reader.read_Vint() for _ in range(4)]
    reader.ensure_end()
    return PlayRequest(data_class, data_instance, *fields)
