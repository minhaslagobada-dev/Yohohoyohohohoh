import unittest

from codec_v13 import decode_client_input, decode_play_request


class ClientInputCodecTests(unittest.TestCase):
    def test_empty_packet(self):
        result = decode_client_input(bytes.fromhex("01 02 03 00"))
        self.assertEqual((result.field_4c, result.field_50, result.field_54), (1, 2, 3))
        self.assertEqual(result.entries, ())

    def test_multiple_entries_with_signed_vints_and_boolean_alignment(self):
        payload = bytes.fromhex(
            "01 02 03 02 "
            "09 01 a4 01 b5 30 4e 00 01 "
            "0a 01 a6 01 00 01 7f 00"
        )
        result = decode_client_input(payload)
        self.assertEqual(len(result.entries), 2)
        first, second = result.entries
        self.assertEqual(
            (first.field_00, first.field_04, first.action, first.field_0c,
             first.field_10, first.field_14, first.flag_18),
            (9, 1, 100, 3125, -50, 0, True),
        )
        self.assertEqual(
            (second.field_00, second.field_04, second.action, second.field_0c,
             second.field_10, second.field_14, second.flag_18),
            (10, 1, 102, 0, 1, -1, False),
        )

    def test_native_maximum_and_invalid_count(self):
        entry = bytes.fromhex("00 01 a4 01 00 00 00 00")
        self.assertEqual(len(decode_client_input(b"\x00\x00\x00\x1e" + entry * 30).entries), 30)
        for count in (b"\x1f", b"\x7f"):
            with self.subTest(count=count), self.assertRaises(ValueError):
                decode_client_input(b"\x00\x00\x00" + count)

    def test_truncated_entries_and_extra_bytes_are_rejected(self):
        full = bytes.fromhex("01 02 03 01 09 01 a4 01 b5 30 4e 00 01")
        for i in range(len(full)):
            with self.subTest(length=i), self.assertRaises(ValueError):
                decode_client_input(full[:i])
        with self.assertRaises(ValueError):
            decode_client_input(full + b"\x00")


class PlayRequestCodecTests(unittest.TestCase):
    def test_data_reference_followed_by_four_vints(self):
        result = decode_play_request(bytes.fromhex("0f 07 01 7f 03 04"))
        self.assertEqual(
            (result.data_class, result.data_instance, result.field_58,
             result.field_5c, result.field_60, result.field_64),
            (15, 7, 1, -1, 3, 4),
        )

    def test_null_data_reference(self):
        result = decode_play_request(bytes.fromhex("00 01 02 03 04"))
        self.assertEqual((result.data_class, result.data_instance), (0, -1))
        self.assertEqual((result.field_58, result.field_5c, result.field_60, result.field_64), (1, 2, 3, 4))

    def test_truncation_and_trailing_bytes(self):
        full = bytes.fromhex("0f 07 01 7f 03 04")
        for i in range(len(full)):
            with self.subTest(length=i), self.assertRaises(ValueError):
                decode_play_request(full[:i])
        with self.assertRaises(ValueError):
            decode_play_request(full + b"\x00")


if __name__ == "__main__":
    unittest.main()
