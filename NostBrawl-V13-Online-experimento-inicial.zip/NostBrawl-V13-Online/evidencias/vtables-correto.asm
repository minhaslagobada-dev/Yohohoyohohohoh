Endereços abaixo são relativos à LIB; adicionar 0x100000 para endereço Ghidra.

===== OnPlay ctor com vtable 0x72e508 =====
00435ce0  f30f1ef8  str      x19, [sp, #-0x20]!
00435ce4  fd7b01a9  stp      x29, x30, [sp, #0x10]
00435ce8  fd430091  add      x29, sp, #0x10
00435cec  e1031f2a  mov      w1, wzr
00435cf0  f30300aa  mov      x19, x0
00435cf4  4967fe97  bl       #0x3cfa18
00435cf8  290e00f0  adrp     x9, #0x5fc000
00435cfc  2061c23d  ldr      q0, [x9, #0x980]
00435d00  c81700b0  adrp     x8, #0x72e000
00435d04  08e11391  add      x8, x8, #0x4f8
00435d08  08410091  add      x8, x8, #0x10
00435d0c  680200f9  str      x8, [x19]
00435d10  7f2a00f9  str      xzr, [x19, #0x50]
00435d14  6082853c  stur     q0, [x19, #0x58]
00435d18  fd7b41a9  ldp      x29, x30, [sp, #0x10]
00435d1c  f30742f8  ldr      x19, [sp], #0x20
00435d20  c0035fd6  ret      

===== case da fabrica que chama o ctor =====
00474240  f30300aa  mov      x19, x0
00474244  66f3f397  bl       #0x170fdc
00474248  c2feff17  b        #0x473d50
0047424c  e00f1d32  mov      w0, #0x78
00474250  2e760594  bl       #0x5d1b08
00474254  f30300aa  mov      x19, x0
00474258  72580194  bl       #0x4ca420
0047425c  bdfeff17  b        #0x473d50
00474260  000d8052  mov      w0, #0x68
00474264  29760594  bl       #0x5d1b08
00474268  f30300aa  mov      x19, x0
0047426c  9d06ff97  bl       #0x435ce0
00474270  b8feff17  b        #0x473d50
00474274  000b8052  mov      w0, #0x58
00474278  24760594  bl       #0x5d1b08
0047427c  f30300aa  mov      x19, x0
00474280  83fbf197  bl       #0xf308c
00474284  b3feff17  b        #0x473d50
00474288  e0071b32  mov      w0, #0x60
0047428c  1f760594  bl       #0x5d1b08
00474290  f30300aa  mov      x19, x0

===== ClientInput: getter, ctor e factory case =====
003e0018  60278552  mov      w0, #0x293b
003e001c  c0035fd6  ret      

===== ClientInput: ctor =====
003a50ac  f30f1ef8  str      x19, [sp, #-0x20]!
003a50b0  fd7b01a9  stp      x29, x30, [sp, #0x10]
003a50b4  fd430091  add      x29, sp, #0x10
003a50b8  e1031f2a  mov      w1, wzr
003a50bc  f30300aa  mov      x19, x0
003a50c0  56aa0094  bl       #0x3cfa18
003a50c4  a81c00f0  adrp     x8, #0x73c000
003a50c8  08810791  add      x8, x8, #0x1e0
003a50cc  08410091  add      x8, x8, #0x10
003a50d0  e0031c32  mov      w0, #0x10
003a50d4  7f5600b9  str      wzr, [x19, #0x54]
003a50d8  680200f9  str      x8, [x19]
003a50dc  7fc204f8  stur     xzr, [x19, #0x4c]
003a50e0  8ab20894  bl       #0x5d1b08
003a50e4  1f7c00a9  stp      xzr, xzr, [x0]
003a50e8  602e00f9  str      x0, [x19, #0x58]
003a50ec  fd7b41a9  ldp      x29, x30, [sp, #0x10]
003a50f0  f30742f8  ldr      x19, [sp], #0x20
003a50f4  c0035fd6  ret      

===== ClientInput: factory case =====
00474e74  e0071b32  mov      w0, #0x60
00474e78  24730594  bl       #0x5d1b08
00474e7c  f30300aa  mov      x19, x0
00474e80  8bc0fc97  bl       #0x3a50ac
00474e84  b3fbff17  b        #0x473d50
