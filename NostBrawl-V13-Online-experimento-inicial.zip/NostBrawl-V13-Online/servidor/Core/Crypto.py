import hashlib
import hmac
import os

from Core import NaCl19
from Utils.Config import Config


DEFAULT_SERVER_PUBLIC_KEY = (
    "EB7C3639CA77E5BD6D5A7AF9FCFBF94AA9BBC5C5819CBBF2859AE60DE6CCD041"
)
DEFAULT_CLIENT_PRIVATE_KEY = (
    "BB14D6FD2B7C9823EAEDB4338CB7237F61E422D23C4977F74ADA052702C0C62D"
)


class CryptoError(Exception):
    pass


class Nonce:
    def __init__(self, nonce=None, clientKey=None, serverKey=None):
        if not clientKey:
            self._nonce = bytes(nonce) if nonce else os.urandom(24)
        else:
            digest = hashlib.blake2b(digest_size=24)
            if nonce:
                digest.update(bytes(nonce))
            digest.update(bytes(clientKey))
            digest.update(bytes(serverKey))
            self._nonce = digest.digest()

        if len(self._nonce) != 24:
            raise ValueError("A V13 nonce must contain exactly 24 bytes")

    def __bytes__(self):
        return self._nonce

    def __len__(self):
        return len(self._nonce)

    def increment(self):
        value = (int.from_bytes(self._nonce, "little") + 2) % (1 << 192)
        self._nonce = value.to_bytes(24, "little")


class Crypto:
    """V13 transport compatible with the modified TweetNaCl reference."""

    def __init__(self, settings=None):
        if settings is None:
            settings = Config.GetValue().get("Crypto", {})

        self.enabled = bool(settings.get("Enabled", True))
        self.decryptNonce = None
        self.encryptNonce = None
        self.public_key = None
        self.login_completed = False

        if not self.enabled:
            self.server_key = b""
            self.client_sk = b""
            self.client_pk = b""
            self.shared_key = b""
            self.shared_en = b""
            return

        self.server_key = bytes.fromhex(
            settings.get("ServerPublicKey", DEFAULT_SERVER_PUBLIC_KEY)
        )
        self.client_sk = bytes.fromhex(
            settings.get("ClientPrivateKey", DEFAULT_CLIENT_PRIVATE_KEY)
        )
        if len(self.server_key) != 32 or len(self.client_sk) != 32:
            raise ValueError("V13 public/private keys must contain 32 bytes")

        self.client_pk = NaCl19.scalarmult_base(self.client_sk)
        self.shared_key = NaCl19.box_beforenm(self.server_key, self.client_sk)
        self.encryptNonce = Nonce(os.urandom(24))
        self.shared_en = os.urandom(32)

    def decrypt(self, packet_id, payload):
        if not self.enabled or packet_id == 10100:
            return payload

        try:
            if packet_id == 10101:
                                                                           
                if len(payload) < 96:
                    raise CryptoError("LoginMessage is too short for V13 crypto")

                self.public_key = payload[:32]
                if not hmac.compare_digest(self.public_key, self.client_pk):
                    raise CryptoError(
                        "The client public key does not match the configured V13 patch"
                    )

                nonce = Nonce(
                    clientKey=self.client_pk,
                    serverKey=self.server_key,
                )
                decrypted = NaCl19.secretbox_open(
                    payload[32:], bytes(nonce), self.shared_key
                )
                if len(decrypted) < 48:
                    raise CryptoError("Decrypted LoginMessage has no session header")

                self.session_key = decrypted[:24]
                self.decryptNonce = Nonce(decrypted[24:48])
                return decrypted[48:]

            if self.decryptNonce is None:
                return payload

            self.decryptNonce.increment()
            return NaCl19.secretbox_open(
                payload, bytes(self.decryptNonce), self.shared_en
            )
        except NaCl19.VerificationError as error:
            raise CryptoError(f"Could not decrypt packet {packet_id}") from error

    def encrypt(self, packet_id, payload):
        if not self.enabled or packet_id in (20100, 20103):
            return payload

        if packet_id == 20104:
            if self.decryptNonce is None:
                raise CryptoError("LoginOk cannot be sent before LoginMessage")

            nonce = Nonce(
                self.decryptNonce,
                clientKey=self.client_pk,
                serverKey=self.server_key,
            )
            session_payload = bytes(self.encryptNonce) + self.shared_en + payload
            encrypted = NaCl19.secretbox(
                session_payload, bytes(nonce), self.shared_key
            )
            self.login_completed = True
            return encrypted

        if self.decryptNonce is None or not self.login_completed:
            raise CryptoError(
                f"Packet {packet_id} cannot use the session before LoginOk"
            )

        self.encryptNonce.increment()
        return NaCl19.secretbox(payload, bytes(self.encryptNonce), self.shared_en)
