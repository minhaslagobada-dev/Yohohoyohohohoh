# NostBrawl R122 — correção de presença

Data: 2026-11-05

## Causa raiz

A LIB R101 ARM64 de referência tem SHA-256 `ccba455df76597e1d0ff081a07bf5e0537ad555229ad1166588d66d75ebff4ae`. A análise seguiu o tutorial do Jordi e foi confirmada com Ghidra direcionado, sem análise global e sem layouts de outras versões.

`PlayerStatusMessage` (`14366`) contém somente um VInt assinado V13 no campo `+0x4c`. O decode nativo em `0x2e692c` chama o leitor em `0x283258`; o encode em `0x387f20` chama o escritor em `0x49d378`.

A R121 usava `read_Vint()` sem ativar o modo nativo V13 e acrescentou um limite `0–6` inexistente no decode da LIB. Além da incompatibilidade do VInt para valores negativos, esse limite rejeitava estados legítimos e fechava toda a conexão como `Malformed packet`.

A rotina nativa de estado em `0x1eef08` produz `-1, 1, 2, 3, 4, 5, 7, 8, 10 e 11`. O atualizador em `0x3a6b20` passa esse retorno diretamente ao construtor de `14366` em `0x10e35c`. Por isso, login, New Event, telas de evento e transições de partida podiam derrubar a mesma conexão.

## Correção

- `PlayerStatusMessage` ativa o decoder V13 já existente em `Utils/Reader.py` antes de ler o campo.
- A validação permanece ativa, mas usa exatamente os estados emitidos pela rotina remetente da R101.
- Payload truncado, dados residuais e estados fora desse conjunto continuam rejeitados.
- O valor `0` continua sendo usado internamente pelo serviço ao detectar desconexão; não é tratado como um estado emitido pelo remetente nativo de `14366`.
- Nenhuma exceção foi escondida e nenhuma proteção de sessão, autenticação ou criptografia foi removida.

## Verificação

- 350 testes automatizados aprovados na staging.
- Fixtures com os bytes V13 reais dos dez estados nativos, incluindo `-1` codificado como `0x7f`.
- Testes de rejeição para estados não emitidos, payload vazio, VInt truncado e bytes residuais.
- Testes TCP de login, New Event, segundo login, presença de batalha, resultado e keepalive sem desconexão.
- Cinco cenários de sala, resultado e retorno de batalha com transições nativas de presença.
- Integração de amigos e clubes preservada; offline continua sendo verificado pela remoção da conexão registrada.

APK, LIB, SCID remoto e os demais sistemas não foram alterados. O aceite visual e de gameplay final no APK permanece com o usuário.
