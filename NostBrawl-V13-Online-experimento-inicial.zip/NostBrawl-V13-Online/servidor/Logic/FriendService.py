import json
import time

from Database.DatabaseManager import DataBase
from Logic.PresenceService import PresenceService


class FriendError(ValueError):
    pass


class FriendService:
    FRIEND = 4
    OUTGOING = 2
    INCOMING = 3
    SUGGESTION = 1

    @staticmethod
    def _now():
        return int(time.time())

    @staticmethod
    def _account_id(player):
        low_id = int(getattr(player, "low_id", 0) or 0)
        if low_id <= 0:
            raise FriendError("Conta inválida")
        return low_id

    @classmethod
    def _migrate_legacy(cls, connection, player):
        low_id = cls._account_id(player)
        legacy = getattr(player, "Friends", {})
        if not isinstance(legacy, dict) or not legacy:
            return
        targets = set()
        for value in legacy.values():
            if isinstance(value, str):
                try:
                    value = json.loads(value)
                except ValueError:
                    continue
            if isinstance(value, dict):
                value = value.get("lowID", value.get("low_id"))
            try:
                target = int(value)
            except (TypeError, ValueError):
                continue
            if target > 0 and target != low_id:
                targets.add(target)
        now = cls._now()
        for target in targets:
            exists = connection.execute(
                "SELECT 1 FROM players WHERE lowID = ?", (target,)
            ).fetchone()
            if exists is None:
                continue
            for owner, friend in ((low_id, target), (target, low_id)):
                connection.execute(
                    "INSERT OR IGNORE INTO friend_relations(owner_id, friend_id, state, "
                    "created_at, updated_at) VALUES(?, ?, 4, ?, ?)",
                    (owner, friend, now, now),
                )
        DataBase._write_state(connection, low_id, "Friends", {})
        player.Friends = {}

    @staticmethod
    def _relation(connection, owner, friend):
        row = connection.execute(
            "SELECT state, origin FROM friend_relations "
            "WHERE owner_id = ? AND friend_id = ?",
            (owner, friend),
        ).fetchone()
        return None if row is None else (int(row[0]), int(row[1]))

    @staticmethod
    def _state(connection, owner, friend):
        relation = FriendService._relation(connection, owner, friend)
        return None if relation is None else relation[0]

    @staticmethod
    def _set_state(connection, owner, friend, state, now, origin=None):
        if origin is None:
            connection.execute(
                "INSERT INTO friend_relations(owner_id, friend_id, state, created_at, updated_at) "
                "VALUES(?, ?, ?, ?, ?) ON CONFLICT(owner_id, friend_id) DO UPDATE SET "
                "state = excluded.state, updated_at = excluded.updated_at",
                (owner, friend, state, now, now),
            )
            return
        connection.execute(
            "INSERT INTO friend_relations(owner_id, friend_id, state, origin, created_at, updated_at) "
            "VALUES(?, ?, ?, ?, ?, ?) ON CONFLICT(owner_id, friend_id) DO UPDATE SET "
            "state = excluded.state, origin = excluded.origin, updated_at = excluded.updated_at",
            (owner, friend, state, int(origin), now, now),
        )

    @classmethod
    def _entry(cls, connection, owner, friend, state=None, origin=None):
        row = connection.execute(
            "SELECT p.lowID, p.name, p.trophies, p.profileIcon, p.clubID, p.online, "
            "c.id, c.name FROM players p LEFT JOIN clubs c ON c.id = p.clubID "
            "WHERE p.lowID = ?", (friend,)
        ).fetchone()
        if row is None:
            return None
        relation = cls._relation(connection, owner, friend)
        if state is None:
            state = 0 if relation is None else relation[0]
        if origin is None:
            origin = 0 if relation is None else relation[1]
        progression = DataBase._read_state(
            connection, friend, "progression"
        )
        club = None
        if row[6] is not None:
            club = {"id": int(row[6]), "name": str(row[7] or "")}
        return {
            "high_id": 0,
            "low_id": int(row[0]),
            "name": str(row[1] or ""),
            "facebook_id": str(progression.get("facebookID", "") or "") if progression.get("isFBLinked") else "",
            "game_center_id": str(progression.get("gameCenterID", "") or ""),
            "state": int(state),
            "origin": int(origin),
            "status": PresenceService.status(friend, row[5]),
            "trophies": int(row[2] or 0),
            "profile_icon": 28000000 + int(row[3] or 0),
            "club": club,
        }

    @classmethod
    def _friends(cls, connection, owner):
        rows = connection.execute(
            "SELECT friend_id, state FROM friend_relations WHERE owner_id = ? "
            "ORDER BY updated_at DESC, friend_id", (owner,)
        ).fetchall()
        entries = []
        for friend_id, state in rows:
            entry = cls._entry(connection, owner, friend_id, state)
            if entry is not None:
                entries.append(entry)
        return entries

    @classmethod
    def add(cls, player, friend_id, source=0):
        owner = cls._account_id(player)
        friend_id = int(friend_id)
        source = int(source)
        if not 0 <= source <= 4:
            raise FriendError("Origem de amizade inválida")
        if owner == friend_id:
            raise FriendError("Não é possível adicionar a própria conta")
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            cls._migrate_legacy(connection, player)
            if cls._entry(connection, owner, friend_id) is None:
                raise FriendError("Conta de amizade inexistente")
            state = cls._state(connection, owner, friend_id)
            reverse = cls._state(connection, friend_id, owner)
            now = cls._now()
            if state == cls.FRIEND or reverse == cls.FRIEND:
                cls._set_state(connection, owner, friend_id, cls.FRIEND, now)
                cls._set_state(connection, friend_id, owner, cls.FRIEND, now)
                new_state = cls.FRIEND
            elif state == cls.INCOMING or reverse == cls.OUTGOING:
                cls._set_state(connection, owner, friend_id, cls.FRIEND, now)
                cls._set_state(connection, friend_id, owner, cls.FRIEND, now)
                new_state = cls.FRIEND
            elif state == cls.OUTGOING or reverse == cls.INCOMING:
                cls._set_state(connection, owner, friend_id, cls.OUTGOING, now)
                cls._set_state(connection, friend_id, owner, cls.INCOMING, now)
                new_state = cls.OUTGOING
            else:
                cls._set_state(
                    connection, owner, friend_id, cls.OUTGOING, now, source
                )
                cls._set_state(
                    connection, friend_id, owner, cls.INCOMING, now, source
                )
                new_state = cls.OUTGOING
            reverse_state = cls._state(connection, friend_id, owner)
            entry = cls._entry(connection, owner, friend_id, new_state)
            reverse_entry = cls._entry(connection, friend_id, owner, reverse_state)
        return {
            "state": new_state,
            "accepted": new_state == cls.FRIEND,
            "entry": entry,
            "reverse_entry": reverse_entry,
            "friend_id": friend_id,
        }

    @classmethod
    def accept(cls, player, friend_id):
        owner = cls._account_id(player)
        friend_id = int(friend_id)
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            cls._migrate_legacy(connection, player)
            state = cls._state(connection, owner, friend_id)
            now = cls._now()
            if state == cls.FRIEND:
                cls._set_state(connection, owner, friend_id, cls.FRIEND, now)
                cls._set_state(connection, friend_id, owner, cls.FRIEND, now)
            elif state == cls.INCOMING:
                cls._set_state(connection, owner, friend_id, cls.FRIEND, now)
                cls._set_state(connection, friend_id, owner, cls.FRIEND, now)
            else:
                raise FriendError("Pedido de amizade recebido inexistente")
            entry = cls._entry(connection, owner, friend_id, cls.FRIEND)
            reverse_entry = cls._entry(connection, friend_id, owner, cls.FRIEND)
        return {"state": cls.FRIEND, "accepted": True, "entry": entry, "reverse_entry": reverse_entry, "friend_id": friend_id}

    @classmethod
    def remove(cls, player, friend_id):
        owner = cls._account_id(player)
        friend_id = int(friend_id)
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            cls._migrate_legacy(connection, player)
            if (
                cls._state(connection, owner, friend_id) is None
                and cls._state(connection, friend_id, owner) is None
            ):
                raise FriendError("Relação de amizade inexistente")
            entry = cls._entry(connection, owner, friend_id)
            reverse_entry = cls._entry(connection, friend_id, owner)
            if entry is None or reverse_entry is None:
                raise FriendError("Conta de amizade inexistente")
            connection.execute(
                "DELETE FROM friend_relations WHERE (owner_id = ? AND friend_id = ?) "
                "OR (owner_id = ? AND friend_id = ?)",
                (owner, friend_id, friend_id, owner),
            )
            entries = cls._friends(connection, owner)
            reverse_entries = cls._friends(connection, friend_id)
        return {
            "entry": entry,
            "reverse_entry": reverse_entry,
            "entries": entries,
            "reverse_entries": reverse_entries,
            "friend_id": friend_id,
            "removed": True,
        }

    @classmethod
    def friends(cls, player):
        owner = cls._account_id(player)
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            cls._migrate_legacy(connection, player)
            return cls._friends(connection, owner)

    @classmethod
    def push_presence(cls, player):
        owner = cls._account_id(player)
        with DataBase._connection() as connection:
            rows = connection.execute(
                "SELECT owner_id FROM friend_relations WHERE friend_id = ?",
                (owner,),
            ).fetchall()
            deliveries = []
            for row in rows:
                entry = cls._entry(connection, row[0], owner)
                if entry is not None:
                    deliveries.append((int(row[0]), entry))
        from Packets.Messages.Server.Friend.FriendListUpdateMessage import FriendListUpdateMessage

        delivered = 0
        for recipient, entry in deliveries:
            if FriendListUpdateMessage(None, player, entry).sendWithLowID(recipient):
                delivered += 1
        return delivered

    @classmethod
    def suggestions(cls, player, limit=20):
        owner = cls._account_id(player)
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            cls._migrate_legacy(connection, player)
            rows = connection.execute(
                "SELECT lowID FROM players p WHERE p.lowID <> ? AND NOT EXISTS("
                "SELECT 1 FROM friend_relations r WHERE "
                "(r.owner_id = ? AND r.friend_id = p.lowID) OR "
                "(r.owner_id = p.lowID AND r.friend_id = ?)"
                ") ORDER BY p.online DESC, p.trophies DESC, p.lowID LIMIT ?",
                (owner, owner, owner, min(100, max(1, int(limit)))),
            ).fetchall()
            return [cls._entry(connection, owner, row[0], cls.SUGGESTION) for row in rows]

    @classmethod
    def addable(cls, player, facebook_ids, game_center_ids):
        owner = cls._account_id(player)
        facebook_ids = {str(value) for value in facebook_ids if str(value)}
        game_center_ids = {str(value) for value in game_center_ids if str(value)}
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            cls._migrate_legacy(connection, player)
            rows = connection.execute(
                "SELECT lowID FROM players WHERE lowID <> ?", (owner,)
            ).fetchall()
            result = []
            for row in rows:
                friend_id = row[0]
                if (
                    cls._state(connection, owner, friend_id) is not None
                    or cls._state(connection, friend_id, owner) is not None
                ):
                    continue
                progression = DataBase._read_state(
                    connection, friend_id, "progression"
                )
                facebook = str(progression.get("facebookID", "") or "")
                game_center = str(progression.get("gameCenterID", "") or "")
                if facebook not in facebook_ids and game_center not in game_center_ids:
                    continue
                entry = cls._entry(connection, owner, friend_id, cls.SUGGESTION)
                if entry is not None:
                    result.append(entry)
        return result

    @classmethod
    def set_facebook(cls, player, facebook_id="", facebook_token="", linked=True):
        low_id = cls._account_id(player)
        facebook_id = str(facebook_id or "")
        facebook_token = str(facebook_token or "")
        if linked and (not facebook_id or not facebook_token):
            raise FriendError("Credenciais Facebook incompletas")
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                "SELECT 1 FROM players WHERE lowID = ?", (low_id,)
            ).fetchone()
            if row is None:
                raise FriendError("Conta não encontrada")
            progression = DataBase._read_state(
                connection, low_id, "progression"
            )
            progression["isFBLinked"] = bool(linked)
            progression["facebookID"] = facebook_id if linked else ""
            progression["facebookToken"] = facebook_token if linked else ""
            DataBase._write_state(
                connection, low_id, "progression", progression
            )
        player.progression = progression
        player.IsFacebookLinked = int(bool(linked))
        player.FacebookID = progression["facebookID"]
        player.FacebookToken = progression["facebookToken"]
        return progression
