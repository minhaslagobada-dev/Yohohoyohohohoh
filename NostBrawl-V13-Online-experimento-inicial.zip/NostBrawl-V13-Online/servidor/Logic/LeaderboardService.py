from Database.DatabaseManager import DataBase
from Logic.ClubService import ClubService


class LeaderboardService:
    @staticmethod
    def players(brawler_id=None):
        selected_brawler = None if brawler_id is None else int(brawler_id)
        with DataBase._connection() as connection:
            rows = connection.execute(
                "SELECT lowID, name, trophies, profileIcon, namecolor, clubID, "
                "playerExp, online FROM players"
            ).fetchall()
            brawler_trophies = {}
            if selected_brawler is not None:
                for row in rows:
                    brawler_trophies[row[0]] = DataBase._read_state(
                        connection, row[0], "brawlersTrophies"
                    )
            club_names = {
                int(row[0]): row[1]
                for row in connection.execute("SELECT id, name FROM clubs")
            }

        entries = []
        for row in rows:
            if selected_brawler is None:
                trophies = DataBase._number(row[2])
            else:
                brawlers = brawler_trophies.get(row[0], {})
                if not isinstance(brawlers, dict):
                    brawlers = {}
                trophies = DataBase._number(
                    brawlers.get(str(selected_brawler), 0)
                )
                if trophies <= 0:
                    continue
            club_id = DataBase._number(row[5])
            entries.append({
                "low_id": DataBase._number(row[0]),
                "name": row[1] or "Guest",
                "trophies": trophies,
                "profile_icon": DataBase._number(row[3]),
                "name_color": DataBase._number(row[4]),
                "club_id": club_id,
                "club_name": club_names.get(club_id, "") if club_id else "",
                "player_experience": DataBase._number(row[6]),
                "online": DataBase._number(row[7]),
            })
        entries.sort(key=lambda entry: (-entry["trophies"], entry["low_id"]))
        return entries

    @staticmethod
    def clubs():
        return ClubService.list_clubs(1, ClubService.MAX_MEMBERS, 3, None)
