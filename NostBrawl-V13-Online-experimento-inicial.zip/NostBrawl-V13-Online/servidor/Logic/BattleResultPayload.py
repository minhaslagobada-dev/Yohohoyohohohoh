from Files.CsvLogic.Skins import Skins
from Logic.BattleEnd import BattleParticipant


def _participants(player):
    battle = getattr(player, "battle_end", None)
    if battle is not None and getattr(battle, "participants", None):
        return list(battle.participants), battle.local_index
    count = int(getattr(player, "players", 6) or 6)
    if not 1 <= count <= 10:
        raise ValueError("Invalid battle participant count")
    participants = [BattleParticipant(
        brawler_id=int(getattr(player, "brawler_id", 0) or 0),
        skin_id=int(getattr(player, "skin_id", 0) or 0),
        team=int(getattr(player, "team", 0) or 0),
        is_player=True,
        name=str(getattr(player, "name", "") or ""),
    )]
    for index in range(1, count):
        participants.append(BattleParticipant(
            brawler_id=int(getattr(player, f"bot{index}", 0) or 0),
            skin_id=0,
            team=int(getattr(player, f"bot{index}_team", 0) or 0),
            is_player=False,
            name=str(getattr(player, f"bot{index}_n", "") or ""),
        ))
    return participants, 0


def _data_reference(message, csv_id, item_id):
    if not csv_id:
        message.writeVint(0)
    else:
        message.writeScId(csv_id, item_id)


def encode_battle_result(message, rewards, game_mode):
    player = message.player
    participants, local_index = _participants(player)
    local = participants[local_index]
    reward_data = rewards.rewards
    tutorial_state = int(getattr(player, "tutorial", 2) or 0)
    tutorial = tutorial_state == 1
    is_in_real_game = tutorial_state == 2
    old_battle_tokens = int(reward_data.get("old_battle_tokens", 0) or 0)
    remaining_battle_tokens = int(reward_data.get("battle_tokens", 0) or 0)

    message.writeVint(game_mode)
    if game_mode in (2, 5):
        message.writeVint(int(getattr(player, "rank", 1) or 0))
    else:
        message.writeVint(int(getattr(player, "battle_result", 0) or 0))
    message.writeVint(rewards.token)
    message.writeVint(rewards.gainedtrophies)
    message.writeVint(rewards.doubledtokens)
    message.writeVint(rewards.remainingtokens)
    message.writeVint(0)
    message.writeBoolean(bool(reward_data.get("hasStarKey", False)))
    message.writeBoolean(old_battle_tokens <= 0)
    message.writeBoolean(remaining_battle_tokens <= 0)
    message.writeBoolean(tutorial)
    message.writeBoolean(is_in_real_game)
    message.writeBoolean(tutorial)
    message.writeVint(len(participants))

    old_experience = int(reward_data.get(
        "old_experience",
        int(getattr(player, "player_experience", 0) or 0)
        - rewards.experience - rewards.mvpexperience,
    ))
    for index, participant in enumerate(participants):
        is_local = index == local_index
        is_player = bool(participant.is_player)
        message.writeString(
            str(getattr(player, "name", "") or "") if is_local else participant.name
        )
        message.writeBoolean(is_player)
        message.writeBoolean(participant.team != local.team)
        message.writeBoolean(is_local and bool(rewards.starplayer))
        _data_reference(message, 16, participant.brawler_id)
        skin_id = Skins.resolve_skin(participant.brawler_id, participant.skin_id)
        _data_reference(message, 29, skin_id)
        message.writeVint(rewards.brawler_trophies if is_local else 0)
        if is_local:
            levels = getattr(player, "Brawler_level", {})
            power_level = int(levels.get(
                str(participant.brawler_id),
                levels.get(participant.brawler_id, 0),
            ) or 0) + 1
        else:
            power_level = 10
        message.writeVint(power_level)
        message.writeBoolean(is_player)
        if is_player:
            message.writeInt(int(getattr(player, "high_id", 0) or 0) if is_local else 0)
            message.writeInt(int(getattr(player, "low_id", 0) or 0) if is_local else 0)

    experience = reward_data.get("exp_rewards_array", {
        0: rewards.experience,
        8: rewards.mvpexperience,
    })
    message.writeVint(len(experience))
    for reward_type, amount in sorted(experience.items(), key=lambda item: int(item[0])):
        message.writeVint(int(reward_type))
        message.writeVint(int(amount))
    message.writeVint(0)
    message.writeVint(2)
    message.writeVint(1)
    message.writeVint(rewards.brawler_trophies)
    message.writeVint(rewards.brawler_trophies_for_rank)
    message.writeVint(5)
    message.writeVint(old_experience)
    message.writeVint(old_experience)
    _data_reference(message, 28, int(getattr(player, "profile_icon", 0) or 0))
    message.writeBoolean(False)
