class PresenceService:
    _clients = None

    @classmethod
    def bind_clients(cls, clients):
        cls._clients = clients

    @classmethod
    def status(cls, low_id, persisted=0, clients=None):
        registry = cls._clients if clients is None else clients
        if registry is None:
            try:
                return int(persisted or 0)
            except (TypeError, ValueError):
                return 0
        recipient = registry.get("Clients", {}).get(str(int(low_id)))
        if recipient is None:
            return 0
        try:
            return int(recipient.get("Status", 0) or 0)
        except (TypeError, ValueError):
            return 0

    @classmethod
    def set_status(cls, player, status, client=None):
        status = int(status)
        player.online = status
        registry = getattr(player, "ClientDict", None) or cls._clients
        if registry is None:
            return True
        recipient = registry.get("Clients", {}).get(
            str(int(getattr(player, "low_id", 0) or 0))
        )
        if client is None:
            if recipient is not None:
                recipient["Status"] = status
            return True
        if recipient is None or recipient.get("SocketInfo") is not client:
            return False
        recipient["Status"] = status
        return True

    @classmethod
    def publish(cls, player):
        from Logic.ClubService import ClubService
        from Logic.FriendService import FriendService

        return {
            "friends": FriendService.push_presence(player),
            "club": ClubService.push_presence(player),
        }
