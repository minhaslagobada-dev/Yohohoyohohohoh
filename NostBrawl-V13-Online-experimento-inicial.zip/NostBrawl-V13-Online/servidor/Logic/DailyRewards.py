import time
from datetime import datetime

from Database.DatabaseManager import DataBase


class DailyRewardError(ValueError):
    pass


class DailyRewards:
    TOKEN_LIMIT = 700
    STAR_AMOUNT = 1

    @staticmethod
    def _moment(now=None):
        return datetime.now() if now is None else now

    @classmethod
    def _day(cls, now=None):
        return cls._moment(now).date().isoformat()

    @staticmethod
    def _player_id(player):
        try:
            low_id = int(getattr(player, "low_id", 0) or 0)
        except (TypeError, ValueError):
            return 0
        token = getattr(player, "token", None)
        if low_id <= 0 or not isinstance(token, str) or not token or token == "None":
            return 0
        return low_id

    @classmethod
    def _ensure_locked(cls, connection, low_id, now=None):
        day = cls._day(now)
        row = connection.execute(
            "SELECT used FROM daily_token_limits WHERE player_id = ? AND day = ?",
            (low_id, day),
        ).fetchone()
        if row is None:
            previous = connection.execute(
                "SELECT 1 FROM daily_token_limits WHERE player_id = ? LIMIT 1",
                (low_id,),
            ).fetchone()
            if previous is not None:
                used = 0
            else:
                account = connection.execute(
                    "SELECT battleTokens FROM players WHERE lowID = ?", (low_id,)
                ).fetchone()
                if account is None:
                    raise DailyRewardError("Conta não encontrada para o limite diário")
                stored = max(0, min(cls.TOKEN_LIMIT, int(account[0] or 0)))
                used = cls.TOKEN_LIMIT - stored
            now_timestamp = int(time.time())
            connection.execute(
                "INSERT INTO daily_token_limits (player_id, day, used, updated_at) "
                "VALUES (?, ?, ?, ?)",
                (low_id, day, used, now_timestamp),
            )
        else:
            used = int(row[0] or 0)
            if not 0 <= used <= cls.TOKEN_LIMIT:
                raise DailyRewardError("Consumo diário persistido fora do limite")
        remaining = cls.TOKEN_LIMIT - used
        cursor = connection.execute(
            "UPDATE players SET battleTokens = ? WHERE lowID = ?",
            (remaining, low_id),
        )
        if cursor.rowcount != 1:
            raise DailyRewardError("Conta não encontrada para o limite diário")
        return {
            "day": day,
            "limit": cls.TOKEN_LIMIT,
            "used": used,
            "remaining": remaining,
            "old_battle_tokens": remaining,
        }

    @classmethod
    def sync_player(cls, player, now=None):
        low_id = cls._player_id(player)
        if low_id <= 0:
            remaining = max(
                0, min(cls.TOKEN_LIMIT, int(getattr(player, "battle_tokens", 0) or 0))
            )
            return {
                "day": cls._day(now),
                "limit": cls.TOKEN_LIMIT,
                "used": cls.TOKEN_LIMIT - remaining,
                "remaining": remaining,
                "persisted": False,
            }
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            state = cls._ensure_locked(connection, low_id, now)
        player.battle_tokens = state["remaining"]
        state["persisted"] = True
        return state

    @classmethod
    def consume(cls, connection, low_id, requested, doubler=0, now=None):
        try:
            low_id = int(low_id)
            requested = int(requested)
            doubler = max(0, int(doubler))
        except (TypeError, ValueError):
            raise DailyRewardError("Recompensa diária inválida") from None
        if low_id <= 0 or requested < 0:
            raise DailyRewardError("Recompensa diária inválida")
        state = cls._ensure_locked(connection, low_id, now)
        base = min(requested, state["remaining"])
        doubled = min(base, doubler, state["remaining"] - base)
        total = base + doubled
        if total:
            used = state["used"] + total
            cursor = connection.execute(
                "UPDATE daily_token_limits SET used = ?, updated_at = ? "
                "WHERE player_id = ? AND day = ?",
                (used, int(time.time()), low_id, state["day"]),
            )
            if cursor.rowcount != 1:
                raise DailyRewardError("Falha ao persistir o consumo diário")
            state["used"] = used
            state["remaining"] = cls.TOKEN_LIMIT - used
            cursor = connection.execute(
                "UPDATE players SET battleTokens = ? WHERE lowID = ?",
                (state["remaining"], low_id),
            )
            if cursor.rowcount != 1:
                raise DailyRewardError("Falha ao atualizar os tokens diários")
        state.update({
            "requested_tokens": requested,
            "tokens_gain": base,
            "doubled_tokens": doubled,
            "total_tokens": total,
            "remaining_doubler": doubler - doubled,
            "battle_tokens": state["remaining"],
        })
        return state

    @classmethod
    def claim_star(cls, connection, low_id, map_id, battle_id, eligible, now=None):
        if not eligible:
            return False
        try:
            low_id = int(low_id)
            map_id = int(map_id)
        except (TypeError, ValueError):
            raise DailyRewardError("Evento da ficha estrela inválido") from None
        if low_id <= 0 or map_id < 0 or not battle_id:
            raise DailyRewardError("Ficha estrela exige partida e evento persistentes")
        day = cls._day(now)
        existing = connection.execute(
            "SELECT 1 FROM daily_star_rewards "
            "WHERE player_id = ? AND day = ? AND map_id = ?",
            (low_id, day, map_id),
        ).fetchone()
        if existing is not None:
            return False
        connection.execute(
            "INSERT INTO daily_star_rewards ("
            "player_id, day, map_id, amount, battle_id, created_at"
            ") VALUES (?, ?, ?, ?, ?, ?)",
            (low_id, day, map_id, cls.STAR_AMOUNT, str(battle_id), int(time.time())),
        )
        return True
