import hashlib
import json

from Logic.BoxInventory import BoxInventory
from Logic.RewardDelivery import RewardDelivery
from Logic.Rewards import RewardError, RewardTransaction
from Logic.ShopCatalog import ShopCatalog
from Logic.ShopService import ShopService


class BillingService:
    @staticmethod
    def _transaction_hash(values):
        serialized = json.dumps(
            [str(value) for value in values], ensure_ascii=False, separators=(",", ":")
        ).encode("utf-8")
        return hashlib.sha256(serialized).hexdigest()

    @staticmethod
    def _experience_level(player):
        value = getattr(player, "experience_level", None)
        if value is None:
            value = getattr(player, "player_experience", 0)
        try:
            return max(0, int(value or 0))
        except (TypeError, ValueError):
            return 0

    @classmethod
    def purchase(cls, player, values, now=None):
        if not isinstance(values, (list, tuple)) or len(values) != 6:
            raise RewardError("Pedido de billing inválido")
        values = [str(value) for value in values]
        package = ShopCatalog.billing_package(values)
        now = ShopService._timestamp(now)
        transaction_id = cls._transaction_hash(values)
        state = ShopService.get_state(player, now)
        billing = state["billing"]
        if transaction_id in billing["transactions"]:
            raise RewardError("Transação de billing já processada")
        is_bundle = package["type"] in (2, 3)
        if is_bundle and package["name"] in billing["bundles"]:
            raise RewardError("Esse pacote já foi adquirido")
        if is_bundle and cls._experience_level(player) < package["xpLevelReq"]:
            raise RewardError("O nível da conta ainda não libera esse pacote")
        if package["bigBoxCount"] < 0 or package["bigBoxCount"] > 10:
            raise RewardError("Quantidade de caixas do pacote inválida")
        transaction = RewardTransaction(player)
        transaction.add_reward("gems", package["diamonds"], exact=True)
        rewards = [{"type": 2, "amount": package["diamonds"]}]
        stored_boxes = []
        if package["bigBoxCount"]:
            BoxInventory.add(transaction, 12, package["bigBoxCount"])
            stored_boxes.append({"boxType": 12, "amount": package["bigBoxCount"]})
        billing["transactions"][transaction_id] = {
            "product": package["name"],
            "processedAt": now,
        }
        if is_bundle:
            billing["bundles"][package["name"]] = {
                "transaction": transaction_id,
                "processedAt": now,
            }
        ShopService._save_state(player, state, transaction)
        transaction.commit()
        return {
            "package": package,
            "transactionId": transaction_id,
            "isBundle": is_bundle,
            "rewards": rewards,
            "storedBoxes": stored_boxes,
            "responses": RewardDelivery.responses(rewards, stored_boxes),
        }
