import time
from threading import Thread

from Logic.Battle.BattleParticipants import BattleParticipants
from Packets.Messages.Server.Battle.StartLoadingMessage import StartLoadingMessage
from Packets.Messages.Server.Battle.VisionUpdateMessage import VisionUpdateMessage


class Battle(Thread):
    def __init__(self, client, player, state, room=None, participants=None):
        Thread.__init__(self, daemon=True)
        self.client = client
        self.player = player
        self.subTick = 0
        self.tick = 0
        self.started = 0
        self.state = state
        self.room = room
        self.participants = participants or BattleParticipants.build(room, player)
        self.player.battleTick = 0
        self.player.battle_room = room
        self.player.battle_participants = self.participants

    def run(self):
        self.startBattle()

    def startBattle(self):
        self.started = 1
        try:
            StartLoadingMessage(
                self.client, self.player, self.room, self.participants
            ).send()
            while self.started:
                self.tick += 1
                self.subTick = 0
                self.player.battleTick = self.tick
                VisionUpdateMessage(
                    self.client, self.player, self.room, self.participants
                ).send()
                time.sleep(0.0515)
        except (ConnectionError, OSError):
            pass
        finally:
            self.started = 0
