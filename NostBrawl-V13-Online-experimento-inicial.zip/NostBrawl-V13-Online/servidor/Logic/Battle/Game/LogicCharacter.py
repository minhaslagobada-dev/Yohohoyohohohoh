class LogicCharacter:
    def encode(self, stream, participants=None):
        if participants is None:
            participants = getattr(self, "participants", None)
        if participants is None:
            player = self.player
            participants = [{
                "index": 0,
                "brawler_id": int(getattr(player, "brawler_id", 0) or 0),
            }]
        stream.writePositiveInt(len(participants), 7)
        for entry in participants:
            stream.writePositiveInt(16, 5)
            stream.writePositiveInt(int(entry["brawler_id"]), 8)
        for index in range(len(participants)):
            stream.writePositiveInt(index, 14)

        for entry in participants:
            stream.writePositiveVInt(3125, 4)
            stream.writePositiveVInt(9500, 4)
            stream.writePositiveInt(0, 3)
            stream.writePositiveInt(0, 4)
            stream.writePositiveInt(10, 4)
            stream.writePositiveInt(0, 1)
            stream.writePositiveInt(0, 1)
            stream.writePositiveInt(0, 3)
            stream.writePositiveInt(0, 1)
            stream.writeInt(63, 6)
            stream.writePositiveInt(0, 1)
            stream.writePositiveInt(0, 1)
            stream.writePositiveInt(0, 1)
            stream.writePositiveInt(0, 1)
            stream.writePositiveInt(1, 1)
            stream.writePositiveInt(1, 1)
            stream.writePositiveInt(0, 1)
            stream.writePositiveInt(0, 1)
            stream.writePositiveInt(0, 2)
            stream.writePositiveInt(3600, 13)
            stream.writePositiveInt(3600, 13)
            stream.writePVIntMax255OZ(0)
            stream.writePositiveInt(0, 1)
            stream.writePositiveInt(0, 4)
            stream.writePositiveInt(0, 2)
            stream.writePositiveInt(0, 1)
            stream.writePositiveInt(0, 9)
            stream.writePositiveInt(0, 1)
            stream.writePositiveInt(0, 1)
            stream.writePositiveInt(0, 5)
            stream.writePositiveInt(1, 1)
            stream.writePositiveInt(0, 1)
            stream.writePositiveInt(1, 1)
            stream.writePositiveInt(3000, 12)
            stream.writePositiveInt(1, 1)
            stream.writePositiveInt(0, 1)
            stream.writePositiveInt(1, 1)
            stream.writePositiveInt(0, 8)
