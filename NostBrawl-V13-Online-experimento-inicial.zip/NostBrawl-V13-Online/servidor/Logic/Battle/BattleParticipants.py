from Files.CsvLogic.Characters import Characters
from Files.CsvLogic.Skins import Skins
from Logic.EventRotation import EventRotation


class BattleParticipants:
    GAME_MODE_VARIATIONS = {
        "CoinRush": 0,
        "BossFight": 2,
        "Survival": 7,
        "BountyHunter": 3,
        "LaserBall": 4,
        "AttackDefend": 5,
        "BattleRoyale": 6,
        "BattleRoyaleTeam": 9,
        "Raid": 8,
        "Tutorial": 11,
    }

    @staticmethod
    def location(map_id):
        locations = EventRotation.locations()
        try:
            return locations[int(map_id)]
        except (IndexError, TypeError, ValueError):
            raise ValueError("Mapa de batalha inválido") from None

    @classmethod
    def game_mode_variation(cls, map_id):
        location = cls.location(map_id)
        return cls.GAME_MODE_VARIATIONS.get(location["game_mode"], -1)

    @staticmethod
    def _skin(brawler_id, skin_id=0):
        try:
            return int(brawler_id), Skins.resolve_skin(brawler_id, skin_id)
        except (TypeError, ValueError):
            brawler_id = 0
            return brawler_id, Skins.get_default_skin(brawler_id)

    @classmethod
    def _entry(cls, member, index, team, bot=False):
        brawler_id, skin_id = cls._skin(
            member.get("brawler_id", 0), member.get("skin_id", 0)
        )
        return {
            "index": index,
            "team": team,
            "name": str(member.get("name", "Bot") or "Bot"),
            "low_id": 0 if bot else int(member.get("low_id", 0) or 0),
            "high_id": 0 if bot else int(member.get("high_id", 0) or 0),
            "brawler_id": brawler_id,
            "skin_id": skin_id,
            "bot": bot,
        }

    @classmethod
    def build(cls, room, player=None):
        room = room or {}
        map_id = int(room.get("map_id", getattr(player, "map_id", 7)) or 0)
        game_mode = cls.location(map_id)["game_mode"]
        members = list(room.get("members", []))
        if not members and player is not None:
            members = [{
                "low_id": int(getattr(player, "low_id", 0) or 0),
                "high_id": int(getattr(player, "high_id", 0) or 0),
                "name": str(getattr(player, "name", "") or ""),
                "brawler_id": int(getattr(player, "brawler_id", 0) or 0),
                "skin_id": int(getattr(player, "skin_id", 0) or 0),
                "team": 0,
            }]
        capacity = int(room.get("capacity", 0) or 0)
        if capacity <= 0:
            if game_mode in {"BattleRoyale", "BattleRoyaleTeam"}:
                capacity = 10
            elif game_mode == "Survival":
                capacity = 6
            elif game_mode == "Raid":
                capacity = 3
            else:
                capacity = 6
        capacity = max(capacity, len(members))
        entries = []

        if game_mode == "BattleRoyale":
            for member in members:
                entries.append(cls._entry(member, len(entries), len(entries)))
        elif game_mode == "BattleRoyaleTeam":
            for member in members:
                entries.append(cls._entry(member, len(entries), len(entries) // 2))
        elif game_mode in {"BossFight", "Survival", "Raid"}:
            for member in members:
                entries.append(cls._entry(member, len(entries), 0))
        else:
            side_counts = [0, 0]
            for member in members:
                try:
                    team = int(member.get("team", 0) or 0)
                except (TypeError, ValueError):
                    team = 0
                if team not in (0, 1) or side_counts[team] >= 3:
                    team = 0 if side_counts[0] <= side_counts[1] else 1
                side_counts[team] += 1
                entries.append(cls._entry(member, len(entries), team))

        brawlers = Characters.get_brawlers_id()
        if not brawlers:
            raise ValueError("Nenhum brawler disponível para bots")
        room_id = int(room.get("id", 0) or 0)
        while len(entries) < capacity:
            index = len(entries)
            if game_mode == "BattleRoyale":
                team = index
            elif game_mode == "BattleRoyaleTeam":
                team = index // 2
            elif game_mode in {"BossFight", "Survival", "Raid"}:
                team = 0
            else:
                counts = [0, 0]
                for entry in entries:
                    if entry["team"] in (0, 1):
                        counts[entry["team"]] += 1
                team = 0 if counts[0] <= counts[1] else 1
            brawler_id = brawlers[(room_id + index) % len(brawlers)]
            bot = {
                "name": "Bot",
                "brawler_id": brawler_id,
                "skin_id": Skins.get_default_skin(brawler_id),
            }
            entries.append(cls._entry(bot, index, team, bot=True))
        return entries

    @staticmethod
    def own_index(entries, player):
        low_id = int(getattr(player, "low_id", 0) or 0)
        for entry in entries:
            if not entry["bot"] and entry["low_id"] == low_id:
                return int(entry["index"])
        return 0
