import copy
import threading
import time

from Database.DatabaseManager import DataBase
from Files.CsvLogic.Skins import Skins
from Logic.EventRotation import EventError, EventRotation
from Logic.FriendService import FriendService


class GameRoomService:
    _entries = {}
    _next_room_id = 1
    _lock = threading.RLock()

    @classmethod
    def init(cls):
        with cls._lock:
            cls._entries = {}
            cls._next_room_id = 1

    @classmethod
    def count(cls):
        with cls._lock:
            return len(cls._entries)

    @staticmethod
    def _account_id(player):
        try:
            low_id = int(getattr(player, "low_id", 0) or 0)
        except (TypeError, ValueError):
            low_id = 0
        if low_id <= 0:
            raise ValueError("Conta inválida para GameRoom")
        return low_id

    @staticmethod
    def _mapping_value(mapping, key, default=0):
        if not isinstance(mapping, dict):
            return default
        try:
            return int(mapping.get(str(key), mapping.get(key, default)) or 0)
        except (TypeError, ValueError):
            return default

    @staticmethod
    def _capacity(map_id):
        try:
            location = EventRotation.locations()[int(map_id)]
        except (IndexError, TypeError, ValueError):
            return 6
        if location["game_mode"] in {"BattleRoyale", "BattleRoyaleTeam"}:
            return 10
        if location["game_mode"] == "Survival":
            return 6
        if location["game_mode"] == "Raid":
            return 3
        return 6

    @staticmethod
    def _location(map_id):
        try:
            map_id = int(map_id)
        except (TypeError, ValueError):
            raise ValueError("Mapa inválido") from None
        locations = EventRotation.locations()
        if not 0 <= map_id < len(locations) or not locations[map_id]["enabled"]:
            raise ValueError("Mapa não habilitado")
        return locations[map_id]

    @classmethod
    def _map_for_create(cls, player, slot, requested_map):
        try:
            slot = int(slot)
            requested_map = int(requested_map)
        except (TypeError, ValueError):
            raise ValueError("Slot ou mapa inválido") from None
        if 1 <= slot <= len(EventRotation.SLOT_POOLS):
            event = EventRotation.resolve_slot(player, slot)
            return int(event["map_id"]), slot
        if requested_map == -64:
            event = EventRotation.resolve_slot(player, 0)
            return int(event["map_id"]), 0
        return int(cls._location(requested_map)["id"]), 0

    @classmethod
    def _selected_skin(cls, player, brawler):
        selected = getattr(player, "brawlers_skins", {})
        skin = cls._mapping_value(selected, brawler, 0)
        if not skin and int(getattr(player, "brawler_id", 0) or 0) == brawler:
            skin = int(getattr(player, "skin_id", 0) or 0)
        return Skins.resolve_skin(brawler, skin)

    @classmethod
    def _new_member(cls, player, owner):
        low_id = cls._account_id(player)
        brawler = int(getattr(player, "brawler_id", 0) or 0)
        return {
            "low_id": low_id,
            "high_id": int(getattr(player, "high_id", 0) or 0),
            "host": bool(owner),
            "ready": False,
            "team": 0,
            "status": 3,
            "brawler_id": brawler,
            "skin_id": cls._selected_skin(player, brawler),
            "trophies": cls._mapping_value(
                getattr(player, "brawlers_trophies", {}), brawler
            ),
            "highest_trophies": cls._mapping_value(
                getattr(player, "brawlers_trophies", {}), brawler
            ),
            "power_level": cls._mapping_value(
                getattr(player, "Brawler_level", {}), brawler, 0
            ),
            "name": str(getattr(player, "name", "") or ""),
            "profile_icon": int(getattr(player, "profile_icon", 0) or 0),
            "name_color": int(getattr(player, "name_color", 0) or 0),
            "_player": player,
        }

    @staticmethod
    def _public_member(member):
        return {
            key: copy.deepcopy(value)
            for key, value in member.items() if not key.startswith("_")
        }

    @staticmethod
    def _public_invite(invite):
        return {
            "room_id": int(invite["room_id"]),
            "sender_id": int(invite["sender_id"]),
            "recipient_id": int(invite["recipient_id"]),
            "name": str(invite["name"]),
            "invite_type": int(invite["invite_type"]),
            "status": 0,
            "entry": copy.deepcopy(invite.get("entry")),
        }

    @classmethod
    def _snapshot(cls, room):
        if room is None:
            return None
        members = [cls._public_member(member) for member in room["members"]]
        owner = next((member["low_id"] for member in members if member["host"]), 0)
        return {
            "id": int(room["id"]),
            "type": int(room["type"]),
            "map_id": int(room["map_id"]),
            "slot_index": int(room["slot_index"]),
            "map_slot": int(room.get("map_slot", 0)),
            "practice": bool(room["practice"]),
            "advertise_band": bool(room.get("advertise_band", False)),
            "advertise_friends": bool(room.get("advertise_friends", True)),
            "capacity": cls._capacity(room["map_id"]),
            "owner_id": owner,
            "player_count": len(members),
            "members": members,
            "invites": [
                cls._public_invite(invite) for invite in room.get("invites", [])
            ],
            "join_requests": [],
        }

    @staticmethod
    def _member(room, low_id):
        return next(
            (member for member in room["members"] if member["low_id"] == low_id),
            None,
        )

    @classmethod
    def _remove_member(cls, room, low_id):
        member = cls._member(room, low_id)
        if member is None:
            return False
        room["members"].remove(member)
        if not room["members"]:
            cls._entries.pop(room["id"], None)
            return True
        if not any(item["host"] for item in room["members"]):
            room["members"][0]["host"] = True
        for item in room["members"]:
            item["ready"] = False
        return True

    @classmethod
    def _room(cls, room_id):
        try:
            return cls._entries.get(int(room_id))
        except (TypeError, ValueError):
            return None

    @classmethod
    def _room_for_player(cls, player):
        low_id = cls._account_id(player)
        try:
            room_id = int(getattr(player, "room_id", 0) or 0)
        except (TypeError, ValueError):
            room_id = 0
        room = cls._room(room_id) if room_id > 0 else None
        if room is not None and cls._member(room, low_id) is not None:
            return room
        return next(
            (
                candidate for candidate in cls._entries.values()
                if cls._member(candidate, low_id) is not None
            ),
            None,
        )

    @classmethod
    def _set_room_id(cls, player, room_id):
        low_id = cls._account_id(player)
        room_id = int(room_id)
        previous = int(getattr(player, "room_id", 0) or 0)
        player.room_id = room_id
        token = getattr(player, "token", "")
        if previous != room_id and token not in (None, "", "None"):
            DataBase._update_value("lowID", low_id, "roomID", room_id)

    @classmethod
    def _bind_player(cls, player, room):
        cls._set_room_id(player, int(room["id"]) if room is not None else 0)
        if room is not None:
            player.map_id = int(room["map_id"])
            player.slot_index = int(room["slot_index"])

    @classmethod
    def _append_event(cls, room, event, actor, target=None, swap_names=False):
        target = target or actor
        room["entry_counter"] += 1
        entry = {
            "kind": 4,
            "event": int(event),
            "id": int(room["entry_counter"]),
            "room_id": int(room["id"]),
            "player_id": int(actor["low_id"]),
            "player_name": str(target["name"] if swap_names else actor["name"]),
            "player_role": 0,
            "target_id": int(target["low_id"]),
            "target_name": str(actor["name"] if swap_names else target["name"]),
            "created_at": int(time.time()),
        }
        room["stream"].append(entry)
        return entry

    @classmethod
    def get(cls, room_id):
        with cls._lock:
            return cls._snapshot(cls._room(room_id))

    @classmethod
    def get_room_id(cls, room_id):
        return cls.get(room_id)

    @classmethod
    def get_rooms(cls):
        with cls._lock:
            return [cls._snapshot(room) for room in cls._entries.values()]

    @classmethod
    def for_player(cls, player):
        low_id = cls._account_id(player)
        with cls._lock:
            room = cls._room_for_player(player)
            if room is None:
                cls._bind_player(player, None)
                return None
            member = cls._member(room, low_id)
            if member is not None:
                member["_player"] = player
            cls._bind_player(player, room)
            return cls._snapshot(room)

    @classmethod
    def resume(cls, player):
        room = cls.for_player(player)
        if room is None:
            return None
        return cls.set_status(player, 3)

    @classmethod
    def disconnect(cls, player):
        room = cls.for_player(player)
        if room is None:
            return None
        return cls.set_status(player, 0)

    @classmethod
    def create(cls, player, slot=0, requested_map=0, room_type=0, practice=False):
        cls._account_id(player)
        map_id, slot = cls._map_for_create(player, slot, requested_map)
        with cls._lock:
            room_id = cls._next_room_id
            cls._next_room_id += 1
            room = {
                "id": room_id,
                "type": int(room_type),
                "practice": bool(practice),
                "advertise_band": False,
                "advertise_friends": True,
                "map_id": map_id,
                "slot_index": int(slot),
                "map_slot": int(slot),
                "members": [cls._new_member(player, True)],
                "invites": [],
                "stream": [],
                "entry_counter": 0,
            }
            cls._entries[room_id] = room
            cls._append_event(room, 101, room["members"][0])
            cls._bind_player(player, room)
            return cls._snapshot(room)

    @classmethod
    def request_join_transition(cls, player, room_id):
        low_id = cls._account_id(player)
        with cls._lock:
            target = cls._room(room_id)
            if target is None:
                return None, None, False
            previous = None
            departed = False
            current = cls._room_for_player(player)
            if current is not None and current["id"] == target["id"]:
                cls._bind_player(player, target)
                return cls._snapshot(target), None, False
            if current is not None:
                member = cls._member(current, low_id)
                cls._append_event(current, 103, member)
                cls._remove_member(current, low_id)
                cls._bind_player(player, None)
                departed = True
                if current["members"]:
                    previous = cls._snapshot(current)
            member = cls._new_member(player, False)
            target["members"].append(member)
            cls._append_event(target, 102, member)
            cls._bind_player(player, target)
            return cls._snapshot(target), previous, departed

    @classmethod
    def request_join(cls, player, room_id):
        room, _, _ = cls.request_join_transition(player, room_id)
        return room

    @classmethod
    def join(cls, player, room_id):
        return cls.request_join(player, room_id)

    @classmethod
    def leave(cls, player):
        low_id = cls._account_id(player)
        with cls._lock:
            room = cls._room_for_player(player)
            if room is None:
                cls._bind_player(player, None)
                return None, False
            member = cls._member(room, low_id)
            if member is None:
                cls._bind_player(player, None)
                return None, False
            cls._append_event(room, 103, member)
            cls._remove_member(room, low_id)
            cls._bind_player(player, None)
            if not room["members"]:
                return None, True
            return cls._snapshot(room), True

    @classmethod
    def kick(cls, player, target_id):
        cls._account_id(player)
        try:
            target_id = int(target_id)
        except (TypeError, ValueError):
            return None, 0
        with cls._lock:
            room = cls._room_for_player(player)
            if room is None:
                return None, 0
            actor = cls._member(room, int(player.low_id))
            target = cls._member(room, target_id)
            if actor is None or target is None:
                return None, 0
            cls._append_event(room, 104, actor, target, swap_names=True)
            cls._remove_member(room, target_id)
            target_player = target.get("_player")
            if target_player is not None:
                cls._bind_player(target_player, None)
            snapshot = cls._snapshot(room) if room["members"] else None
            return snapshot, target_id

    @classmethod
    def set_ranked_location(cls, player, map_id, slot):
        try:
            map_id = int(map_id)
            slot = int(slot)
        except (TypeError, ValueError):
            raise ValueError("Mapa ou slot de evento inválido") from None
        with cls._lock:
            room = cls._room_for_player(player)
            if room is None:
                return None
            event = EventRotation.resolve_slot(player, slot)
            if int(event["slot"]) != slot:
                raise EventError("Slot de evento inexistente")
            if int(event["map_id"]) != map_id:
                raise ValueError("Mapa divergente para o slot do evento")
            room["slot_index"] = int(event["slot"])
            room["map_slot"] = int(event["slot"])
            room["map_id"] = int(event["map_id"])
            room["type"] = 0
            for member in room["members"]:
                participant = member.get("_player")
                if participant is not None:
                    cls._bind_player(participant, room)
            return cls._snapshot(room)

    @classmethod
    def set_location(cls, player, map_id):
        with cls._lock:
            room = cls._room_for_player(player)
            if room is None:
                return None
            location = cls._location(map_id)
            room["map_id"] = int(location["id"])
            room["slot_index"] = 0
            room["map_slot"] = 0
            room["type"] = 1
            for member in room["members"]:
                participant = member.get("_player")
                if participant is not None:
                    cls._bind_player(participant, room)
            return cls._snapshot(room)

    @classmethod
    def toggle_practice(cls, player):
        with cls._lock:
            room = cls._room_for_player(player)
            if room is None:
                return None
            room["practice"] = not bool(room["practice"])
            return cls._snapshot(room)

    @classmethod
    def toggle_advertise_band(cls, player):
        with cls._lock:
            room = cls._room_for_player(player)
            if room is None:
                return None
            room["advertise_band"] = not bool(
                room.get("advertise_band", False)
            )
            return cls._snapshot(room)

    @classmethod
    def set_ready(cls, player, ready):
        low_id = cls._account_id(player)
        with cls._lock:
            room = cls._room_for_player(player)
            if room is None:
                return None
            member = cls._member(room, low_id)
            if member is not None:
                member["ready"] = bool(ready)
            return cls._snapshot(room)

    @classmethod
    def begin_battle(cls, player):
        cls._account_id(player)
        with cls._lock:
            room = cls._room_for_player(player)
            if room is None or room.get("battle_started", False):
                return None
            room["battle_started"] = True
            participants = []
            for member in room["members"]:
                member["ready"] = False
                if member["status"] != 0:
                    member["status"] = 5
                participant = member.get("_player")
                if participant is not None:
                    participants.append(participant)
            return cls._snapshot(room), participants

    @classmethod
    def set_status(cls, player, status):
        low_id = cls._account_id(player)
        with cls._lock:
            room = cls._room_for_player(player)
            if room is None:
                return None
            member = cls._member(room, low_id)
            if member is not None:
                member["status"] = int(status)
                member["_player"] = player
            return cls._snapshot(room)

    @classmethod
    def set_teams(cls, player, targets, team):
        with cls._lock:
            room = cls._room_for_player(player)
            if room is None or not targets:
                return None
            members = []
            for _, target_id in targets:
                member = cls._member(room, int(target_id))
                if member is not None:
                    members.append(member)
            if not members:
                return None
            side = 1 if int(team) >= 3 else 0
            for member in members:
                member["team"] = side
            return cls._snapshot(room)

    @classmethod
    def set_member_settings(cls, player, brawler_id=0, skin_id=0):
        low_id = cls._account_id(player)
        brawler = int(brawler_id)
        with cls._lock:
            room = cls._room_for_player(player)
            if room is None:
                return None
            member = cls._member(room, low_id)
            if member is None:
                return cls._snapshot(room)
            member["_player"] = player
            member["brawler_id"] = brawler
            member["skin_id"] = int(skin_id)
            member["trophies"] = cls._mapping_value(
                getattr(player, "brawlers_trophies", {}), brawler
            )
            member["highest_trophies"] = cls._mapping_value(
                getattr(player, "brawlers_trophies", {}), brawler
            )
            member["power_level"] = cls._mapping_value(
                getattr(player, "Brawler_level", {}), brawler, 0
            )
            return cls._snapshot(room)

    @classmethod
    def invite(cls, player, recipient_id, invite_type=0):
        sender_id = cls._account_id(player)
        recipient_id = int(recipient_id)
        with cls._lock:
            room = cls._room_for_player(player)
            if room is None:
                return None, None
            with DataBase._connection() as connection:
                account = connection.execute(
                    "SELECT name FROM players WHERE lowID = ?", (recipient_id,)
                ).fetchone()
                if account is None:
                    return None, None
                entry = FriendService._entry(
                    connection, recipient_id, sender_id
                )
            if entry is None:
                return None, None
            room.setdefault("invites", [])[:] = [
                invite for invite in room.get("invites", [])
                if int(invite["recipient_id"]) != recipient_id
            ]
            invite = {
                "room_id": int(room["id"]),
                "sender_id": sender_id,
                "recipient_id": recipient_id,
                "name": str(account[0] or ""),
                "invite_type": int(invite_type),
                "entry": entry,
            }
            room["invites"].append(invite)
            return cls._snapshot(room), cls._public_invite(invite)

    @classmethod
    def _take_invite(cls, player, room_id):
        low_id = cls._account_id(player)
        room = cls._room(room_id)
        if room is None:
            return None, None, None
        index = next(
            (
                index for index, invite in enumerate(room.get("invites", []))
                if int(invite["recipient_id"]) == low_id
            ),
            None,
        )
        if index is None:
            return room, None, None
        invite = room["invites"].pop(index)
        return room, invite, cls._public_invite(invite)

    @classmethod
    def clear_invite(cls, player, room_id, expected_type=None):
        with cls._lock:
            room, _, invite = cls._take_invite(player, room_id)
            if room is None or invite is None:
                return None, None
            return cls._snapshot(room), invite

    @classmethod
    def accept_invite(cls, player, room_id, expected_type=None):
        low_id = cls._account_id(player)
        with cls._lock:
            room, _, invite = cls._take_invite(player, room_id)
            if room is None or invite is None:
                return None, None
            if cls._member(room, low_id) is None:
                current = cls._room_for_player(player)
                if current is not None and current["id"] != room["id"]:
                    previous_member = cls._member(current, low_id)
                    cls._append_event(current, 103, previous_member)
                    cls._remove_member(current, low_id)
                member = cls._new_member(player, False)
                room["members"].append(member)
                cls._append_event(room, 102, member)
            cls._bind_player(player, room)
            return cls._snapshot(room), invite

    @classmethod
    def add_chat(cls, player, text):
        low_id = cls._account_id(player)
        with cls._lock:
            room = cls._room_for_player(player)
            if room is None:
                return None, None
            room["entry_counter"] += 1
            chat = {
                "kind": 2,
                "id": int(room["entry_counter"]),
                "room_id": int(room["id"]),
                "player_id": low_id,
                "player_name": str(getattr(player, "name", "") or ""),
                "player_role": 0,
                "message": str(text or ""),
                "created_at": int(time.time()),
            }
            room["stream"].append(chat)
            return cls._snapshot(room), copy.deepcopy(chat)

    @classmethod
    def stream(cls, room_id, after_id=0):
        with cls._lock:
            room = cls._room(room_id)
            if room is None:
                return []
            return copy.deepcopy([
                entry for entry in room["stream"]
                if entry["id"] > int(after_id)
            ])

    @classmethod
    def chats(cls, room_id, after_id=0):
        return [
            entry for entry in cls.stream(room_id, after_id)
            if entry["kind"] == 2
        ]
