import copy
import csv
import re
import threading
import time

from Database.DatabaseManager import DataBase
from Logic.NotificationFactory import NotificationFactory
from Logic.Rewards import RewardTransaction
from Utils.Config import Config


class SeasonService:
    STATE_KEY = "season"
    _sync_lock = threading.RLock()
    STATE_VERSION = 1
    DEFAULT_DURATION = "14d"
    MINIMUM_TROPHIES = 500
    LOSS_PERCENTAGE = 50
    SEASON_BOX_REWARDS = {6: 10, 10: 11, 14: 12}
    _milestones_cache = None

    @staticmethod
    def _integer(value, default=0):
        try:
            return int(value)
        except (TypeError, ValueError):
            return default

    @classmethod
    def _nonnegative(cls, value, default=0):
        return max(0, cls._integer(value, default))

    @classmethod
    def parse_duration(cls, value):
        if isinstance(value, bool):
            raise ValueError("SeasonDuration deve usar dias, horas ou minutos")
        if isinstance(value, int):
            seconds = value
        elif isinstance(value, str):
            match = re.fullmatch(r"(\d+)([dhm])?", value.strip().lower())
            if match is None:
                raise ValueError("SeasonDuration deve usar formatos como 70d, 12h ou 1m")
            amount = int(match.group(1))
            unit = match.group(2)
            multiplier = {None: 1, "m": 60, "h": 3600, "d": 86400}[unit]
            seconds = amount * multiplier
        else:
            raise ValueError("SeasonDuration deve usar dias, horas ou minutos")
        if seconds <= 0:
            raise ValueError("SeasonDuration deve ser maior que zero")
        return seconds

    @classmethod
    def duration(cls):
        return cls.parse_duration(
            Config.GetValue().get("SeasonDuration", cls.DEFAULT_DURATION)
        )

    @classmethod
    def milestones(cls):
        if cls._milestones_cache is not None:
            return cls._milestones_cache
        milestones = []
        with open(
            "GameAssets/csv_logic/milestones.csv",
            "r",
            encoding="utf-8-sig",
            newline="",
        ) as csv_file:
            for row in csv.DictReader(csv_file):
                if row.get("Type") != "6":
                    continue
                try:
                    milestone = {
                        "Index": int(row["Index"]),
                        "Trophies": int(row["ProgressStart"] or 0),
                        "Keys": int(row["SeasonEndRewardKeys"] or 0),
                        "RewardType": int(row["PrimaryLvlUpRewardType"] or 0),
                        "RewardCount": int(row["PrimaryLvlUpRewardCount"] or 0),
                    }
                except (KeyError, TypeError, ValueError) as error:
                    raise ValueError(
                        f"Marco de temporada inválido: {row.get('Name', '?')}"
                    ) from error
                if min(milestone.values()) < 0:
                    raise ValueError(
                        f"Marco de temporada negativo: {row.get('Name', '?')}"
                    )
                milestones.append(milestone)
        if not milestones:
            raise ValueError("Nenhum marco de temporada foi encontrado")
        milestones.sort(key=lambda value: (value["Trophies"], value["Index"]))
        cls._milestones_cache = tuple(milestones)
        return cls._milestones_cache

    @classmethod
    def milestone_for_trophies(cls, trophies):
        trophies = cls._nonnegative(trophies)
        selected = None
        for milestone in cls.milestones():
            if milestone["Trophies"] > trophies:
                break
            selected = milestone
        if selected is None:
            return {
                "Index": -1,
                "Trophies": 0,
                "Keys": 0,
                "RewardType": 0,
                "RewardCount": 0,
            }
        return copy.deepcopy(selected)

    @staticmethod
    def is_persistent(player):
        token = getattr(player, "token", None)
        low_id = SeasonService._integer(getattr(player, "low_id", 0))
        return (
            low_id > 0
            and isinstance(token, str)
            and bool(token)
            and token != "None"
        )

    @classmethod
    def _new_state(cls, now, generation=0):
        return {
            "version": cls.STATE_VERSION,
            "endsAt": int(now) + cls.duration(),
            "generation": max(0, cls._integer(generation)),
            "lastResetAt": 0,
        }

    @classmethod
    def _ensure_state(cls, player, now):
        current = getattr(player, "progression", {})
        if not isinstance(current, dict):
            current = {}
        raw = current.get(cls.STATE_KEY)
        if isinstance(raw, dict) and cls._integer(raw.get("endsAt")) > 0:
            return {
                "version": cls.STATE_VERSION,
                "endsAt": cls._integer(raw.get("endsAt")),
                "generation": max(0, cls._integer(raw.get("generation"))),
                "lastResetAt": max(0, cls._integer(raw.get("lastResetAt"))),
            }

        state = cls._new_state(now)
        progression = copy.deepcopy(current)
        progression[cls.STATE_KEY] = state
        if cls.is_persistent(player):
            DataBase._update_value(
                "lowID",
                cls._integer(getattr(player, "low_id", 0)),
                "progression",
                progression,
            )
        player.progression = progression
        return state

    @staticmethod
    def _sorted_brawler_keys(mapping):
        def sort_key(value):
            try:
                return (0, int(value))
            except (TypeError, ValueError):
                return (1, str(value))

        return sorted(mapping, key=sort_key)

    @classmethod
    def _reset_details(cls, player, now):
        current = getattr(player, "brawlers_trophies", {})
        if not isinstance(current, dict):
            current = {}
        updated = copy.deepcopy(current)
        changes = []
        total_loss = 0
        best_brawler = 0
        best_loss = 0

        for key in cls._sorted_brawler_keys(current):
            before = cls._nonnegative(current[key])
            excess = max(0, before - cls.MINIMUM_TROPHIES)
            loss = excess * cls.LOSS_PERCENTAGE // 100
            after = before - loss
            updated[key] = after
            if loss <= 0:
                continue
            total_loss += loss
            change = {
                "Brawler": cls._integer(key),
                "Before": before,
                "After": after,
                "Loss": loss,
            }
            changes.append(change)
            if loss > best_loss:
                best_loss = loss
                best_brawler = cls._integer(key)

        old_total = cls._nonnegative(getattr(player, "trophies", 0))
        new_total = max(0, old_total - total_loss)
        milestone = cls.milestone_for_trophies(old_total)
        boxes = []
        if milestone["Keys"] > 0:
            box_type = cls.SEASON_BOX_REWARDS.get(milestone["RewardType"])
            if box_type is not None and milestone["RewardCount"] > 0:
                boxes.append({
                    "Type": box_type,
                    "Count": milestone["RewardCount"],
                })

        best_after = cls._nonnegative(updated.get(str(best_brawler), 0))
        return {
            "updatedTrophies": updated,
            "newTotal": new_total,
            "notification": {
                "Best": {
                    "Trophies": best_after,
                    "Points": best_loss,
                    "Coins": best_loss,
                    "Bonus": 0,
                },
                "Total": {
                    "Trophies": new_total,
                    "Points": total_loss,
                    "Coins": total_loss,
                    "Bonus": milestone["Keys"],
                },
                "BestBrawler": best_brawler,
                "Boxes": boxes,
                "Milestone": milestone,
                "Changes": changes,
                "OldTotalTrophies": old_total,
                "NewTotalTrophies": new_total,
            },
        }

    @classmethod
    def _end_season(cls, player, now, state):
        details = cls._reset_details(player, now)
        notifications, notification = NotificationFactory._prepare_season(
            player, details["notification"], now
        )
        next_state = {
            "version": cls.STATE_VERSION,
            "endsAt": int(now) + cls.duration(),
            "generation": max(0, cls._integer(state.get("generation"))) + 1,
            "lastResetAt": int(now),
        }

        transaction = RewardTransaction(player)
        transaction.set_value(
            "brawlers_trophies",
            "brawlersTrophies",
            details["updatedTrophies"],
        )
        transaction.set_value("trophies", "trophies", details["newTotal"])
        transaction.set_value("Notifications", "Notifications", notifications)
        transaction.set_progression_value(cls.STATE_KEY, next_state)
        transaction.commit()
        return notification, next_state

    @classmethod
    def sync(cls, player, now=None):
        with cls._sync_lock:
            return cls._sync_unlocked(player, now)

    @classmethod
    def _sync_unlocked(cls, player, now=None):
        now = int(time.time() if now is None else now)
        if not cls.is_persistent(player):
            return {
                "enabled": False,
                "reset": False,
                "notification": None,
                "endsAt": 0,
                "remaining": 0,
            }

        state = cls._ensure_state(player, now)
        notification = None
        reset = False
        if now >= state["endsAt"]:
            notification, state = cls._end_season(player, now, state)
            reset = True
        return {
            "enabled": True,
            "reset": reset,
            "notification": copy.deepcopy(notification),
            "endsAt": state["endsAt"],
            "remaining": max(0, state["endsAt"] - now),
        }

    @classmethod
    def end_now(cls, player, now=None, expected_ends_at=None):
        with cls._sync_lock:
            now = int(time.time() if now is None else now)
            state = cls._ensure_state(player, now)
            if expected_ends_at is not None and state["endsAt"] != expected_ends_at:
                return None
            notification, next_state = cls._end_season(player, now, state)
            return {
                "notification": notification,
                "season": next_state,
            }
