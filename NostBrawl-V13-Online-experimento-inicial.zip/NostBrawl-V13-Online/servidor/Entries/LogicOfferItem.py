class LogicOfferItem:
    @staticmethod
    def _reference(writer, reference):
        if not reference:
            writer.v(0)
            return
        try:
            csv_id, item_id = int(reference[0]), int(reference[1])
        except (IndexError, TypeError, ValueError):
            raise ValueError("Invalid offer DataReference") from None
        if csv_id <= 0 or item_id < 0:
            raise ValueError("Invalid offer DataReference")
        writer.v(csv_id)
        writer.v(item_id)

    @classmethod
    def encode(cls, writer, item):
        writer.v(int(item["offerId"]))
        writer.v(int(item.get("amount", 0)))
        cls._reference(writer, item.get("target"))
        writer.v(int(item.get("value", 0)))
