# NostBrawl R115 — apresentação transacional das recompensas

## Escopo e continuidade

A R115 parte integralmente da R114 e preserva suas regras de economia, ledger, limites diários, eventos, persistência relacional e protocolo R101/V13.

- Nenhuma alteração no `config.json`, no schema v5, nos IDs, na ordem ou no layout dos packets.
- Nenhuma mudança em compras, poder, skins, Gameroom, SCID, criptografia ou mecânica das batalhas.
- R114 e revisões anteriores continuam preservadas.

## Investigação nativa concluída

A análise diferenciou a LIB ARM64 R101 da LIB ARM32 de outra V13. O formato longo de 23456 observado no ARM32 não foi aplicado à R101.

| Mensagem | Resultado na R101 |
|---|---|
| 23456 | Getter, vtable, encode e decode confirmam o envelope usado pelo servidor; não foi adotado o layout ARM32 incompatível. |
| 14109 | Um Boolean; nenhum campo adicional foi inserido. |
| 24101 | Home, avatar e VInt final continuam na ordem comprovada. |
| Recompensa 23456 | Estrutura nativa de três inteiros; `brawler_trophies` e `brawler_trophies_for_rank` são os valores anteriores da barra, enquanto `trophies_gain` contém o ganho. O bloco `[1,0,0]` da conta analisada não era um defeito. |

Timestamps de eventos e loja foram comparados com as referências e com a conta real. A thread periódica de batalha e os dois 14366 não forneceram evidência de causa do crash e não foram alterados para simular uma correção.

## Defeito reproduzido

A home serializava as animações `tokensAnim`, `trophiesAnim` e `bigTokensAnim`, mas nunca consumia os campos correspondentes de `progression`.

Na cópia da conta real, antes da correção:

| Leitura | tokensAnim | trophiesAnim | bigTokensAnim |
|---|---:|---:|---:|
| Primeira home após BattleEnd | 20 | 6 | 1 |
| Segunda home, sem nova partida | 20 | 6 | 1 |
| Nova carga da conta | 20 | 6 | 1 |

Isso comprovava repetição indevida da apresentação. Não prova, sozinho, que esse defeito seja a causa do encerramento visual do APK.

## Causa e correção

### `Packets/Messages/Server/Home/OwnHomeDataMessage.py`

- Captura os três valores usados na serialização sem alterar o payload.
- Consome a apresentação somente depois que `Writer._send_payload` concluiu `sendall` sem exceção.
- Não consome durante `encode()` e não consome quando o socket falha.
- Após a operação transacional, reconcilia os campos locais somente se ainda possuírem os valores apresentados; em divergência, adota o estado persistido sem sobrescrever uma recompensa mais nova.
- Mantém a regra de serialização já existente para animação negativa de troféus e permite seu consumo sem alterar o protocolo.

### `Database/DatabaseManager.py`

Foi adicionada a operação `consume_home_reward_animations`:

1. Abre `BEGIN IMMEDIATE`.
2. Confirma a existência da conta e lê o estado relacional atual.
3. Compara os três valores persistidos com os valores efetivamente serializados.
4. Se houver divergência, não apaga nada e devolve o estado persistido para reconciliar a sessão antiga: uma home antiga não pode eliminar a recompensa de uma partida mais nova.
5. Se forem idênticos, atualiza somente os três campos em uma cópia de `progression`, preservando os demais dados.
6. Usa o mesmo `commit/rollback` e `fsync` das demais gravações do servidor.

A limpeza é apenas da apresentação. Moedas, caixas, XP, troféus, saldo diário e o ledger permanente não são alterados por essa operação.

## Resultados

### Testes automatizados

**387 testes: todos aprovados.** Sete novos testes cobrem:

1. Consumo após envio bem-sucedido e segunda home zerada, sem mudança de recursos.
2. `encode()` e falha de `sendall` preservando a recompensa para nova tentativa.
3. Home antiga concorrendo com apresentação mais nova, sem apagá-la.
4. Sessão desatualizada adotando o estado persistido, tanto já consumido quanto substituído por recompensa mais nova.
5. Falha de gravação com rollback e nova tentativa bem-sucedida.
6. Consumo de animação negativa de troféus com o mesmo payload já utilizado.
7. Replay após consumo sem restaurar a apresentação; nova instância apresenta somente sua própria recompensa.

### Conta real fornecida, somente em cópia

- Banco original aberto como somente leitura e com hash inalterado.
- Cópia íntegra, schema v5 e `integrity_check = ok`.
- BattleEnd 23456 com 6 participantes e **0 byte residual**.
- Primeira home após a partida: `[20, 6, 1]`.
- Segunda home sem nova partida: `[0, 0, 0]`.
- Reload: `[0, 0, 0]`.
- `animationsRepeated = false`.

A conta enviada não é a conta do log original; portanto, esse replay não substitui o aceite no dispositivo que apresentou o crash.

### Processo real e reinício

- Primeira home apresenta `[20, 6, 1]`; a seguinte fica zerada.
- Relogin após reinício mantém a apresentação consumida.
- Replay após reinício retorna o BattleResult persistido, não altera recursos/ledger e não reintroduz animações.
- Nova instância concede uma nova recompensa e apresenta `[20, 6, 0]`; a ficha estrela não é duplicada.
- Estado visual do evento permanece `3` após a leitura e o reinício; os outros eventos continuam independentes.
- `dailyUsed`: 20 após a primeira partida e 40 após a segunda; saldo: 680 e 660.

### Demais matrizes

- **66/66 fluxos** integrados de BattleEnd, economia, eventos, compras, limites e desconexões aprovados.
- **6 eventos ranqueados** aprovados, com status novo/visualizado correto e ficha estrela independente por evento/dia.
- Bateria adversarial aprovada: 6 válidos, 622 truncamentos, 24 trailing bytes, 1.200 mutações, 1.000 aleatórios, mapas desabilitados, headers inválidos e oversize; nenhum crash, recompensa indevida ou ledger parcial.

## Limitações e aceite

Não houve ADB, emulador ou renderização do APK nesta validação. Sockets, decodificação e testes de banco não comprovam a renderização.

**A R115 corrige o defeito reproduzido de repetição da apresentação, mas não declara o crash visual resolvido sem teste no APK.** O aceite deve verificar várias partidas consecutivas, retorno à home, relogin e repetição do client, observando se a recompensa aparece uma única vez e se o encerramento deixou de ocorrer.

Evidências desta revisão: `r115-full.log`, `r115-home-presentation.log`, `r115-real-account-report.json`, `r115-process-report.json`, `r115-end-to-end-report.json`, `r115-adversarial-report.json` e `r115-ranked-location-report.json`.
