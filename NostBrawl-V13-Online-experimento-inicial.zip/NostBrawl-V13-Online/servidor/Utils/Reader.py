from io import BufferedReader, BytesIO


class BSMessageReader(BufferedReader):
    def __init__(self, initial_bytes):
        super().__init__(BytesIO(initial_bytes))
        self._payload_length = len(initial_bytes)
        self.native_v13 = False
        self._bit_index = 0
        self._bit_buffer = 0

    def enable_native_v13(self):
        """Use the V13 ChecksumEncoder signed VInt and packed booleans."""
        self.native_v13 = True
        self._bit_index = 0
        self._bit_buffer = 0
        return self

    def _read_exact(self, length):
        if self.native_v13:
            self._bit_index = 0
        if length < 0:
            raise ValueError(f"Negative field length: {length}")
        remaining = max(0, self._payload_length - self.tell())
        if length > remaining:
            raise ValueError(
                f"Unexpected end of message: wanted {length} bytes, got {remaining}"
            )
        data = self.read(length)
        if len(data) != length:
            raise ValueError(
                f"Unexpected end of message: wanted {length} bytes, got {len(data)}"
            )
        return data

    def read_byte(self):
        return int.from_bytes(self._read_exact(1), "big")

    def read_boolean(self):
        if self.native_v13:
            if self._bit_index == 0:
                data = self.read(1)
                if len(data) != 1:
                    raise ValueError("Unexpected end of packed V13 booleans")
                self._bit_buffer = data[0]
            value = bool(self._bit_buffer & (1 << self._bit_index))
            self._bit_index = (self._bit_index + 1) & 7
            return value

        value = self.read_byte()
        if value not in (0, 1):
            raise ValueError("Booleano inválido")
        return bool(value)

    def ensure_end(self):
        if self.read(1):
            raise ValueError("Mensagem contém dados residuais")

    def read_Vint(self):
        if self.native_v13:
            return self._read_native_vint()
        n = self._read_varint(True)
        return (n >> 1) ^ (-(n & 1))

    def _read_native_vint(self):
        first = self.read_byte()
        negative = bool(first & 0x40)
        result = first & 0x3F
        if not first & 0x80:
            if negative:
                result |= -1 << 6
            return self._signed32(result)

        for group in range(1, 4):
            byte = self.read_byte()
            result |= (byte & 0x7F) << (6 + (group - 1) * 7)
            if not byte & 0x80:
                if negative:
                    result |= -1 << (6 + group * 7)
                return self._signed32(result)

        # The native fifth byte is a full byte and bit 31 comes from the
        # sign flag; there is no continuation-bit validation at this point.
        result |= self.read_byte() << 27
        if negative:
            result |= 0x80000000
        return self._signed32(result)

    @staticmethod
    def _signed32(value):
        value &= 0xFFFFFFFF
        return value - 0x100000000 if value & 0x80000000 else value

    def read_short(self, length=2):
        return int.from_bytes(self._read_exact(length), "big")

    def read_int(self, length=4):
        return int.from_bytes(self._read_exact(length), "big")

    def _read_varint(self, rotate: bool = True):
        result = 0
        shift = 0
        while True:
            if shift >= 35:
                raise ValueError("Variable integer is too long")

            byte = self.read_byte()
            if rotate and shift == 0:
                seventh = (byte & 0x40) >> 6
                msb = (byte & 0x80) >> 7
                n = byte << 1
                n = n & ~0x181
                byte = n | (msb << 7) | seventh
            result |= (byte & 0x7F) << shift
            shift += 7
            if not (byte & 0x80):
                break
        return result

    def read_rrsint32(self):
        if self.native_v13:
            return self._read_native_vint()
        n = self._read_varint(True)
        return (n >> 1) ^ (-(n & 1))

    def readScId(self):
        a = self.read_Vint()
        b = self.read_Vint() if a != 0 else -1
        return a, b

    def readLogicLong(self):
        if self.native_v13:
            return self.read_int(), self.read_int()
        return self.read_Vint(), self.read_Vint()

    def read_string(self):
        length = self.read_int()
        if length == 0xFFFFFFFF:
            return ""
        return self._read_exact(length).decode("utf-8")

    def peek_int(self, length=4):
        return int.from_bytes(self.peek(length)[:length], "big")
