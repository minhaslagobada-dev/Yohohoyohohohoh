import json


class Fingerprint:
    def loadFinger(path):
        try:
            with open(path, "r", encoding="utf-8") as finger_file:
                finger_content = json.load(finger_file)
            return finger_content["sha"]
        except Exception as error:
            print(f"Could not load fingerprint: {error}")
            return None

    def loadFinger_full(path):
        try:
            with open(path, "r", encoding="utf-8") as finger_file:
                finger_content = json.load(finger_file)
            return json.dumps(finger_content)
        except Exception as error:
            print(f"Could not load fingerprint: {error}")
            return None
