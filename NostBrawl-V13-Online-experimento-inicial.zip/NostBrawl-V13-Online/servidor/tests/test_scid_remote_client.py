import json
import socket
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from SCIDClient.Remote import RemoteSCIDClient
from SCIDClient.Models import SCIDError


class UnsignedHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        self.rfile.read(int(self.headers.get("Content-Length", 0)))
        body = json.dumps({"ok": True, "account": None, "token": None}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format, *args):
        pass


class RemoteSCIDClientTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.database = str(Path(self.temporary.name) / "players.sqlite")
        self.key = "remote-client-test-key-with-32-bytes"

    def tearDown(self):
        self.temporary.cleanup()

    def settings(self, port):
        return {
            "Database": {"Path": self.database},
            "SCID": {
                "RemoteUrl": f"http://127.0.0.1:{port}",
                "RemoteApiKey": self.key,
                "RemoteTimeoutSeconds": 1,
            },
        }

    def test_unsigned_remote_response_is_rejected(self):
        server = ThreadingHTTPServer(("127.0.0.1", 0), UnsignedHandler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            service = RemoteSCIDClient(self.settings(server.server_port))
            with self.assertRaises(SCIDError) as caught:
                service.token_for_game(1)
            self.assertEqual(caught.exception.code, "scid_integration_rejected")
        finally:
            server.shutdown()
            server.server_close()
            thread.join(5)

    def test_unreachable_remote_service_is_an_explicit_error(self):
        with socket.socket() as listener:
            listener.bind(("127.0.0.1", 0))
            port = listener.getsockname()[1]
        service = RemoteSCIDClient(self.settings(port))
        with self.assertRaises(SCIDError) as caught:
            service.token_for_game(1)
        self.assertEqual(caught.exception.code, "scid_unavailable")

    def test_remote_client_rejects_invalid_url_and_weak_key(self):
        settings = self.settings(25018)
        settings["SCID"]["RemoteUrl"] = "file:///tmp/scid"
        with self.assertRaises(ValueError):
            RemoteSCIDClient(settings)
        settings = self.settings(25018)
        settings["SCID"]["RemoteApiKey"] = "short"
        with self.assertRaises(ValueError):
            RemoteSCIDClient(settings)


if __name__ == "__main__":
    unittest.main()
