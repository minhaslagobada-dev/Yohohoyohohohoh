import os
import socket
import sqlite3
import sys
import tempfile
import unittest
from contextlib import closing
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch


PROJECT_ROOT = Path(__file__).resolve().parents[1]
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from Database.DatabaseManager import DataBase
from Files.CsvLogic.Skins import Skins
from Logic.GameRoomService import GameRoomService
from Logic.Player import Players
from Packets.LogicMessageFactory import packets
from Packets.Messages.Client.Battle.OnPlay import OnPlay
from Packets.Messages.Client.Gameroom.SetInvitesBlockedMessage import SetInvitesBlockedMessage
from Packets.Messages.Client.Gameroom.TeamChangeMemberSettingsMessage import TeamChangeMemberSettingsMessage
from Packets.Messages.Client.Gameroom.TeamChatMessage import TeamChatMessage
from Packets.Messages.Client.Gameroom.TeamCreateMessage import TeamCreateMessage
from Packets.Messages.Client.Gameroom.TeamInvitationResponseMessage import TeamInvitationResponseMessage
from Packets.Messages.Client.Gameroom.TeamInviteMessage import TeamInviteMessage
from Packets.Messages.Client.Gameroom.TeamInviteResponseMessage import TeamInviteResponseMessage
from Packets.Messages.Client.Gameroom.TeamJoinMessage import TeamJoinMessage
from Packets.Messages.Client.Gameroom.TeamKickMessage import TeamKickMessage
from Packets.Messages.Client.Gameroom.TeamLeaveMessage import TeamLeaveMessage
from Packets.Messages.Client.Gameroom.TeamMemberStatusMessage import TeamMemberStatusMessage
from Packets.Messages.Client.Gameroom.TeamPostAdMessage import TeamPostAdMessage
from Packets.Messages.Client.Gameroom.TeamRequestJoinMessage import TeamRequestJoinMessage
from Packets.Messages.Client.Gameroom.TeamSetLocationMessage import TeamSetLocationMessage
from Packets.Messages.Client.Gameroom.TeamSetMemberReadyMessage import TeamSetMemberReadyMessage
from Packets.Messages.Client.Gameroom.TeamSetRankedLocationMessage import TeamSetRankedLocationMessage
from Packets.Messages.Client.Gameroom.TeamSpectateMessage import TeamSpectateMessage
from Packets.Messages.Client.Gameroom.TeamToggleMemberSideMessage import TeamToggleMemberSideMessage
from Packets.Messages.Client.Gameroom.TeamTogglePractiseMessage import TeamTogglePractiseMessage
from Packets.Messages.Client.Home.GoHomeFromOfflinePractiseMessage import GoHomeFromOfflinePractiseMessage
from Packets.Messages.Server.Battle.MatchMakingCancelledMessage import MatchMakingCancelledMessage
from Packets.Messages.Server.Gameroom.SetInvitesBlockedOkMessage import SetInvitesBlockedOkMessage
from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Packets.Messages.Server.Gameroom.TeamInvitationMessage import TeamInvitationMessage
from Packets.Messages.Server.Gameroom.TeamStreamMessage import TeamStreamMessage
from Utils.Reader import BSMessageReader
from Utils.Writer import Writer


def native_writer():
    return Writer(None).enable_native_v13()


def native_reader(payload):
    return BSMessageReader(payload).enable_native_v13()


def read_first_member(payload):
    reader = native_reader(payload)
    reader.read_Vint()
    reader.read_boolean()
    reader.read_Vint()
    reader.read_int()
    reader.read_int()
    reader.read_Vint()
    reader.read_boolean()
    reader.read_boolean()
    reader.read_Vint()
    reader.read_Vint()
    reader.readScId()
    if reader.read_Vint() != 1:
        raise ValueError("O teste exige exatamente um integrante")
    reader.read_boolean()
    reader.read_int()
    reader.read_int()
    reader.read_string()
    reader.read_Vint()
    brawler = reader.readScId()
    skin = reader.readScId()
    trophies = reader.read_Vint()
    highest_trophies = reader.read_Vint()
    power_level = reader.read_Vint()
    return {
        "brawler": brawler,
        "skin": skin,
        "trophies": trophies,
        "highest_trophies": highest_trophies,
        "power_level": power_level,
    }


def receive_exact(connection, length):
    data = bytearray()
    while len(data) < length:
        chunk = connection.recv(length - len(data))
        if not chunk:
            raise ConnectionError("socket fechado")
        data.extend(chunk)
    return bytes(data)


def receive_packet(connection):
    header = receive_exact(connection, 7)
    packet_id = int.from_bytes(header[:2], "big")
    length = int.from_bytes(header[2:5], "big")
    return packet_id, receive_exact(connection, length)


def make_player(low_id, name=None, token=""):
    player = Players(SimpleNamespace())
    player.low_id = low_id
    player.high_id = 0
    player.token = token
    player.name = name or f"Player {low_id}"
    player.room_id = 0
    player.online = 3
    player.brawler_id = 0
    player.skin_id = 0
    player.profile_icon = 7
    player.name_color = 9
    player.brawlers_trophies = {"0": 123}
    player.brawlers_trophies_in_rank = {"0": 234}
    player.Brawler_level = {"0": 4}
    player.brawlers_skins = {"0": 0}
    player.ClientDict = {"ClientCounts": 0, "Clients": {}}
    player.crypto = None
    return player


class GameRoomProtocolTests(unittest.TestCase):
    def setUp(self):
        GameRoomService.init()
        self.addCleanup(GameRoomService.init)

    def test_factory_uses_v13_team_ids(self):
        expected = {
            14350: TeamCreateMessage,
            14351: TeamJoinMessage,
            14352: TeamKickMessage,
            14353: TeamLeaveMessage,
            14356: TeamTogglePractiseMessage,
            14357: TeamToggleMemberSideMessage,
            14358: TeamSpectateMessage,
            14359: TeamChatMessage,
            14360: TeamPostAdMessage,
            14361: TeamMemberStatusMessage,
            14362: TeamSetRankedLocationMessage,
            14363: TeamSetLocationMessage,
            14365: TeamInviteMessage,
            14368: TeamInviteResponseMessage,
            14370: TeamInviteMessage,
            14479: TeamInvitationResponseMessage,
            14777: SetInvitesBlockedMessage,
            14881: TeamRequestJoinMessage,
        }
        for packet_id, message_class in expected.items():
            self.assertIs(packets[packet_id], message_class)

    def test_create_decodes_booleans_and_optional_v13_tail(self):
        writer = native_writer()
        for value in (7, 1, 2):
            writer.writeVint(value)
        writer.writeBoolean(True)
        message = TeamCreateMessage(None, make_player(1), writer.buffer)
        message.decode()
        self.assertEqual(
            (message.map_slot, message.requested_map, message.room_type),
            (1, 7, 2),
        )
        self.assertTrue(message.practice)
        self.assertFalse(message.has_optional_data)
        writer.writeBoolean(False)
        writer.writeString("Equipe")
        writer.writeVint(7)
        writer.writeScId(15, 9)
        with self.assertRaises(ValueError):
            TeamCreateMessage(None, make_player(1), writer.buffer).decode()

    def test_join_kick_ready_location_and_settings_decoders(self):
        writer = native_writer()
        for value in (0, 91, 0):
            writer.writeVint(value)
        writer.writeScId(15, 7)
        join = TeamJoinMessage(None, make_player(1), writer.buffer)
        join.decode()
        self.assertEqual(join.room_id, 91)
        self.assertEqual(join.location, (15, 7))

        writer = native_writer()
        writer.writeVint(0)
        writer.writeVint(77)
        kick = TeamKickMessage(None, make_player(1), writer.buffer)
        kick.decode()
        self.assertEqual((kick.target_high_id, kick.target_id), (0, 77))

        writer = native_writer()
        writer.writeBoolean(True)
        writer.writeVint(4)
        ready = TeamSetMemberReadyMessage(None, make_player(1), writer.buffer)
        ready.decode()
        self.assertTrue(ready.ready)
        self.assertEqual(ready.unknown, 4)

        writer = native_writer()
        writer.writeScId(15, 7)
        location = TeamSetLocationMessage(None, make_player(1), writer.buffer)
        location.decode()
        self.assertEqual(location.location, (15, 7))
        self.assertEqual(location.slot, 0)

        writer = native_writer()
        writer.writeVint(0)
        writer.writeScId(29, 0)
        settings = TeamChangeMemberSettingsMessage(
            None, make_player(1), writer.buffer
        )
        settings.decode()
        self.assertEqual(settings.unknown, 0)
        self.assertEqual(settings.brawler_reference, (0, -1))
        self.assertEqual(settings.skin_reference, (29, 0))

    def test_invite_decoders_use_native_v13_primitives(self):
        writer = native_writer()
        for value in (0, 77, 2):
            writer.writeVint(value)
        invite = TeamInviteMessage(None, make_player(42), writer.buffer)
        invite.decode()
        self.assertEqual(
            (invite.high_id, invite.recipient_id, invite.invite_type),
            (0, 77, 2),
        )

        writer = native_writer()
        writer.writeVint(9)
        writer.writeVint(1)
        response = TeamInviteResponseMessage(None, make_player(77), writer.buffer)
        response.decode()
        self.assertEqual((response.room_id, response.accepted), (9, 1))

        writer = native_writer()
        writer.writeVint(2)
        writer.writeInt(0)
        writer.writeInt(9)
        writer.writeBoolean(True)
        invitation = TeamInvitationResponseMessage(
            None, make_player(77), writer.buffer
        )
        invitation.decode()
        self.assertEqual(invitation.invite_type, 2)
        self.assertEqual((invitation.high_id, invitation.room_id), (0, 9))
        self.assertTrue(invitation.accepted)

    def test_member_status_reads_exactly_one_vint(self):
        writer = native_writer()
        writer.writeVint(5)
        message = TeamMemberStatusMessage(None, make_player(1), writer.buffer)
        message.decode()
        self.assertEqual(message.status, 5)
        writer.writeVint(0)
        writer.writeVint(0)
        with self.assertRaises(ValueError):
            TeamMemberStatusMessage(None, make_player(1), writer.buffer).decode()

    def test_native_logic_long_and_null_data_reference_primitives(self):
        writer = native_writer()
        writer.writeInt(0)
        writer.writeInt(91)
        reader = native_reader(writer.buffer)
        self.assertEqual(reader.readLogicLong(), (0, 91))
        reader.ensure_end()

        writer = native_writer()
        writer.writeScId(0, 77)
        self.assertEqual(writer.buffer, b"\x00")
        reader = native_reader(writer.buffer)
        self.assertEqual(reader.readScId(), (0, -1))
        reader.ensure_end()

        legacy = Writer(None)
        legacy.writeVint(0)
        legacy.writeVint(91)
        reader = BSMessageReader(legacy.buffer)
        self.assertEqual(reader.readLogicLong(), (0, 91))
        reader.ensure_end()

    def test_team_message_matches_member_layout(self):
        owner = make_player(42, "Owner")
        room = GameRoomService.create(owner, 0, 0, 0, True)
        payload = TeamGameroomDataMessage(None, owner, room)._encode_payload()
        expected = bytes.fromhex(
            "00" "01" "06" "00000000" "00000001" "01" "02" "00"
            "00" "0f00" "01" "01" "00000000" "0000002a"
            "00000005" "4f776e6572" "00" "1000" "1d00" "bb01"
            "bb01" "05" "03" "00" "00" "00" "00" "00"
        )
        self.assertEqual(payload, expected)

        reader = native_reader(payload)
        self.assertEqual(reader.read_Vint(), room["type"])
        self.assertTrue(reader.read_boolean())
        self.assertEqual(reader.read_Vint(), 6)
        self.assertEqual((reader.read_int(), reader.read_int()), (0, room["id"]))
        self.assertEqual(reader.read_Vint(), 1)
        self.assertFalse(reader.read_boolean())
        self.assertTrue(reader.read_boolean())
        self.assertEqual(reader.read_Vint(), 0)
        self.assertEqual(reader.read_Vint(), room["slot_index"])
        self.assertEqual(reader.readScId(), (15, room["map_id"]))
        self.assertEqual(reader.read_Vint(), 1)
        self.assertTrue(reader.read_boolean())
        self.assertEqual((reader.read_int(), reader.read_int()), (0, 42))
        self.assertEqual(reader.read_string(), "Owner")
        self.assertEqual(reader.read_Vint(), 0)
        self.assertEqual(reader.readScId(), (16, 0))
        self.assertEqual(reader.readScId(), (29, 0))
        self.assertEqual(reader.read_Vint(), 123)
        self.assertEqual(reader.read_Vint(), 123)
        self.assertEqual(reader.read_Vint(), 5)
        self.assertEqual(room["members"][0]["power_level"], 4)
        self.assertEqual(reader.read_Vint(), 3)
        self.assertFalse(reader.read_boolean())
        self.assertEqual(reader.read_Vint(), 0)
        self.assertEqual(reader.read_Vint(), 0)
        self.assertEqual(reader.read_Vint(), 0)
        self.assertEqual(reader.read_Vint(), 0)
        reader.ensure_end()

    def test_room_wire_uses_real_power_and_skin_saved_per_brawler(self):
        owner = make_player(42)
        owner.Brawler_level = {"0": 0}
        owner.brawlers_skins = {"0": 29}
        owner.skin_id = 0
        room = GameRoomService.create(owner, 0, 0, 0, True)
        payload = TeamGameroomDataMessage(None, owner, room)._encode_payload()
        member = read_first_member(payload)
        self.assertEqual(member["brawler"], (16, 0))
        self.assertEqual(member["skin"], (29, 29))
        self.assertEqual(member["power_level"], 1)
        self.assertEqual(room["members"][0]["power_level"], 0)
        self.assertEqual(owner.skin_id, 0)
        self.assertEqual(owner.brawlers_skins["0"], 29)

    def test_room_resolves_default_skin_and_keeps_global_skin_fallback(self):
        owner = make_player(42)
        owner.brawler_id = 1
        owner.skin_id = 0
        owner.brawlers_skins = {"1": 0}
        owner.Brawler_level = {"1": 8}
        owner.brawlers_trophies = {"1": 50}
        room = GameRoomService.create(owner, 0, 0, 0, True)
        self.assertEqual(
            room["members"][0]["skin_id"], Skins.get_default_skin(1)
        )
        payload = TeamGameroomDataMessage(None, owner, room)._encode_payload()
        self.assertEqual(read_first_member(payload)["power_level"], 9)

        fallback = make_player(43)
        fallback.skin_id = 29
        fallback.brawlers_skins = {"0": 0}
        fallback_room = GameRoomService.create(fallback, 0, 0, 0, True)
        self.assertEqual(fallback_room["members"][0]["skin_id"], 29)

    def test_room_skin_change_stays_selected_when_creating_another_room(self):
        owner = make_player(42)
        owner.brawlers_skins = {"0": 0}
        GameRoomService.create(owner, 0, 0, 0, True)
        server, client = socket.socketpair()
        self.addCleanup(server.close)
        self.addCleanup(client.close)
        writer = native_writer()
        writer.writeVint(0)
        writer.writeScId(29, 29)
        message = TeamChangeMemberSettingsMessage(client, owner, writer.buffer)
        message.decode()
        with patch.object(DataBase, "replaceValue", return_value=True) as update:
            changed = message.process()
        self.assertEqual(changed["members"][0]["skin_id"], 29)
        self.assertEqual(owner.brawlers_skins["0"], 29)
        update.assert_any_call(message, "brawlersSkins", {"0": 29})
        self.assertEqual(receive_packet(server)[0], 24124)

        GameRoomService.leave(owner)
        recreated = GameRoomService.create(owner, 0, 0, 0, True)
        self.assertEqual(recreated["members"][0]["skin_id"], 29)

    def test_team_message_matches_native_invite_and_request_layouts(self):
        owner = make_player(42, "Owner")
        room = GameRoomService.create(owner, 0, 0, 0)
        room["members"] = []
        room["invites"] = [{
            "sender_id": 1000, "recipient_id": 2000,
            "name": "Convidado", "invite_type": 2, "status": 0,
        }]
        room["join_requests"] = [{
            "player_id": 2000,
            "entry": {
                "high_id": 1, "low_id": 3000, "name": "Solicitante",
                "facebook_id": "fb", "game_center_id": "gc",
                "state": 4, "trophies": 500, "profile_icon": 28000007,
                "club": {"id": 9, "name": "Clube"},
            },
        }]
        payload = TeamGameroomDataMessage(None, owner, room)._encode_payload()
        reader = native_reader(payload)
        self.assertEqual(reader.read_Vint(), 0)
        self.assertFalse(reader.read_boolean())
        self.assertEqual(reader.read_Vint(), 6)
        self.assertEqual((reader.read_int(), reader.read_int()), (0, room["id"]))
        self.assertEqual(reader.read_Vint(), 1)
        self.assertFalse(reader.read_boolean())
        self.assertTrue(reader.read_boolean())
        self.assertEqual(reader.read_Vint(), 0)
        self.assertEqual(reader.read_Vint(), 0)
        self.assertEqual(reader.readScId(), (15, 0))
        self.assertEqual(reader.read_Vint(), 0)

        self.assertEqual(reader.read_Vint(), 1)
        self.assertEqual((reader.read_int(), reader.read_int()), (0, 1000))
        self.assertEqual((reader.read_int(), reader.read_int()), (0, 2000))
        self.assertEqual(reader.read_string(), "Convidado")
        self.assertEqual(reader.read_Vint(), 2)
        self.assertEqual(reader.read_Vint(), 0)

        self.assertEqual(reader.read_Vint(), 1)
        self.assertEqual((reader.read_int(), reader.read_int()), (0, room["id"]))
        self.assertEqual((reader.read_int(), reader.read_int()), (0, 2000))
        self.assertEqual((reader.read_int(), reader.read_int()), (1, 3000))
        self.assertEqual(reader.read_string(), "Solicitante")
        self.assertEqual(reader.read_string(), "fb")
        self.assertEqual(reader.read_string(), "gc")
        self.assertEqual(reader.read_string(), "")
        self.assertEqual(reader.read_int(), 0)
        self.assertEqual(reader.read_int(), 500)
        self.assertEqual(reader.read_int(), 4)
        self.assertEqual([reader.read_int() for _ in range(3)], [0, 0, 0])
        self.assertTrue(reader.read_boolean())
        self.assertEqual((reader.read_int(), reader.read_int()), (0, 9))
        self.assertEqual(reader.read_int(), 0)
        self.assertEqual(reader.read_string(), "Clube")
        self.assertEqual(reader.read_int(), 0)
        self.assertEqual(reader.read_int(), 0)
        self.assertEqual(reader.read_string(), "")
        self.assertEqual(reader.read_int(), 28000007)
        self.assertEqual(reader.read_int(), 0)
        reader.ensure_end()

    def test_team_stream_encodes_events_and_chat(self):
        entries = [
            {
                "kind": 4, "event": 101, "id": 1, "room_id": 7,
                "player_id": 42, "player_name": "Owner", "player_role": 0,
                "target_id": 42, "target_name": "Owner", "created_at": 100,
            },
            {
                "kind": 2, "id": 2, "room_id": 7, "player_id": 42,
                "player_name": "Owner", "player_role": 0,
                "message": "oi", "created_at": 100,
            },
        ]
        message = TeamStreamMessage(None, make_player(42), {"id": 7}, entries)
        with patch(
            "Packets.Messages.Server.Gameroom.TeamStreamMessage.time.time",
            return_value=110,
        ):
            payload = message._encode_payload()
        reader = native_reader(payload)
        self.assertEqual([reader.read_Vint() for _ in range(3)], [0, 7, 2])
        self.assertEqual(reader.read_Vint(), 4)
        self.assertEqual([reader.read_Vint() for _ in range(4)], [0, 1, 0, 42])
        self.assertEqual(reader.read_string(), "Owner")
        self.assertEqual([reader.read_Vint() for _ in range(2)], [0, 10])
        self.assertFalse(reader.read_boolean())
        self.assertEqual(reader.read_Vint(), 101)
        self.assertTrue(reader.read_boolean())
        self.assertEqual([reader.read_Vint() for _ in range(2)], [0, 42])
        self.assertEqual(reader.read_string(), "Owner")
        self.assertEqual(reader.read_Vint(), 2)
        self.assertEqual([reader.read_Vint() for _ in range(4)], [0, 2, 0, 42])
        self.assertEqual(reader.read_string(), "Owner")
        self.assertEqual([reader.read_Vint() for _ in range(2)], [0, 10])
        self.assertFalse(reader.read_boolean())
        self.assertEqual(reader.read_string(), "oi")
        reader.ensure_end()

    def test_ready_uses_legacy_on_play_server_flow_without_server_battle(self):
        owner = make_player(42)
        created = GameRoomService.create(owner, 1, 0, 0)
        server, client = socket.socketpair()
        self.addCleanup(server.close)
        self.addCleanup(client.close)

        def ready(value=True):
            writer = native_writer()
            writer.writeBoolean(value)
            writer.writeVint(0)
            message = TeamSetMemberReadyMessage(client, owner, writer.buffer)
            message.decode()
            return message.process()

        def expect_cancelled():
            self.assertEqual(receive_packet(server), (20406, b""))
            self.assertEqual((owner.map_id, owner.mmplayers), (15, 1))

        with patch("Logic.Battle.Battle.Battle.start") as battle_start, \
             patch(
                 "Packets.Messages.Server.Battle.StartLoadingMessage."
                 "StartLoadingMessage.send"
             ) as start_loading:
            room = ready()
            self.assertTrue(room["members"][0]["ready"])
            self.assertEqual(receive_packet(server)[0], 24124)
            expect_cancelled()

            room = ready(False)
            self.assertFalse(room["members"][0]["ready"])
            self.assertEqual(receive_packet(server)[0], 24124)
            server.settimeout(0.05)
            with self.assertRaises(TimeoutError):
                receive_packet(server)
            server.settimeout(1)

            ready()
            self.assertEqual(receive_packet(server)[0], 24124)
            expect_cancelled()
        battle_start.assert_not_called()
        start_loading.assert_not_called()
        server.settimeout(0.05)
        with self.assertRaises(TimeoutError):
            receive_packet(server)

    def test_create_and_join_send_team_data_and_stream(self):
        owner = make_player(42)
        server, client = socket.socketpair()
        self.addCleanup(server.close)
        self.addCleanup(client.close)
        writer = native_writer()
        for value in (1, 0, 0):
            writer.writeVint(value)
        writer.writeBoolean(False)
        create = TeamCreateMessage(client, owner, writer.buffer)
        create.decode()
        room = create.process()
        self.assertEqual(receive_packet(server)[0], 24124)
        self.assertEqual(receive_packet(server)[0], 24131)

        guest = make_player(77)
        join_server, join_client = socket.socketpair()
        self.addCleanup(join_server.close)
        self.addCleanup(join_client.close)
        writer = native_writer()
        for value in (0, room["id"], 0):
            writer.writeVint(value)
        writer.writeScId(15, 0)
        join = TeamJoinMessage(join_client, guest, writer.buffer)
        join.decode()
        join.process()
        self.assertEqual(receive_packet(join_server)[0], 24124)
        self.assertEqual(receive_packet(join_server)[0], 24131)

    def test_invites_blocked_uses_boolean_and_command_213(self):
        player = make_player(42)
        server, client = socket.socketpair()
        self.addCleanup(server.close)
        self.addCleanup(client.close)
        with patch.object(DataBase, "replaceValue", return_value=True):
            message = SetInvitesBlockedMessage(client, player, b"\x01")
            message.decode()
            self.assertTrue(message.process())
        packet_id, payload = receive_packet(server)
        self.assertEqual(packet_id, 24111)
        reader = native_reader(payload)
        self.assertEqual(reader.read_Vint(), 213)
        self.assertTrue(reader.read_boolean())
        reader.ensure_end()
        self.assertEqual(player.do_not_distrub, 1)
        confirmation = SetInvitesBlockedOkMessage(None, player)._encode_payload()
        self.assertEqual(native_reader(confirmation).read_Vint(), 213)


class GameRoomFlowTests(unittest.TestCase):
    def setUp(self):
        GameRoomService.init()
        self.addCleanup(GameRoomService.init)

    def test_complete_v17_create_join_chat_ready_kick_and_leave_flow(self):
        owner = make_player(42, "Owner")
        guest = make_player(77, "Guest")
        room = GameRoomService.create(owner, 1, 0, 0)
        self.assertEqual(GameRoomService.stream(room["id"])[0]["event"], 101)
        joined = GameRoomService.join(guest, room["id"])
        self.assertEqual(joined["player_count"], 2)
        self.assertEqual(len(GameRoomService.stream(room["id"])), 2)
        _, chat = GameRoomService.add_chat(guest, "Olá")
        self.assertEqual(chat["message"], "Olá")
        self.assertTrue(GameRoomService.set_ready(owner, True)["members"][0]["ready"])
        self.assertTrue(GameRoomService.set_ready(guest, True)["members"][1]["ready"])
        self.assertEqual(GameRoomService.set_status(guest, 5)["members"][1]["status"], 5)
        self.assertEqual(GameRoomService.set_member_settings(guest, 0, 0)["player_count"], 2)
        remaining, kicked = GameRoomService.kick(guest, 42)
        self.assertEqual(kicked, 42)
        self.assertEqual(remaining["player_count"], 1)
        self.assertEqual(remaining["members"][0]["low_id"], 77)
        self.assertTrue(remaining["members"][0]["host"])
        self.assertEqual(owner.room_id, 0)
        self.assertEqual(GameRoomService.stream(room["id"])[-1]["event"], 104)
        empty, departed = GameRoomService.leave(guest)
        self.assertTrue(departed)
        self.assertIsNone(empty)
        self.assertEqual(guest.room_id, 0)
        self.assertIsNone(GameRoomService.get(room["id"]))
        self.assertEqual(GameRoomService.stream(room["id"]), [])
        self.assertEqual(GameRoomService.count(), 0)

    def test_invite_accept_and_clear_use_real_account_state(self):
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "players.db")
            resolved = str(Path(path).resolve())
            self.addCleanup(DataBase._initialized_paths.discard, resolved)
            with patch.object(DataBase, "_database_path", lambda: path):
                owner = make_player(42, "Owner", token="invite-owner")
                guest = make_player(77, "Guest", token="invite-guest")
                DataBase.createAccount(SimpleNamespace(player=owner))
                DataBase.createAccount(SimpleNamespace(player=guest))
                room = GameRoomService.create(owner, 1, 0, 0)
                room, invite = GameRoomService.invite(owner, 77, 2)
                self.assertEqual(len(room["invites"]), 1)
                self.assertEqual(invite["recipient_id"], 77)
                self.assertEqual(invite["entry"]["low_id"], 42)

                payload = TeamInvitationMessage(None, owner, invite)._encode_payload()
                reader = native_reader(payload)
                self.assertEqual(reader.read_Vint(), 2)
                self.assertEqual(
                    (reader.read_int(), reader.read_int()), (0, room["id"])
                )
                entry = invite["entry"]
                self.assertEqual((reader.read_int(), reader.read_int()), (0, 42))
                self.assertEqual(reader.read_string(), "Owner")
                self.assertEqual(reader.read_string(), "")
                self.assertEqual(reader.read_string(), "")
                self.assertEqual(reader.read_string(), "")
                self.assertEqual(reader.read_int(), entry["status"])
                self.assertEqual(reader.read_int(), entry["trophies"])
                self.assertEqual(reader.read_int(), entry["state"])
                self.assertEqual(reader.read_int(), entry["origin"])
                self.assertEqual([reader.read_int() for _ in range(2)], [0, 0])
                self.assertFalse(reader.read_boolean())
                self.assertEqual(reader.read_string(), "")
                self.assertEqual(reader.read_int(), entry["profile_icon"])
                self.assertEqual(reader.read_int(), 0)
                reader.ensure_end()

                accepted, accepted_invite = GameRoomService.accept_invite(
                    guest, room["id"]
                )
                self.assertEqual(accepted["player_count"], 2)
                self.assertEqual(accepted["invites"], [])
                self.assertEqual(accepted_invite["sender_id"], 42)
                self.assertEqual(guest.room_id, room["id"])

                room, invite = GameRoomService.invite(owner, 77, 2)
                self.assertEqual(len(room["invites"]), 1)
                cleared, cleared_invite = GameRoomService.clear_invite(
                    guest, room["id"]
                )
                self.assertEqual(cleared["player_count"], 2)
                self.assertEqual(cleared["invites"], [])
                self.assertEqual(cleared_invite["recipient_id"], 77)

    def test_v17_has_no_capacity_check_and_create_always_adds_a_room(self):
        owner = make_player(42)
        first = GameRoomService.create(owner, 1, 0, 0)
        second = GameRoomService.create(owner, 1, 0, 0)
        self.assertEqual((first["id"], second["id"]), (1, 2))
        self.assertEqual(GameRoomService.get(first["id"])["player_count"], 1)
        for low_id in range(100, 113):
            joined = GameRoomService.join(make_player(low_id), second["id"])
            self.assertIsNotNone(joined)
        self.assertEqual(joined["player_count"], 14)

    def test_room_ids_are_not_reused_while_another_room_is_active(self):
        first_owner = make_player(42)
        second_owner = make_player(77)
        third_owner = make_player(99)
        first = GameRoomService.create(first_owner, 1, 0, 0)
        second = GameRoomService.create(second_owner, 1, 0, 0)
        GameRoomService.leave(first_owner)
        third = GameRoomService.create(third_owner, 1, 0, 0)
        self.assertEqual((first["id"], second["id"], third["id"]), (1, 2, 3))
        self.assertEqual(GameRoomService.get(second["id"])["owner_id"], 77)
        self.assertEqual(GameRoomService.count(), 2)

    def test_go_home_preserves_room_and_sends_only_home_data(self):
        owner = make_player(42, "Owner")
        guest = make_player(77, "Guest")
        room = GameRoomService.create(owner, 1, 0, 0)
        GameRoomService.join(guest, room["id"])
        server, client = socket.socketpair()
        self.addCleanup(server.close)
        self.addCleanup(client.close)
        message = GoHomeFromOfflinePractiseMessage(client, guest, b"\x01")
        message.decode()
        with patch(
            "Logic.GameRoomGateway.GameRoomGateway.broadcast_data_and_stream"
        ) as broadcast, patch(
            "Packets.Messages.Server.Gameroom.TeamLeaveOkMessage."
            "TeamLeaveOkMessage.send"
        ) as leave, patch(
            "Packets.Messages.Client.Home.GoHomeFromOfflinePractiseMessage."
            "OwnHomeDataMessage.send"
        ) as home:
            result = message.process()
        self.assertIsNone(result)
        remaining = GameRoomService.get(room["id"])
        self.assertEqual(remaining["player_count"], 2)
        self.assertEqual(
            [member["low_id"] for member in remaining["members"]], [42, 77]
        )
        self.assertEqual((owner.room_id, guest.room_id), (room["id"], room["id"]))
        self.assertEqual(len(GameRoomService.stream(room["id"])), 2)
        broadcast.assert_not_called()
        leave.assert_not_called()
        home.assert_called_once()
        server.settimeout(0.05)
        with self.assertRaises(TimeoutError):
            receive_packet(server)

    def test_go_home_outside_room_sends_only_home_data(self):
        player = make_player(42)
        message = GoHomeFromOfflinePractiseMessage(None, player, b"\x01")
        message.decode()
        with patch(
            "Packets.Messages.Server.Gameroom.TeamLeaveOkMessage."
            "TeamLeaveOkMessage.send"
        ) as leave, patch(
            "Packets.Messages.Client.Home.GoHomeFromOfflinePractiseMessage."
            "OwnHomeDataMessage.send"
        ) as home:
            remaining = message.process()
        self.assertIsNone(remaining)
        self.assertEqual(player.room_id, 0)
        leave.assert_not_called()
        home.assert_called_once()

    def test_login_resume_only_restores_room_data(self):
        owner = make_player(42)
        guest = make_player(77)
        room = GameRoomService.create(owner, 1, 0, 0)
        GameRoomService.join(guest, room["id"])
        offline = GameRoomService.disconnect(owner)
        self.assertEqual(offline["members"][0]["status"], 0)
        replacement = make_player(42, "Owner")
        replacement.room_id = room["id"]
        resumed = GameRoomService.resume(replacement)
        self.assertEqual(resumed["members"][0]["status"], 3)
        self.assertEqual(resumed["player_count"], 2)
        self.assertEqual(len(GameRoomService.stream(room["id"])), 2)

    def test_v17_on_play_creates_room_without_changing_legacy_on_play(self):
        player = make_player(42)
        message = OnPlay(None, player, b"\x01\x00\x00")
        message.decode()
        self.assertTrue(message.v17_layout)
        with patch("Logic.GameRoomGateway.GameRoomGateway.deliver_data") as deliver, \
             patch.object(MatchMakingCancelledMessage, "send") as cancelled:
            room = message.process()
        self.assertIsNotNone(room)
        self.assertEqual(player.room_id, room["id"])
        deliver.assert_called_once()
        cancelled.assert_called_once()

    def test_room_id_is_persisted_and_reloaded(self):
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "players.db")
            resolved = str(Path(path).resolve())
            self.addCleanup(DataBase._initialized_paths.discard, resolved)
            with patch.object(DataBase, "_database_path", lambda: path):
                owner = make_player(42, token="room-token")
                DataBase.createAccount(SimpleNamespace(player=owner))
                room = GameRoomService.create(owner, 1, 0, 0)
                loaded = make_player(42, token="room-token")
                self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=loaded)))
                self.assertEqual(loaded.room_id, room["id"])
                GameRoomService.for_player(loaded)
                GameRoomService.leave(loaded)
                reloaded = make_player(42, token="room-token")
                self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=reloaded)))
                self.assertEqual(reloaded.room_id, 0)

    def test_r90_database_gains_room_id_without_losing_account_data(self):
        with tempfile.TemporaryDirectory() as directory:
            path = str(Path(directory) / "players.db")
            schema = DataBase.PLAYER_SCHEMA.replace(
                "            online INTEGER NOT NULL DEFAULT 0,\n"
                "            roomID INTEGER NOT NULL DEFAULT 0",
                "            online INTEGER NOT NULL DEFAULT 0",
            )
            with closing(sqlite3.connect(path)) as connection:
                connection.executescript(schema)
                connection.execute(
                    "INSERT INTO players(token, name, lowID, gold) VALUES (?,?,?,?)",
                    ("legacy-r90", "Legacy", 42, 987),
                )
                connection.commit()
            resolved = str(Path(path).resolve())
            self.addCleanup(DataBase._initialized_paths.discard, resolved)
            with patch.object(DataBase, "_database_path", lambda: path):
                player = make_player(42, token="legacy-r90")
                self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=player)))
                self.assertEqual((player.gold, player.room_id), (987, 0))
                with closing(sqlite3.connect(path)) as connection:
                    columns = [
                        row[1] for row in connection.execute("PRAGMA table_info(players)")
                    ]
                    self.assertEqual(columns, list(DataBase.PLAYER_STORAGE_COLUMNS))
                    self.assertIn("roomID", columns)
                    self.assertEqual(
                        connection.execute("PRAGMA integrity_check").fetchone()[0],
                        "ok",
                    )
                    self.assertEqual(
                        connection.execute("PRAGMA foreign_key_check").fetchall(), []
                    )


if __name__ == "__main__":
    unittest.main(verbosity=2)
