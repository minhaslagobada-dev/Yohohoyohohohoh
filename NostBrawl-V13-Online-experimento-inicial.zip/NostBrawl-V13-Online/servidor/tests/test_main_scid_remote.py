import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from main import Server
from SCIDClient.Remote import RemoteSCIDClient
from SCIDClient.Runtime import get_service, set_service
from Utils.Config import Config


PROJECT_ROOT = Path(__file__).resolve().parents[1]


class MainSCIDRemoteTests(unittest.TestCase):
    def test_main_starts_only_remote_client(self):
        with tempfile.TemporaryDirectory() as temporary:
            settings = json.loads((PROJECT_ROOT / "config.json").read_text())
            settings["Database"]["Path"] = str(Path(temporary) / "players.sqlite")
            settings["SCID"].update({
                "RemoteUrl": "http://127.0.0.1:25018",
                "RemoteApiKey": "main-remote-test-key-with-32-bytes",
                "RemoteTimeoutSeconds": 3,
            })
            server = Server(ip="127.0.0.1", port=0)
            try:
                with patch.object(Config, "GetValue", return_value=settings):
                    result = server.start_scid()
                self.assertIsNone(result)
                self.assertFalse(hasattr(server, "scid_server"))
                self.assertIsInstance(server.scid_client, RemoteSCIDClient)
                self.assertIs(get_service(), server.scid_client)
                server.stop_scid()
                self.assertIsNone(get_service())
                self.assertIsNone(server.scid_client)
            finally:
                server.stop_scid()
                server.server.close()
                set_service(None)


if __name__ == "__main__":
    unittest.main()
