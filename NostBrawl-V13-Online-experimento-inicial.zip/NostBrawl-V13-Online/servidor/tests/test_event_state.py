import copy
import tempfile
import unittest
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from Database.DatabaseManager import DataBase
from Logic.EventRotation import EventError, EventRotation
from Logic.EventSlots import EventSlots
from Logic.Player import Players
from Packets.LogicCommandManager import EndClientTurn
from Packets.Messages.Server.Home.OwnHomeDataMessage import OwnHomeDataMessage
from Utils.Writer import Writer
from tests.test_battle_end import CaptureClient
from tests.test_own_home_data_wire import OwnHomeDataReader


def read_event_statuses(payload):
    reader = OwnHomeDataReader(payload)
    for _ in range(2):
        reader.v()
    for _ in range(5):
        reader.v()
    for _ in range(3):
        reader.v()
    reader.references()
    reader.references()
    reader.b()
    for _ in range(6):
        reader.v()
    reader.b()
    reader.v()
    reader.b()
    for _ in range(2):
        reader.v()
    for _ in range(4):
        reader.b()
    for _ in range(3):
        reader.v()
    reader.b()
    for _ in range(reader.v()):
        for _ in range(reader.v()):
            reader.v()
            reader.v()
            target_class = reader.v()
            if target_class:
                reader.v()
            reader.v()
        for _ in range(5):
            reader.v()
        reader.b()
        reader.v()
        reader.b()
        reader.v()
        reader.s()
    for _ in range(6):
        reader.v()
    reader.v()
    reader.v()
    for _ in range(12):
        reader.v()
    reader.array()
    reader.array()
    statuses = []
    for _ in range(reader.v()):
        values = [reader.v() for _ in range(8)]
        statuses.append(values[7])
        reader.s()
        reader.v()
        reader.array()
        reader.v()
    return statuses


class EventStateTests(unittest.TestCase):
    def setUp(self):
        self.temp_directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp_directory.cleanup)
        self.database_path = str(Path(self.temp_directory.name) / "players.db")
        path_patch = patch.object(DataBase, "_database_path", lambda: self.database_path)
        path_patch.start()
        self.addCleanup(path_patch.stop)
        self.now = datetime(2026, 10, 26, 12, 0, 0)
        self.player = Players(SimpleNamespace())
        self.player.low_id = 1
        self.player.high_id = 0
        self.player.token = "event-state-token"
        DataBase.createAccount(SimpleNamespace(player=self.player))
        DataBase.replaceValues(SimpleNamespace(player=self.player), {"brawlBoxes": 0})
        self.player.brawl_boxes = 0

    @contextmanager
    def clock(self):
        with patch("Logic.EventRotation.datetime") as clock:
            clock.now.return_value = self.now
            clock.combine.side_effect = datetime.combine
            clock.strptime.side_effect = datetime.strptime
            yield

    def turn(self, commands):
        writer = Writer(None)
        for value in (0, 1, 0, len(commands)):
            writer.writeVint(value)
        for event_index, state in commands:
            for value in (503, 0, 0, 0, 0, event_index, state):
                writer.writeVint(value)
        message = EndClientTurn(CaptureClient(), self.player, writer.buffer)
        message.decode()
        return message

    def reload(self):
        player = Players(SimpleNamespace())
        player.token = self.player.token
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=player)))
        return player

    def test_multiple_503_commands_consume_base_index_and_state_exactly(self):
        message = self.turn(((1, 1), (2, 3)))
        with self.clock():
            message.process()
            statuses = [event["status"] for event in EventRotation.snapshot(self.player)]
        self.assertEqual(message.command_ids, [503, 503])
        self.assertEqual(message.tell(), len(message.initial_bytes))
        self.assertEqual(statuses[:2], [1, 3])
        self.assertEqual(self.player.brawl_boxes, 0)
        self.assertEqual(EventRotation.claimed_slots(self.player, self.now), set())

    def test_only_state_two_grants_and_replay_is_persistent(self):
        with self.clock():
            first = EventRotation.apply_state(self.player, 1, 2)
            replay = EventRotation.apply_state(self.player, 1, 2)
            restored = self.reload()
            status = EventRotation.snapshot(restored)[0]["status"]
        self.assertTrue(first["claimed"])
        self.assertFalse(replay["claimed"])
        self.assertEqual((first["balance"], replay["balance"]), (10, 10))
        self.assertEqual(restored.brawl_boxes, 10)
        self.assertEqual(status, 2)

    def test_viewed_state_survives_reload_restart_and_home_encoding(self):
        with self.clock():
            EventRotation.apply_state(self.player, 1, 3)
            DataBase._initialized_paths.discard(str(Path(self.database_path).resolve()))
            restored = self.reload()
            self.assertEqual(EventRotation.snapshot(restored)[0]["status"], 3)
            message = OwnHomeDataMessage(None, restored)
            with patch.object(EventSlots, "Timer", lambda self: 49020):
                message.encode()
        self.assertEqual(read_event_statuses(message.buffer)[:2], [3, 1])
        self.assertEqual(restored.brawl_boxes, 0)

    def test_updated_event_becomes_new_without_erasing_claim_history(self):
        with self.clock():
            EventRotation.apply_state(self.player, 1, 2)
            EventRotation.apply_state(self.player, 1, 3)
            updated = copy.deepcopy(EventRotation.events(self.now))
            updated[0]["map_id"] = next(
                value for value in EventRotation.SLOT_POOLS[0][1]
                if value != updated[0]["map_id"]
            )
            with patch.object(EventRotation, "events", return_value=updated):
                snapshot = EventRotation.snapshot(self.player, self.now)
        self.assertEqual(snapshot[0]["status"], 1)
        self.assertTrue(snapshot[0]["claimed"])
        self.assertEqual(self.player.brawl_boxes, 10)

    def test_secondary_modifier_update_marks_viewed_event_new(self):
        initial = copy.deepcopy(EventRotation.events(self.now))
        initial[0]["modifier"] = 1
        initial[0]["modifiers"] = (1,)
        with patch.object(EventRotation, "events", return_value=initial):
            with self.clock():
                EventRotation.apply_state(self.player, 1, 3)
                self.assertEqual(EventRotation.snapshot(self.player)[0]["status"], 3)

        updated = copy.deepcopy(initial)
        updated[0]["modifiers"] = (1, 3)
        with patch.object(EventRotation, "events", return_value=updated):
            with self.clock():
                event = EventRotation.snapshot(self.player)[0]
        self.assertEqual(event["status"], 1)
        self.assertFalse(event["claimed"])
        self.assertEqual(self.player.brawl_boxes, 0)

    def test_new_day_after_view_is_new_again_and_claim_is_per_date(self):
        first_day = datetime(2026, 10, 26, 12, 0, 0)
        second_day = datetime(2026, 10, 27, 12, 0, 0)

        self.now = first_day
        with self.clock():
            self.assertTrue(EventRotation.apply_state(self.player, 1, 2)["claimed"])
            EventRotation.apply_state(self.player, 1, 3)
            home = OwnHomeDataMessage(None, self.player)._encode_payload()
            self.assertEqual(read_event_statuses(home), [3, 1, 1, 1, 1])

        restored = self.reload()
        self.player = restored
        self.now = second_day
        with self.clock():
            home = OwnHomeDataMessage(None, restored)._encode_payload()
            self.assertEqual(read_event_statuses(home), [1, 1, 1, 1, 1])
            self.assertFalse(EventRotation.apply_state(restored, 1, 3)["claimed"])
            self.assertEqual(restored.brawl_boxes, 10)
            self.assertTrue(EventRotation.apply_state(restored, 1, 2)["claimed"])
            self.assertFalse(EventRotation.apply_state(restored, 1, 2)["claimed"])
            self.assertEqual(restored.brawl_boxes, 20)

        reloaded = self.reload()
        self.assertEqual(reloaded.brawl_boxes, 20)
        with self.clock():
            home = OwnHomeDataMessage(None, reloaded)._encode_payload()
            self.assertEqual(read_event_statuses(home), [2, 1, 1, 1, 1])

    def test_invalid_state_does_not_change_balance_or_visible_state(self):
        with self.clock():
            for slot, state in ((0, 3), (6, 3), (1, 0), (1, 4), (1, -1)):
                with self.assertRaises(EventError):
                    EventRotation.apply_state(self.player, slot, state)
            self.assertEqual(
                [event["status"] for event in EventRotation.snapshot(self.player)],
                [1, 1, 1, 1, 1],
            )
        self.assertEqual(self.player.brawl_boxes, 0)
        self.assertEqual(self.reload().brawl_boxes, 0)
