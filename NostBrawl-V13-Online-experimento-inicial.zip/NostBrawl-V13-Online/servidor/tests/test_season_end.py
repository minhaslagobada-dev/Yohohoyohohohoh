import os
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

PROJECT_ROOT = Path(__file__).resolve().parents[1]
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from Database.DatabaseManager import DataBase
from Logic.EventSlots import EventSlots
from Logic.NotificationFactory import NotificationFactory
from Logic.Player import Players
from Logic.SeasonService import SeasonService
from Packets.LogicCommandManager import EndClientTurn
from Packets.Messages.Server.Home.OwnHomeDataMessage import OwnHomeDataMessage
from Utils.Reader import BSMessageReader
from Utils.Writer import Writer

NOW = 1700000000
DURATION = 1209600


class CaptureClient:
    def __init__(self):
        self.packets = []

    def sendall(self, data):
        self.packets.append(bytes(data))


class FakeTimer:
    instances = []

    def __init__(self, delay, callback, args=()):
        self.delay = delay
        self.callback = callback
        self.args = args
        self.daemon = False
        self.started = False
        self.cancelled = False
        self.__class__.instances.append(self)

    def start(self):
        self.started = True

    def cancel(self):
        self.cancelled = True

    def fire(self):
        self.callback(*self.args)


def vint(value):
    writer = Writer(None)
    writer.writeVint(value)
    return writer.buffer


def view_payload(notification_index):
    writer = Writer(None)
    for value in (0, 0, 0, 1, 528, 0, 0, 0, 0, notification_index):
        writer.writeVint(value)
    return writer.buffer


def delete_payload(action=1):
    writer = Writer(None)
    for value in (0, 137, 0, 1, 514, 136, 136, -64, -64, action):
        writer.writeVint(value)
    return writer.buffer + b"\xff" * 4


class HomeReader(BSMessageReader):
    def __init__(self, payload):
        super().__init__(payload)
        self.bit_index = 0
        self.bit_byte = 0

    def v(self):
        self.bit_index = 0
        return self.read_Vint()

    def b(self):
        if self.bit_index == 0:
            self.bit_byte = self.read_byte()
        value = bool(self.bit_byte & (1 << self.bit_index))
        self.bit_index = (self.bit_index + 1) & 7
        return value

    def references(self):
        return [(self.v(), self.v()) for _ in range(self.v())]


def read_season_timer(payload):
    reader = HomeReader(payload)
    for _ in range(7):
        reader.v()
    reader.v()
    reader.v()
    reader.v()
    reader.references()
    reader.references()
    reader.b()
    for _ in range(6):
        reader.v()
    reader.b()
    reader.v()
    reader.b()
    reader.v()
    return reader.v()


class SeasonEndTests(unittest.TestCase):
    def setUp(self):
        self.temp_directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp_directory.cleanup)
        self.database_path = str(Path(self.temp_directory.name) / "players.db")
        path_patch = patch.object(DataBase, "_database_path", lambda: self.database_path)
        path_patch.start()
        self.addCleanup(path_patch.stop)
        time_patch = patch("Logic.SeasonService.time.time", return_value=NOW)
        time_patch.start()
        self.addCleanup(time_patch.stop)
        shop_patch = patch(
            "Packets.Messages.Server.Home.OwnHomeDataMessage.ShopService.encode_home",
            lambda writer, player: writer.v(0),
        )
        shop_patch.start()
        self.addCleanup(shop_patch.stop)

        self.player = Players(SimpleNamespace())
        self.player.low_id = 42
        self.player.high_id = 0x01020304
        self.player.token = "season-token"
        self.player.name = "Season"
        self.player.trophies = 3300
        self.player.highest_trophies = 3300
        self.player.brawl_boxes = 0
        self.player.big_boxes = 0
        for key in self.player.brawlers_trophies:
            self.player.brawlers_trophies[key] = 0
        self.player.brawlers_trophies["0"] = 600
        self.player.brawlers_trophies["1"] = 501
        self.player.brawlers_trophies["2"] = 500
        DataBase.createAccount(SimpleNamespace(player=self.player))

    def expire(self):
        initial = SeasonService.sync(self.player, NOW)
        self.assertFalse(initial["reset"])
        self.assertEqual(initial["remaining"], DURATION)
        result = SeasonService.sync(self.player, NOW + DURATION)
        self.assertTrue(result["reset"])
        return result["notification"]

    def reload(self):
        loaded = Players(SimpleNamespace())
        loaded.token = self.player.token
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=loaded)))
        return loaded

    def test_reset_uses_fifty_percent_excess_and_csv_milestone(self):
        notification = self.expire()
        self.assertEqual(self.player.brawlers_trophies["0"], 550)
        self.assertEqual(self.player.brawlers_trophies["1"], 501)
        self.assertEqual(self.player.brawlers_trophies["2"], 500)
        self.assertEqual(self.player.trophies, 3250)
        self.assertEqual(self.player.highest_trophies, 3300)
        self.assertEqual(self.player.star_points, 999999)
        self.assertEqual(self.player.brawl_boxes, 0)
        self.assertEqual(notification["Type"], 99)
        self.assertEqual(notification["Index"], 1)
        self.assertFalse(notification["Read"])
        self.assertFalse(notification["Seen"])
        self.assertEqual(
            notification["Best"],
            {"Trophies": 550, "Points": 50, "Coins": 50, "Bonus": 0},
        )
        self.assertEqual(
            notification["Total"],
            {"Trophies": 3250, "Points": 50, "Coins": 50, "Bonus": 140},
        )
        self.assertEqual(notification["BestBrawler"], 0)
        self.assertEqual(notification["Boxes"], [{"Type": 10, "Count": 1}])
        self.assertEqual(notification["Milestone"]["Index"], 48)
        self.assertEqual(notification["Milestone"]["Keys"], 140)
        self.assertEqual(notification["Changes"], [
            {"Brawler": 0, "Before": 600, "After": 550, "Loss": 50}
        ])
        self.assertEqual(self.player.progression["season"]["generation"], 1)
        self.assertEqual(
            self.player.progression["season"]["endsAt"], NOW + DURATION * 2
        )

        again = SeasonService.sync(self.player, NOW + DURATION)
        self.assertFalse(again["reset"])
        self.assertEqual(len(self.player.Notifications), 1)
        loaded = self.reload()
        self.assertEqual(loaded.brawlers_trophies["0"], 550)
        self.assertEqual(loaded.trophies, 3250)
        self.assertEqual(loaded.Notifications, self.player.Notifications)
        self.assertEqual(loaded.progression["season"], self.player.progression["season"])

    def test_native_99_body_and_skin_94_share_the_home_list(self):
        notification = self.expire()
        writer = OwnHomeDataMessage(None, self.player)
        NotificationFactory.encode(writer, self.player.Notifications)
        reader = BSMessageReader(writer.buffer)
        self.assertEqual(
            [reader.read_Vint() for _ in range(16)],
            [
                1, 99,
                550, 50, 50, 0,
                3250, 50, 50, 140,
                0, 9000, 16, 0, 9000, 0,
            ],
        )
        self.assertEqual(reader.read(), b"")

        NotificationFactory.add_skin(self.player, 2, "Skin especial")
        mixed = OwnHomeDataMessage(None, self.player)
        NotificationFactory.encode(mixed, self.player.Notifications)
        reader = BSMessageReader(mixed.buffer)
        self.assertEqual([reader.read_Vint(), reader.read_Vint()], [2, 99])
        for _ in range(14):
            reader.read_Vint()
        self.assertEqual([reader.read_Vint(), reader.read_Vint()], [94, 29000002])
        self.assertEqual(reader.read(), b"")
        self.assertEqual(notification["Index"], 1)

    def test_view_does_not_consume_and_delete_claims_tokens_and_box_once(self):
        self.expire()
        view_client = CaptureClient()
        view = EndClientTurn(view_client, self.player, view_payload(1))
        view.decode()
        view.process()
        self.assertEqual(view.commandID, 528)
        self.assertEqual(view_client.packets, [])
        self.assertTrue(self.player.Notifications["0"]["Seen"])
        self.assertFalse(self.player.Notifications["0"]["Read"])
        self.assertEqual(self.player.brawl_boxes, 0)

        loaded = self.reload()
        self.assertTrue(loaded.Notifications["0"]["Seen"])
        self.assertFalse(loaded.Notifications["0"]["Read"])
        pending = OwnHomeDataMessage(None, loaded)
        NotificationFactory.encode(pending, loaded.Notifications)
        self.assertEqual(BSMessageReader(pending.buffer).read_Vint(), 1)

        client = CaptureClient()
        turn = EndClientTurn(client, loaded, delete_payload(1))
        turn.decode()
        turn.process()
        self.assertEqual(turn.commandID, 514)
        self.assertEqual(turn.notification_action, 1)
        self.assertEqual(loaded.brawl_boxes, 340)
        self.assertEqual(loaded.big_boxes, 0)
        self.assertTrue(loaded.Notifications["0"]["Read"])
        self.assertTrue(loaded.Notifications["0"]["Seen"])
        self.assertEqual(len(client.packets), 1)
        response = BSMessageReader(client.packets[0][7:])
        self.assertEqual(
            [response.read_Vint() for _ in range(8)],
            [207, 5000001, 340, 0, 0, 0, 0, 0],
        )
        self.assertEqual(response.read(), b"")

        replay_client = CaptureClient()
        replay = EndClientTurn(replay_client, loaded, delete_payload(1))
        replay.decode()
        replay.process()
        self.assertEqual(replay_client.packets, [])
        self.assertEqual(loaded.brawl_boxes, 340)
        persisted = self.reload()
        self.assertEqual(persisted.brawl_boxes, 340)
        self.assertTrue(persisted.Notifications["0"]["Read"])
        encoded = OwnHomeDataMessage(None, persisted)
        NotificationFactory.encode(encoded, persisted.Notifications)
        self.assertEqual(encoded.buffer, b"\x00")

    def test_home_timer_is_daily_68_and_expiry_inserts_99_before_avatar(self):
        self.player.progression["season"] = {
            "version": 1,
            "endsAt": NOW + 123,
            "generation": 0,
            "lastResetAt": 0,
        }
        DataBase._update_value(
            "lowID", self.player.low_id, "progression", self.player.progression
        )
        with patch.object(EventSlots, "Timer", lambda self: 49020):
            home = OwnHomeDataMessage(None, self.player)
            home.encode()
        self.assertEqual(read_season_timer(home.buffer), 123)

        with patch("Logic.SeasonService.time.time", return_value=NOW + 123), \
             patch.object(EventSlots, "Timer", lambda self: 49020):
            expired = OwnHomeDataMessage(None, self.player)
            expired.encode()
        self.assertEqual(read_season_timer(expired.buffer), DURATION)
        self.assertEqual(len(self.player.Notifications), 1)
        block_writer = OwnHomeDataMessage(None, self.player)
        NotificationFactory.encode(block_writer, self.player.Notifications)
        account_id = (0x01020304).to_bytes(4, "big") + (42).to_bytes(4, "big")
        self.assertIn(account_id + block_writer.buffer, expired.buffer)

    def test_csv_boundaries_and_box_types_are_not_invented(self):
        self.assertEqual(SeasonService.milestone_for_trophies(2899)["Keys"], 0)
        self.assertEqual(SeasonService.milestone_for_trophies(2900)["Keys"], 100)
        self.assertEqual(SeasonService.milestone_for_trophies(3000)["Index"], 45)
        self.assertEqual(SeasonService.milestone_for_trophies(3300)["RewardType"], 6)
        self.assertEqual(SeasonService.milestone_for_trophies(3900)["RewardType"], 10)
        self.assertEqual(SeasonService.milestone_for_trophies(4300)["RewardType"], 14)
        self.assertEqual(SeasonService.milestone_for_trophies(15000)["Index"], 93)
        self.assertEqual(SeasonService.SEASON_BOX_REWARDS, {6: 10, 10: 11, 14: 12})

        details = SeasonService._reset_details(self.player, NOW)["notification"]
        self.assertEqual(details["Boxes"], [{"Type": 10, "Count": 1}])
        self.player.trophies = 4000
        details = SeasonService._reset_details(self.player, NOW)["notification"]
        self.assertEqual(details["Boxes"], [])
        self.assertEqual(details["Total"]["Bonus"], 220)

    def test_big_box_milestone_is_persisted_in_native_box_inventory(self):
        self.player.trophies = 3900
        DataBase._update_value("lowID", self.player.low_id, "trophies", 3900)
        self.expire()
        result = NotificationFactory.claim_next_season(self.player)
        self.assertEqual(result["tokens"], 320)
        self.assertEqual(result["boxes"], [{"Type": 11, "Count": 1}])
        self.assertEqual(result["resources"], {5000001: 320, 5000009: 0})
        self.assertEqual(self.player.brawl_boxes, 320)
        self.assertEqual(
            self.player.progression["boxInventory"]["boxes"]["11"], 1
        )
        loaded = self.reload()
        self.assertEqual(loaded.progression["boxInventory"]["boxes"]["11"], 1)

    def test_online_timer_delivers_native_206_and_schedules_next_season(self):
        from main import Server

        server = Server("127.0.0.1", 0)
        self.addCleanup(server.server.close)
        client = CaptureClient()
        self.player.logged_in = True
        self.player.crypto = None
        server.Clients = {
            "ClientCounts": 1,
            "Clients": {"42": {"SocketInfo": client, "Crypto": None}},
        }
        self.player.ClientDict = server.Clients
        SeasonService.sync(self.player, NOW)
        self.player.progression["season"]["endsAt"] = NOW + 60
        FakeTimer.instances = []
        with patch("main.threading.Timer", FakeTimer):
            timer = server.schedule_season(self.player, client)
            self.assertEqual(timer.delay, 60 - Server.SEASON_PUSH_LEAD)
            self.assertTrue(timer.started)
            self.assertTrue(timer.daemon)
            with patch(
                "Logic.SeasonService.time.time",
                return_value=NOW + 60 - Server.SEASON_PUSH_LEAD,
            ):
                timer.fire()
                timer.fire()
            self.assertEqual(len(client.packets), 1)
            packet = client.packets[0]
            self.assertEqual(int.from_bytes(packet[:2], "big"), 24111)
            self.assertEqual(int.from_bytes(packet[2:5], "big"), len(packet) - 7)
            reader = BSMessageReader(packet[7:])
            self.assertEqual(reader.read_Vint(), 206)
            self.assertTrue(reader.read_boolean())
            self.assertEqual(reader.read_Vint(), 99)
            values = [reader.read_Vint() for _ in range(14)]
            self.assertEqual(
                values,
                [550, 50, 50, 0, 3250, 50, 50, 140, 0, 9000, 16, 0, 9000, 0],
            )
            reader.ensure_end()
            self.assertEqual(self.player.brawlers_trophies["0"], 550)
            notification = next(
                value for value in self.player.Notifications.values()
                if value["Type"] == 99
            )
            self.assertEqual(notification["Index"], 1)
            self.assertFalse(notification["Read"])
            next_timer = FakeTimer.instances[-1]
            self.assertIsNot(next_timer, timer)
            self.assertEqual(next_timer.delay, DURATION)
            self.assertEqual(
                self.player.progression["season"]["endsAt"],
                NOW + 60 + DURATION,
            )
            server.unregister_client(self.player, client)
            self.assertTrue(next_timer.cancelled)
            self.assertEqual(server._season_timers, {})

    def test_duration_is_configurable_and_must_be_positive(self):
        with patch(
            "Logic.SeasonService.Config.GetValue", return_value={"SeasonDuration": 60}
        ):
            result = SeasonService.sync(self.player, NOW)
            self.assertEqual(result["endsAt"], NOW + 60)
            self.assertEqual(result["remaining"], 60)
        with patch(
            "Logic.SeasonService.Config.GetValue", return_value={"SeasonDuration": 0}
        ), self.assertRaisesRegex(ValueError, "SeasonDuration"):
            SeasonService.duration()

    def test_duration_accepts_days_hours_minutes_and_legacy_seconds(self):
        cases = (
            ("1m", 60),
            ("1h", 3600),
            ("70d", 6048000),
            (" 2H ", 7200),
            ("90", 90),
            (90, 90),
        )
        for value, expected in cases:
            with self.subTest(value=value):
                self.assertEqual(SeasonService.parse_duration(value), expected)
        for value in ("1w", "1.5h", "", None, True, -1, "0m"):
            with self.subTest(invalid=value), self.assertRaises(ValueError):
                SeasonService.parse_duration(value)
        with patch(
            "Logic.SeasonService.Config.GetValue", return_value={"SeasonDuration": "1m"}
        ):
            result = SeasonService.sync(self.player, NOW)
            self.assertEqual(result["remaining"], 60)
            self.assertEqual(result["endsAt"], NOW + 60)


if __name__ == "__main__":
    unittest.main()
