import sqlite3
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor
from contextlib import closing
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from Database.DatabaseManager import DataBase
from Logic.BattleInstances import BattleInstanceService
from Logic.BattleResultAdapter import apply_battle_result_rewards
from Logic.GameRoomService import GameRoomService
from Packets.Messages.Client.Battle.AskForBattleEndMessage import AskForBattleEndMessage
from Packets.Messages.Client.Gameroom.TeamSetMemberReadyMessage import (
    TeamSetMemberReadyMessage,
)
from Utils.Writer import Writer
from tests.test_battle_end import BattleAccountTestCase, CaptureClient, make_battle


class BattleLedgerTests(BattleAccountTestCase):
    def rows(self, player=None):
        player = player or self.player
        with closing(sqlite3.connect(self.database_path)) as connection:
            connection.row_factory = sqlite3.Row
            return [dict(row) for row in connection.execute(
                "SELECT * FROM battle_reward_ledger WHERE player_id = ? "
                "ORDER BY created_at, battle_id",
                (player.low_id,),
            )]

    def restart_schema(self):
        DataBase._initialized_paths.discard(str(Path(self.database_path).resolve()))

    def ready(self):
        writer = Writer(None).enable_native_v13()
        writer.writeBoolean(True)
        writer.writeVint(0)
        message = TeamSetMemberReadyMessage(None, self.player, writer.buffer)
        message.decode()
        message.process()

    def test_ready_reuses_open_instance_and_new_ready_distinguishes_identical_results(self):
        GameRoomService.init()
        self.addCleanup(GameRoomService.init)
        GameRoomService.create(self.player, 1, 0, 0)
        with patch("Packets.Messages.Server.Battle.MatchMakingCancelledMessage.MatchMakingCancelledMessage.send"):
            self.ready()
            first_instance = self.player.battle_instance_id
            self.ready()
            self.assertEqual(self.player.battle_instance_id, first_instance)
            first, first_client, _ = self.process(make_battle())
            self.assertEqual(first["battleID"], first_instance)
            self.ready()
            self.assertNotEqual(self.player.battle_instance_id, first_instance)
            second, second_client, _ = self.process(make_battle())

        self.assertNotEqual(second["battleID"], first["battleID"])
        self.assertNotEqual(second_client.packets[0], first_client.packets[0])
        self.assertEqual((self.player.trophies, self.player.brawl_boxes), (12, 40))
        self.assertEqual(len(self.rows()), 2)
        replay, replay_client, _ = self.process(make_battle())
        self.assertEqual(replay["battleID"], second["battleID"])
        self.assertEqual(replay_client.packets[0], second_client.packets[0])
        self.assertEqual((self.player.trophies, self.player.brawl_boxes), (12, 40))

    def test_ledger_ignores_legacy_cache_and_survives_schema_restart(self):
        first, client, _ = self.process(make_battle())
        first_packet = client.packets[0]
        self.player.progression["battleEndHistory"] = {}
        DataBase.replaceValues(SimpleNamespace(player=self.player), {
            "progression": self.player.progression,
        })
        self.restart_schema()
        loaded = self.reload()
        replay, replay_client, _ = self.process(make_battle(), loaded)
        self.assertEqual(replay["battleID"], first["battleID"])
        self.assertEqual(replay_client.packets[0], first_packet)
        self.assertEqual((loaded.trophies, loaded.brawl_boxes, loaded.big_boxes), (6, 20, 1))
        self.assertEqual(len(self.rows(loaded)), 1)
        self.assertIsNotNone(self.rows(loaded)[0]["completed_at"])

    def test_history_over_twenty_and_old_replay_remain_permanent(self):
        first = None
        for index in range(22):
            result, _, _ = self.process(make_battle(map_slot=index))
            if first is None:
                first = result
        self.assertEqual(len(self.rows()), 22)
        self.assertEqual(self.player.big_boxes, 1)
        balances = (self.player.trophies, self.player.brawl_boxes, self.player.big_boxes)
        with patch("Logic.BattleInstances.time.time", return_value=4_000_000_000), \
             patch("Logic.BattleRewardsManager.time.time", return_value=4_000_000_000):
            replay, _, _ = self.process(make_battle(map_slot=0))
        self.assertEqual(replay["battleID"], first["battleID"])
        self.assertEqual(len(self.rows()), 22)
        self.assertEqual(
            (self.player.trophies, self.player.brawl_boxes, self.player.big_boxes),
            balances,
        )

    def test_failure_before_commit_rolls_back_rewards_and_allows_retry(self):
        client = CaptureClient()
        message = AskForBattleEndMessage(client, self.player, make_battle())
        message.decode()
        with patch.object(
            DataBase, "_write_state", side_effect=sqlite3.OperationalError("injected")
        ):
            with self.assertRaises(sqlite3.OperationalError):
                message.process()
        self.assertEqual(self.player.trophies, 0)
        self.assertEqual(self.reload().trophies, 0)
        rows = self.rows()
        self.assertEqual(len(rows), 1)
        self.assertIsNone(rows[0]["rewards_json"])
        result, _, _ = self.process(make_battle())
        self.assertEqual(result["battleID"], rows[0]["battle_id"])
        self.assertEqual((self.reload().trophies, self.reload().brawl_boxes), (6, 20))

    def test_disconnect_after_commit_recovers_result_without_duplicate(self):
        client = CaptureClient()
        message = AskForBattleEndMessage(client, self.player, make_battle())
        message.decode()
        with patch.object(client, "sendall", side_effect=ConnectionResetError("closed")):
            with self.assertRaises(ConnectionResetError):
                message.process()
        rows = self.rows()
        self.assertEqual(len(rows), 1)
        self.assertIsNotNone(rows[0]["rewards_json"])
        loaded = self.reload()
        self.assertEqual((loaded.trophies, loaded.brawl_boxes), (6, 20))
        replay, _, _ = self.process(make_battle(), loaded)
        self.assertEqual(replay["battleID"], rows[0]["battle_id"])
        self.assertEqual((self.reload().trophies, self.reload().brawl_boxes), (6, 20))

    def test_concurrent_same_instance_applies_once(self):
        players = [self.reload() for _ in range(8)]
        battle_id = uuid.uuid4().hex
        barrier = threading.Barrier(len(players))
        def reward(player):
            barrier.wait()
            return apply_battle_result_rewards(player, 0, battle_id)
        with ThreadPoolExecutor(max_workers=len(players)) as executor:
            results = list(executor.map(reward, players))
        self.assertEqual(sum("_replayed" in item.rewards for item in results), 7)
        loaded = self.reload()
        self.assertEqual((loaded.trophies, loaded.brawl_boxes, loaded.big_boxes), (6, 20, 1))
        self.assertEqual(len(self.rows()), 1)

    def test_concurrent_different_instances_serialize_canonical_balances(self):
        players = [self.reload() for _ in range(2)]
        barrier = threading.Barrier(2)
        def reward(player):
            barrier.wait()
            return apply_battle_result_rewards(player, 0, uuid.uuid4().hex)
        with ThreadPoolExecutor(max_workers=2) as executor:
            results = list(executor.map(reward, players))
        self.assertEqual([item.gainedtrophies for item in results], [6, 6])
        loaded = self.reload()
        self.assertEqual((loaded.trophies, loaded.brawl_boxes, loaded.big_boxes), (12, 40, 1))
        self.assertEqual(len(self.rows()), 2)

    def test_r111_schema_is_extended_without_rebuilding_players(self):
        DataBase.replaceValues(SimpleNamespace(player=self.player), {"gold": 4321})
        with closing(sqlite3.connect(self.database_path)) as connection:
            connection.execute("DROP TABLE battle_reward_ledger")
            connection.execute("PRAGMA user_version = 3")
        self.restart_schema()
        loaded = self.reload()
        self.assertEqual((loaded.low_id, loaded.gold, loaded.token), (1, 4321, self.player.token))
        with closing(sqlite3.connect(self.database_path)) as connection:
            self.assertEqual(connection.execute("PRAGMA user_version").fetchone()[0], 5)
            self.assertIsNotNone(connection.execute(
                "SELECT 1 FROM sqlite_master WHERE type = 'table' "
                "AND name = 'battle_reward_ledger'"
            ).fetchone())
            self.assertEqual(connection.execute(
                "SELECT COUNT(*) FROM players WHERE lowID = 1"
            ).fetchone()[0], 1)
