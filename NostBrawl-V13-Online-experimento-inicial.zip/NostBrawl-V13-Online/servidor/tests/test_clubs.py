import json
import sqlite3
import tempfile
import unittest
from contextlib import closing
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from Database.DatabaseManager import DataBase
from Logic.ClubService import ClubError, ClubService
from Logic.Player import Players
from Logic.PresenceService import PresenceService
from Packets.LogicMessageFactory import packets
from Packets.Messages.Client.Alliance.Alliance_Chat_Message import AllianceChatMessage
from Packets.Messages.Client.Alliance.Ask_For_Alliance_Data_Message import AskForAllianceDataMessage
from Packets.Messages.Client.Alliance.Create_Message import Create_Message
from Packets.Messages.Client.Alliance.Edit_Settings_Message import Edit_Settings_Message
from Packets.Messages.Client.Alliance.Promote_Alliance_Member_Message import Promote_Alliance_Member_Message
from Packets.Messages.Client.Alliance.Search_Message import Search_Message
from Packets.Messages.Client.Alliance.Send_Club_Mail_Message import SendClubMail
from Packets.Messages.Client.Home.PlayerStatusMessage import PlayerStatusMessage
from Packets.Messages.Server.Alliance.Alliance_Data_Message import AllianceDataMessage
from Packets.Messages.Server.Alliance.AllianceMemberEntryMessage import AllianceMemberEntryMessage
from Packets.Messages.Server.Alliance.AllianceStreamMessage import AllianceStreamMessage
from Packets.Messages.Server.Alliance.JoinableAllianceListMessage import JoinableAllianceListMessage
from Packets.Messages.Server.Alliance.My_Alliance_Message import MyAllianceMessage
from Packets.Messages.Server.AllianceBot.Alliance_Bot_Chat_Server_Message import AllianceBotChatServerMessage
from Packets.Messages.Server.Home.PlayerProfileMessage import PlayerProfileMessage
from Packets.Messages.Server.Leaderboard.TopGlobalClubsDataMessage import GetLeaderboardClubGlobalOkMessage
from Packets.Messages.Server.Leaderboard.TopGlobalPlayersDataMessage import GetLeaderboardGlobalOkMessage
from Packets.Messages.Server.Leaderboard.TopLocalClubsDataMessage import GetLeaderboardClubLocalOkMessage
from Utils.Reader import BSMessageReader
from Utils.Writer import Writer


class CaptureClient:
    def __init__(self):
        self.packets = []

    def sendall(self, data):
        self.packets.append(bytes(data))

    def ids(self):
        return [int.from_bytes(packet[:2], "big") for packet in self.packets]

    def versions(self):
        return [int.from_bytes(packet[5:7], "big") for packet in self.packets]


def string(value):
    writer = Writer(None)
    writer.writeString(value)
    return writer.buffer


def vint(value):
    writer = Writer(None)
    writer.writeVint(value)
    return writer.buffer


def int32(value):
    return int(value).to_bytes(4, "big", signed=True)


class ClubAccountTestCase(unittest.TestCase):
    def setUp(self):
        self.temp_directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp_directory.cleanup)
        self.database_path = str(Path(self.temp_directory.name) / "players.db")
        path_patch = patch.object(DataBase, "_database_path", lambda: self.database_path)
        path_patch.start()
        self.addCleanup(path_patch.stop)
        self.empty_clients = {"ClientCounts": 0, "Clients": {}}

    def make_account(self, low_id, name, trophies=0):
        player = Players(SimpleNamespace())
        player.low_id = low_id
        player.high_id = 0
        player.token = f"club-token-{low_id}"
        player.name = name
        player.trophies = trophies
        player.highest_trophies = trophies
        player.ClientDict = self.empty_clients
        DataBase.createAccount(SimpleNamespace(player=player))
        return player

    def reload(self, player):
        loaded = Players(SimpleNamespace())
        loaded.token = player.token
        loaded.ClientDict = self.empty_clients
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=loaded)))
        return loaded


class ClubServiceTests(ClubAccountTestCase):
    def test_create_edit_chat_mail_and_stream_persist(self):
        owner = self.make_account(1, "Owner", 100)
        club, welcome = ClubService.create(owner, 123456, "Alpha", "Description", 8, 1, 100, 1)
        self.assertEqual(owner.player_experience, 99999)
        self.assertEqual(club["members"][0]["experience"], 99999)
        self.assertEqual((owner.club_low_id, owner.club_role), (123456, 2))
        self.assertEqual(club["family_friendly"], 1)
        self.assertEqual(club["trophies"], 100)
        self.assertIsNone(welcome)
        loaded = self.reload(owner)
        self.assertEqual((loaded.club_low_id, loaded.club_role), (123456, 2))
        self.assertEqual(loaded.progression["clubLastSeenMessageID"], 0)

        club = ClubService.edit(owner, "Edited", 9, 2, 200, 0)
        self.assertEqual((club["description"], club["family_friendly"]), ("Edited", 0))
        club = ClubService.edit(owner, "Again", 9, 2, 200)
        self.assertEqual(club["family_friendly"], 0)
        _, first = ClubService.chat(owner, "First")
        _, second = ClubService.chat(owner, "Second")
        messages = ClubService.get_messages(club["id"])
        self.assertEqual([entry["message"] for entry in messages], ["First", "Second"])
        self.assertEqual([entry["position"] for entry in messages], [1, 2])
        self.assertEqual((first["player_role"], second["player_role"]), (2, 2))

        _, notification = ClubService.mail(owner, "Club mail")
        self.assertEqual(ClubService.get_notifications(club["id"]), [notification])
        stream = AllianceStreamMessage(None, owner, club["id"], 0)
        stream.encode()
        reader = BSMessageReader(stream.buffer)
        self.assertEqual(reader.read_Vint(), 2)
        data = AllianceDataMessage(None, owner, 0, club["id"])
        data.encode()
        club_reader = BSMessageReader(data.buffer)
        self.assertEqual(club_reader.read_Vint(), 0)
        self.assertEqual((club_reader.read_int(), club_reader.read_int()), (0, 123456))
        self.assertEqual(club_reader.read_string(), "Alpha")
        self.assertEqual(
            [club_reader.read_Vint() for _ in range(6)],
            [8, 9, 2, 1, 100, 200],
        )
        self.assertEqual([club_reader.read_Vint(), club_reader.read_Vint()], [0, 0])
        self.assertEqual(club_reader.read_string(), "Again")
        self.assertEqual(club_reader.read_Vint(), 1)
        self.assertEqual((club_reader.read_int(), club_reader.read_int()), (0, 1))
        self.assertEqual(club_reader.read_string(), "Owner")
        self.assertEqual(
            [club_reader.read_Vint() for _ in range(5)],
            [2, 100, 0, 0, 0],
        )
        self.assertEqual([club_reader.read_Vint(), club_reader.read_Vint()], [28, 0])
        self.assertEqual(club_reader.read(), b"")
        self.assertEqual(self.reload(owner).club_role, 2)

    def test_join_leave_succession_and_last_member_delete(self):
        owner = self.make_account(2, "Owner", 200)
        member = self.make_account(3, "Member", 50)
        ClubService.create(owner, 222222, "Club", "", 1, 1, 0, 0)
        club, join_entry = ClubService.join(member, 222222)
        self.assertEqual((club["member_count"], club["trophies"]), (2, 250))
        self.assertEqual((join_entry["message"], join_entry["player_role"]), ("3", 1))
        self.assertEqual(self.reload(member).club_low_id, 222222)

        result = ClubService.leave(owner)
        self.assertFalse(result["deleted"])
        self.assertEqual(result["memberIDs"], [3])
        self.assertEqual(result["entry"]["message"], "4")
        self.assertEqual((owner.club_low_id, owner.club_role), (0, 0))
        self.assertEqual(self.reload(member).club_role, 2)
        self.assertEqual(ClubService.get_club(222222)["member_count"], 1)

        result = ClubService.leave(member)
        self.assertTrue(result["deleted"])
        self.assertIsNone(ClubService.get_club(222222))
        self.assertEqual(ClubService.get_messages(222222), [])
        self.assertEqual(self.reload(member).club_low_id, 0)

    def test_roles_kick_and_unauthorized_actions_are_atomic(self):
        owner = self.make_account(4, "Owner", 300)
        member = self.make_account(5, "Member", 100)
        ClubService.create(owner, 333333, "Roles", "", 1, 1, 0, 0)
        ClubService.join(member, 333333)
        with self.assertRaises(ClubError):
            ClubService.kick(member, 4)
        self.assertEqual(self.reload(owner).club_low_id, 333333)

        club, actor_role = ClubService.promote(owner, 5, 3)
        self.assertEqual(actor_role, 2)
        self.assertEqual(self.reload(member).club_role, 3)
        club, actor_role = ClubService.promote(owner, 5, 2)
        self.assertEqual(actor_role, 4)
        self.assertEqual(self.reload(owner).club_role, 4)
        self.assertEqual(self.reload(member).club_role, 2)
        with self.assertRaises(ClubError):
            ClubService.promote(owner, 5, 1)

        club, entry, target = ClubService.kick(member, 4)
        self.assertEqual(target, 4)
        self.assertEqual(entry["message"], "1")
        self.assertEqual(club["member_ids"], [5])
        self.assertEqual((self.reload(owner).club_low_id, self.reload(owner).club_role), (0, 0))

    def test_search_filters_before_limit_and_excludes_closed_clubs(self):
        first = self.make_account(6, "First", 500)
        second = self.make_account(7, "Second", 100)
        third = self.make_account(8, "Third", 1000)
        ClubService.create(first, 444441, "Other", "", 1, 1, 0, 0)
        ClubService.create(second, 444442, "Needle", "", 1, 1, 0, 1)
        ClubService.create(third, 444443, "Closed Needle", "", 1, 3, 0, 0)
        result = ClubService.list_clubs(1, 100, 2, 1, "Needle")
        self.assertEqual([club["id"] for club in result], [444442])
        self.assertEqual(result[0]["family_friendly"], 1)
        self.assertEqual(ClubService.list_clubs(1, 100, 2, 30, "Closed"), [])

    def test_handler_create_chat_and_promote_route(self):
        self.assertIs(packets[14306], Promote_Alliance_Member_Message)
        owner = self.make_account(9, "Owner", 100)
        client = CaptureClient()
        payload = string("Handler Club") + string("Desc")
        for value in (8, 1, 1, 0):
            writer = Writer(None)
            writer.writeVint(value)
            payload += writer.buffer
        with patch("Utils.Helpers.Helpers.randomClubID", lambda self: 555555):
            message = Create_Message(client, owner, payload)
            message.decode()
        self.assertEqual(message.read(), b"")
        self.assertEqual(message.clubfriendlyfamily, 0)
        self.assertEqual(
            (message.BadgeIdentifier, message.clubbadgeID),
            (8, 1),
        )
        self.assertEqual(
            (message.clubtype, message.clubtrophiesneeded),
            (1, 0),
        )
        club = message.process()
        self.assertEqual(club["id"], 555555)
        self.assertEqual(client.ids(), [24333, 24399, 24311])
        self.assertEqual(client.versions(), [11, 11, 11])
        self.assertEqual((owner.club_low_id, owner.club_role), (555555, 2))

        chat_client = CaptureClient()
        chat_payload = string("Persistent chat")
        chat = AllianceChatMessage(chat_client, owner, chat_payload)
        chat.decode()
        entry = chat.process()
        self.assertEqual(entry["message"], "Persistent chat")
        self.assertEqual(chat_client.ids(), [24312])
        self.assertEqual(chat_client.versions(), [11])
        self.assertEqual(len(ClubService.get_messages(555555)), 1)
        stream = AllianceStreamMessage(None, owner, 555555, 0)
        stream.encode()
        self.assertEqual(BSMessageReader(stream.buffer).read_Vint(), 1)
        self.assertEqual(len(ClubService.get_messages(555555)), 1)

    def test_profile_and_player_leaderboard_read_club_from_service(self):
        owner = self.make_account(11, "Profile Owner", 350)
        club, _ = ClubService.create(owner, 777770, "Profile Club", "", 6, 1, 25, 0)
        row = DataBase.loadMembersById(SimpleNamespace(player=owner), owner.low_id)
        profile = PlayerProfileMessage(None, owner, 0, owner.low_id, [row])
        leaderboard = GetLeaderboardGlobalOkMessage(None, owner)
        profile.encode()
        leaderboard.encode()
        self.assertIn(b"Profile Club", leaderboard.buffer)
        reader = BSMessageReader(profile.buffer)
        self.assertEqual([reader.read_Vint() for _ in range(2)], [0, 11])
        self.assertEqual(reader.read_string(), "Profile Owner")
        self.assertEqual(reader.readScId(), (0, -1))
        for _ in range(reader.read_Vint()):
            self.assertEqual(reader.read_Vint(), 16)
            reader.read_Vint()
            reader.read_Vint()
            reader.read_Vint()
            reader.read_Vint()
            reader.read_Vint()
        self.assertEqual(reader.read_Vint(), 10)
        for _ in range(10):
            reader.read_Vint()
            reader.read_Vint()
        self.assertEqual(reader.read_byte(), 1)
        self.assertEqual(reader.read_int(), 0)
        self.assertEqual(reader.read_int(), club["id"])
        self.assertEqual(reader.read_string(), "Profile Club")
        self.assertEqual(reader.readScId(), (8, 6))
        self.assertEqual(
            [reader.read_Vint() for _ in range(4)],
            [1, 1, 350, 25],
        )
        self.assertEqual(reader.readScId(), (0, -1))
        self.assertEqual(reader.read_Vint(), 0)
        self.assertEqual(reader.readScId(), (25, 2))
        self.assertEqual(reader.read(), b"")

    def test_profile_without_club_uses_native_v13_field_order(self):
        owner = self.make_account(14, "No Club", 125)
        row = DataBase.loadMembersById(SimpleNamespace(player=owner), owner.low_id)
        profile = PlayerProfileMessage(None, owner, 0, owner.low_id, [row])
        profile.encode()
        reader = BSMessageReader(profile.buffer)
        self.assertEqual([reader.read_Vint() for _ in range(2)], [0, 14])
        self.assertEqual(reader.read_string(), "No Club")
        self.assertEqual(reader.readScId(), (0, -1))
        for _ in range(reader.read_Vint()):
            self.assertEqual(reader.read_Vint(), 16)
            reader.read_Vint()
            self.assertEqual(reader.read_Vint(), 0)
            reader.read_Vint()
            reader.read_Vint()
            reader.read_Vint()
        self.assertEqual(reader.read_Vint(), 10)
        stats = {}
        for _ in range(10):
            key = reader.read_Vint()
            stats[key] = reader.read_Vint()
        self.assertEqual(list(stats), [1, 2, 3, 4, 5, 7, 8, 9, 10, 11])
        self.assertEqual(stats[7], 28000000 + owner.profile_icon)
        self.assertEqual(reader.read_byte(), 0)
        self.assertEqual(reader.readScId(), (0, -1))
        self.assertEqual(reader.read(), b"")

    def test_club_leaderboards_and_bot_use_persistent_service_data(self):
        owner = self.make_account(12, "Open", 100)
        closed_owner = self.make_account(13, "Closed", 400)
        ClubService.create(owner, 777771, "Open Club", "", 2, 1, 0, 0)
        ClubService.create(closed_owner, 777772, "Closed Club", "", 3, 3, 0, 0)
        for message_class in (GetLeaderboardClubGlobalOkMessage, GetLeaderboardClubLocalOkMessage):
            with self.subTest(message=message_class.__name__):
                message = message_class(None, owner, 0)
                message.encode()
                reader = BSMessageReader(message.buffer)
                self.assertEqual([reader.read_Vint() for _ in range(2)], [2, 0])
                self.assertEqual(
                    reader.read_string(),
                    owner.region if message_class is GetLeaderboardClubLocalOkMessage else "",
                )
                self.assertEqual(reader.read_Vint(), 2)
                entries = []
                for _ in range(2):
                    self.assertEqual(reader.read_Vint(), 0)
                    club_id = reader.read_Vint()
                    rank = reader.read_Vint()
                    trophies = reader.read_Vint()
                    self.assertEqual(reader.read_Vint(), 2)
                    name = reader.read_string()
                    members = reader.read_Vint()
                    self.assertEqual(reader.read_Vint(), 8)
                    badge = reader.read_Vint()
                    entries.append((club_id, rank, trophies, name, members, badge))
                self.assertEqual([entry[0] for entry in entries], [777772, 777771])
                self.assertEqual([entry[1] for entry in entries], [1, 2])
                self.assertEqual([reader.read_Vint() for _ in range(4)], [0, 2, 0, 0])
                self.assertEqual(reader.read_string(), owner.region)
                self.assertEqual(reader.read(), b"")
        ClubService.chat(owner, "Persistent")
        bot = AllianceBotChatServerMessage(None, owner, "Bot response")
        self.assertEqual(bot.version, 11)
        bot.encode()
        reader = BSMessageReader(bot.buffer)
        self.assertEqual([reader.read_Vint() for _ in range(5)], [2, 0, 1, 1, 1])
        self.assertEqual(reader.read_string(), "Club Bot")
        self.assertEqual([reader.read_Vint() for _ in range(3)], [3, 0, 0])
        self.assertEqual(reader.read_string(), "Bot response")
        self.assertEqual(reader.read(), b"")

    def test_edit_settings_v13_payload_is_fully_decoded_and_persisted(self):
        owner = self.make_account(20, "Editor", 100)
        ClubService.create(owner, 888888, "Editable", "Old", 8, 1, 0, 0)
        client = CaptureClient()
        payload = string("Updated description")
        for value in (8, 7, 2, 150):
            writer = Writer(None)
            writer.writeVint(value)
            payload += writer.buffer
        message = Edit_Settings_Message(client, owner, payload)
        message.decode()
        self.assertEqual(message.read(), b"")
        self.assertEqual((message.inf2, message.badgeID), (8, 7))
        self.assertEqual((message.inf4, message.regionID), (0, 0))
        self.assertEqual((message.clubType, message.requiredTrophies), (2, 150))
        self.assertIsNone(message.friendlyFamilly)
        club = message.process()
        self.assertEqual(club["description"], "Updated description")
        self.assertEqual((club["badge_id"], club["type"]), (7, 2))
        self.assertEqual(club["required_trophies"], 150)
        self.assertEqual(club["family_friendly"], 0)
        self.assertEqual(client.ids(), [24333, 24399])
        self.assertEqual(
            ClubService.get_club(888888)["description"], "Updated description"
        )

    def test_online_status_updates_memory_sqlite_and_club_counters(self):
        owner = self.make_account(21, "Online", 100)
        ClubService.create(owner, 888889, "Online Club", "", 8, 1, 0, 0)
        writer = Writer(None).enable_native_v13()
        writer.writeVint(2)
        status = PlayerStatusMessage(None, owner, writer.buffer)
        status.decode()
        status.process()
        self.assertEqual(owner.online, 2)
        row = DataBase.loadMembersById(SimpleNamespace(player=owner), owner.low_id)
        self.assertEqual(row[36], 2)
        self.assertEqual(ClubService.get_club(888889)["online_count"], 1)

        mine = MyAllianceMessage(None, owner, 888889)
        mine.encode()
        reader = BSMessageReader(mine.buffer)
        self.assertEqual([reader.read_Vint() for _ in range(4)], [1, 1, 25, 2])
        self.assertEqual((reader.read_int(), reader.read_int()), (0, 888889))
        self.assertEqual(reader.read_string(), "Online Club")
        self.assertEqual(
            [reader.read_Vint() for _ in range(7)],
            [8, 8, 1, 1, 100, 0, 0],
        )
        self.assertEqual(reader.read_Vint(), 1)
        self.assertEqual(reader.read(), b"")

        joinable = JoinableAllianceListMessage(None, owner)
        joinable.encode()
        reader = BSMessageReader(joinable.buffer)
        self.assertEqual(reader.read_Vint(), 1)
        self.assertEqual((reader.read_int(), reader.read_int()), (0, 888889))
        self.assertEqual(reader.read_string(), "Online Club")
        self.assertEqual(
            [reader.read_Vint() for _ in range(7)],
            [8, 8, 1, 1, 100, 0, 0],
        )
        self.assertEqual(reader.read_Vint(), 1)
        self.assertEqual(reader.read(), b"")

        writer = Writer(None).enable_native_v13()
        writer.writeVint(8)
        status = PlayerStatusMessage(None, owner, writer.buffer)
        status.decode()
        status.process()
        self.assertEqual(owner.online, 8)
        self.assertEqual(ClubService.get_club(888889)["online_count"], 1)

    def test_live_club_presence_broadcasts_member_and_drops_disconnected_status(self):
        owner = self.make_account(31, "Live Owner", 300)
        member = self.make_account(32, "Live Member", 100)
        ClubService.create(owner, 999991, "Live Club", "", 8, 1, 0, 0)
        ClubService.join(member, 999991)
        owner_client = CaptureClient()
        member_client = CaptureClient()
        clients = {
            "ClientCounts": 2,
            "Clients": {
                "31": {"SocketInfo": owner_client, "Crypto": None, "Lock": None, "Status": 1},
                "32": {"SocketInfo": member_client, "Crypto": None, "Lock": None, "Status": 2},
            },
        }
        owner.ClientDict = clients
        member.ClientDict = clients
        PresenceService.bind_clients(clients)
        self.addCleanup(PresenceService.bind_clients, None)
        club = ClubService.get_club(999991)
        self.assertEqual(club["online_count"], 2)
        self.assertEqual(club["members"][1]["status"], 2)
        writer = Writer(None).enable_native_v13()
        writer.writeVint(8)
        status = PlayerStatusMessage(member_client, member, writer.buffer)
        status.decode()
        status.process()
        self.assertEqual(owner_client.ids(), [24308])
        packet = owner_client.packets[-1]
        reader = BSMessageReader(packet[7:])
        self.assertEqual((reader.read_int(), reader.read_int()), (0, 999991))
        self.assertEqual((reader.read_int(), reader.read_int()), (0, 32))
        self.assertEqual(reader.read_string(), "Live Member")
        self.assertEqual(
            [reader.read_Vint() for _ in range(3)], [1, 100, 8]
        )
        club = ClubService.get_club(999991)
        self.assertEqual(club["online_count"], 2)
        self.assertEqual(club["members"][1]["status"], 8)
        del clients["Clients"]["32"]
        clients["ClientCounts"] = 1
        club = ClubService.get_club(999991)
        self.assertEqual(club["online_count"], 1)
        self.assertEqual(club["members"][1]["status"], 0)

    def test_alliance_data_decoder_consumes_optional_logiclong(self):
        owner = self.make_account(22, "Alliance Data", 100)
        ClubService.create(owner, 888890, "Data Club", "", 8, 1, 0, 0)
        for present in (False, True):
            with self.subTest(present=present):
                client = CaptureClient()
                payload = int32(0) + int32(888890) + vint(int(present))
                if present:
                    payload += int32(7) + int32(9)
                message = AskForAllianceDataMessage(client, owner, payload)
                message.decode()
                self.assertEqual(message.hasAdditionalID, present)
                self.assertEqual(
                    (message.additionalHighID, message.additionalLowID),
                    (7, 9) if present else (0, 0),
                )
                self.assertEqual(message.read(), b"")
                message.process()
                self.assertEqual(client.ids(), [24301])
                self.assertEqual(client.versions(), [11])
                packet = client.packets[0]
                length = int.from_bytes(packet[2:5], "big")
                reader = BSMessageReader(packet[7:7 + length])
                self.assertEqual(reader.read_Vint(), 0)
                self.assertEqual((reader.read_int(), reader.read_int()), (0, 888890))

        other = self.make_account(23, "Other Owner", 200)
        ClubService.create(other, 888891, "Other Club", "", 8, 1, 0, 0)
        response = AllianceDataMessage(None, owner, 0, 888891)
        response.encode()
        self.assertEqual(BSMessageReader(response.buffer).read_Vint(), 2)

    def test_search_decoder_filters_and_response_use_native_layout(self):
        online = self.make_account(24, "Online", 500)
        offline = self.make_account(25, "Offline", 100)
        ClubService.create(online, 888892, "Needle Online", "", 8, 1, 0, 0)
        ClubService.create(offline, 888893, "Needle Offline", "", 8, 1, 0, 0)
        DataBase.replaceValues(SimpleNamespace(player=online), {"online": 2})
        payload = (
            string("Needle")
            + int32(1)
            + int32(100)
            + int32(2)
            + int32(1)
            + vint(0)
            + int32(0)
            + int32(0)
        )
        client = CaptureClient()
        message = Search_Message(client, online, payload)
        message.decode()
        self.assertEqual(
            (
                message.RequestedName,
                message.minMembers,
                message.maxMembers,
                message.clubType,
                message.maxListLength,
                message.onlyOnline,
                message.regionID,
                message.sortOrder,
            ),
            ("Needle", 1, 100, 2, 1, False, 0, 0),
        )
        self.assertEqual(message.read(), b"")
        clubs = message.process()
        self.assertEqual([club["id"] for club in clubs], [888892])
        self.assertEqual(client.ids(), [24310])
        self.assertEqual(client.versions(), [11])
        packet = client.packets[0]
        length = int.from_bytes(packet[2:5], "big")
        reader = BSMessageReader(packet[7:7 + length])
        self.assertEqual(reader.read_string(), "Needle")
        self.assertEqual(reader.read_Vint(), 1)
        self.assertEqual((reader.read_int(), reader.read_int()), (0, 888892))
        self.assertEqual(reader.read_string(), "Needle Online")
        self.assertEqual(
            [reader.read_Vint() for _ in range(6)],
            [8, 8, 1, 1, 500, 0],
        )
        self.assertEqual(reader.readScId(), (0, -1))
        self.assertEqual(reader.read_Vint(), 1)
        self.assertEqual(reader.read(), b"")

    def test_club_mail_native_logiclong_reaches_two_connected_clients(self):
        owner = self.make_account(26, "Mail Owner", 300)
        member = self.make_account(27, "Mail Member", 100)
        ClubService.create(owner, 888894, "Mail Club", "", 8, 1, 0, 0)
        ClubService.join(member, 888894)
        owner_client = CaptureClient()
        member_client = CaptureClient()
        clients = {
            "ClientCounts": 2,
            "Clients": {
                "26": {"SocketInfo": owner_client, "Lock": None, "Crypto": None},
                "27": {"SocketInfo": member_client, "Lock": None, "Crypto": None},
            },
        }
        owner.ClientDict = clients
        member.ClientDict = clients
        payload = int32(0) + int32(888894) + string("Native mail")
        message = SendClubMail(owner_client, owner, payload)
        message.decode()
        self.assertEqual((message.clubHighID, message.clubLowID), (0, 888894))
        self.assertEqual(message.msg, "Native mail")
        self.assertEqual(message.read(), b"")
        notification = message.process()
        self.assertEqual(notification["text"], "Native mail")
        self.assertEqual(owner_client.ids(), [24333, 24111])
        self.assertEqual(owner_client.versions(), [11, 0])
        self.assertEqual(member_client.ids(), [24111])
        self.assertEqual(ClubService.get_notifications(888894), [notification])

    def test_alliance_member_entry_uses_native_v13_layout_and_version(self):
        player = SimpleNamespace(
            club_high_id=0,
            club_low_id=888895,
            high_id=0,
            low_id=28,
            name="Entry Member",
            club_role=2,
            trophies=450,
            online=2,
            profile_icon=7,
        )
        message = AllianceMemberEntryMessage(None, player)
        self.assertEqual(message.version, 11)
        message.encode()
        reader = BSMessageReader(message.buffer)
        self.assertEqual((reader.read_int(), reader.read_int()), (0, 888895))
        self.assertEqual((reader.read_int(), reader.read_int()), (0, 28))
        self.assertEqual(reader.read_string(), "Entry Member")
        self.assertEqual(
            [reader.read_Vint() for _ in range(5)],
            [2, 450, 2, 0, 0],
        )
        self.assertEqual(reader.readScId(), (28, 7))
        self.assertEqual(reader.read(), b"")

    def test_legacy_club_chat_and_mail_migration_is_idempotent(self):
        club_id = 666666
        owner = self.make_account(10, "Legacy", 400)
        DataBase.replaceValues(SimpleNamespace(player=owner), {"clubID": club_id, "clubRole": 2})
        clubs_path = Path(self.temp_directory.name) / "clubs.db"
        chats_directory = Path(self.temp_directory.name) / "Chats"
        chats_directory.mkdir()
        with closing(sqlite3.connect(clubs_path)) as connection:
            connection.execute("CREATE TABLE clubs (clubID INT, name TEXT, description TEXT, region TEXT, badgeID INT, type INT, trophiesneeded INT, trophies INT, members JSON, notif JSON)")
            connection.execute(
                "INSERT INTO clubs VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (club_id, "Legacy Club", "Old", "RU", 4, 1, 50, 400, json.dumps({"10": "Legacy"}), json.dumps({"0": {"text": "Old mail", "by": 10, "timer": 1}})),
            )
            connection.commit()
        with closing(sqlite3.connect(chats_directory / f"{club_id}.db")) as connection:
            connection.execute("CREATE TABLE chats (Event INT, Tick INT, plrid INT, plrname TEXT, plrrole INT, Msg TEXT)")
            connection.execute("INSERT INTO chats VALUES (2, 1, 10, 'Legacy', 2, 'Old chat')")
            connection.commit()
        first = ClubService.migrate_legacy(clubs_path, chats_directory)
        second = ClubService.migrate_legacy(clubs_path, chats_directory)
        self.assertEqual(first, {"clubs": 1, "members": 1, "messages": 1, "notifications": 1})
        self.assertEqual(second, {"clubs": 0, "members": 0, "messages": 0, "notifications": 0})
        club = ClubService.get_club(club_id)
        self.assertEqual((club["name"], club["member_count"], club["trophies"]), ("Legacy Club", 1, 400))
        self.assertEqual(ClubService.get_messages(club_id)[0]["message"], "Old chat")
        self.assertEqual(ClubService.get_notifications(club_id)[0]["text"], "Old mail")


if __name__ == "__main__":
    unittest.main()
