import socket
from types import SimpleNamespace

from Core.Crypto import Crypto
from Database.DatabaseManager import DataBase
from Files.CsvLogic.Characters import Characters
from Files.CsvLogic.Skins import Skins
from Logic.Battle.BattleParticipants import BattleParticipants
from Logic.GameRoomService import GameRoomService
from main import ClientThread
from Packets.Messages.Client.Battle.AskForBattleEndMessage import AskForBattleEndMessage
from Packets.Messages.Client.Gameroom.TeamCreateMessage import TeamCreateMessage
from Packets.Messages.Client.Gameroom.TeamSetMemberReadyMessage import TeamSetMemberReadyMessage
from Packets.Messages.Client.Home.GoHomeFromOfflinePractiseMessage import GoHomeFromOfflinePractiseMessage
from Packets.Messages.Server.Battle.StartLoadingMessage import StartLoadingMessage
from Utils.Writer import Writer
from tests.test_battle_end import (
    BattleAccountTestCase,
    CaptureClient,
    read_native_result,
)
from tests.test_own_home_data_wire import read_home_commodities
from tests.test_room_battle import parse_start_loading


def native_writer():
    return Writer(None).enable_native_v13()


def status_payload(status):
    writer = native_writer()
    writer.writeVint(status)
    return writer.buffer


def create_payload(map_id):
    writer = native_writer()
    for value in (map_id, 0, 0):
        writer.writeVint(value)
    writer.writeBoolean(False)
    return writer.buffer


def ready_payload():
    writer = native_writer()
    writer.writeBoolean(True)
    writer.writeVint(0)
    return writer.buffer


def battle_payload(entries, own_index, map_id, result, rank):
    writer = native_writer()
    for value in (result, entries[own_index]["team"], rank, map_id, 0, len(entries)):
        writer.writeVint(value)
    for index, entry in enumerate(entries):
        writer.writeScId(16, entry["brawler_id"])
        writer.writeScId(29, entry["skin_id"])
        writer.writeVint(entry["team"])
        writer.writeBoolean(index == own_index)
        writer.writeString(entry["name"])
    return writer.buffer


def assert_complete_home(test, payload, brawler_id):
    reader, _ = read_home_commodities(payload)
    test.assertEqual(reader.selected_brawler, (16, brawler_id))
    reader.brawler_values()
    reader.brawler_values()
    reader.v()
    reader.brawler_values()
    reader.brawler_values()
    for _ in range(2):
        reader.v()
    for _ in range(3):
        reader.v()
    for _ in range(7):
        reader.v()
    for _ in range(2):
        reader.v()
    test.assertEqual(reader.read(), b"")


def receive_exact(connection, length):
    data = bytearray()
    while len(data) < length:
        chunk = connection.recv(length - len(data))
        if not chunk:
            raise ConnectionError("A conexão fechou antes do pacote completo")
        data.extend(chunk)
    return bytes(data)


def receive_packet(connection):
    header = receive_exact(connection, 7)
    length = int.from_bytes(header[2:5], "big")
    return int.from_bytes(header[:2], "big"), receive_exact(connection, length)


def send_packet(connection, message_id, payload=b""):
    header = message_id.to_bytes(2, "big")
    header += len(payload).to_bytes(3, "big") + b"\x00\x00"
    connection.sendall(header + payload)


class LoopServer:
    def __init__(self):
        self.max_packet_size = 1024 * 1024
        self.crypto_settings = {"Enabled": False}
        self.Clients = {"ClientCounts": 0, "Clients": {}}

    def unregister_client(self, player, client):
        return None


class BattleReturnRegressionTests(BattleAccountTestCase):
    def setUp(self):
        super().setUp()
        GameRoomService.init()
        self.addCleanup(GameRoomService.init)

    def configure_brawler(self, player, brawler_id, trophies=0):
        skin_id = Skins.get_default_skin(brawler_id)
        player.brawler_id = brawler_id
        player.skin_id = skin_id
        player.BrawlersUnlockedState = dict(player.BrawlersUnlockedState)
        player.BrawlersUnlockedState[str(brawler_id)] = 1
        player.brawlers_skins = dict(player.brawlers_skins)
        player.brawlers_skins[str(brawler_id)] = skin_id
        player.brawlers_trophies = dict(player.brawlers_trophies)
        player.brawlers_trophies[str(brawler_id)] = trophies
        player.brawlers_trophies_in_rank = dict(player.brawlers_trophies_in_rank)
        player.brawlers_trophies_in_rank[str(brawler_id)] = trophies
        player.Brawler_level = dict(player.Brawler_level)
        player.Brawler_level[str(brawler_id)] = 4
        player.trophies = trophies
        player.highest_trophies = trophies
        DataBase.replaceValues(SimpleNamespace(player=player), {
            "brawlerID": brawler_id,
            "skinID": skin_id,
            "brawlersSkins": player.brawlers_skins,
            "brawlersTrophies": player.brawlers_trophies,
            "brawlersTrophiesForRank": player.brawlers_trophies_in_rank,
            "brawlerPowerLevel": player.Brawler_level,
            "UnlockedBrawlers": player.BrawlersUnlockedState,
            "trophies": trophies,
            "highest_trophies": trophies,
        })
        return skin_id

    def create_room(self, player, map_id):
        client = CaptureClient()
        message = TeamCreateMessage(client, player, create_payload(map_id))
        message.decode()
        room = message.process()
        entries = BattleParticipants.build(room)
        own_index = BattleParticipants.own_index(entries, player)
        return room, entries, own_index

    def process_battle(self, player, payload):
        client = CaptureClient()
        message = AskForBattleEndMessage(client, player, payload)
        message.decode()
        result = message.process()
        return result, read_native_result(client.payload())

    def process_home(self, player):
        client = CaptureClient()
        message = GoHomeFromOfflinePractiseMessage(client, player, b"\x00")
        message.decode()
        message.process()
        payload = client.payload()
        self.assertEqual(client.message_id, 24101)
        return payload

    def test_every_brawler_survives_room_loading_result_reload_and_home(self):
        for brawler_id in Characters.get_brawlers_id():
            with self.subTest(brawler=brawler_id):
                GameRoomService.init()
                player = self.make_account(1000 + brawler_id, f"brawler-{brawler_id}")
                skin_id = self.configure_brawler(player, brawler_id)
                room, entries, own_index = self.create_room(player, 7)
                self.assertEqual(entries[own_index]["brawler_id"], brawler_id)
                self.assertEqual(entries[own_index]["skin_id"], skin_id)

                loading = StartLoadingMessage(None, player, room, entries)._encode_payload()
                decoded_loading = parse_start_loading(loading)
                self.assertEqual(decoded_loading["members"][own_index]["brawler"], (16, brawler_id))
                self.assertEqual(decoded_loading["members"][own_index]["skin"], (29, skin_id))

                payload = battle_payload(entries, own_index, 7, 0, 0)
                _, response = self.process_battle(player, payload)
                self.assertEqual(response["header"][3], 6)
                self.assertEqual(response["flags"][4], True)
                self.assertEqual(len(response["participants"]), len(entries))
                for index, entry in enumerate(entries):
                    self.assertEqual(response["participants"][index]["brawler"], (16, entry["brawler_id"]))
                    self.assertEqual(response["participants"][index]["skin"], (29, entry["skin_id"]))

                loaded = self.reload(player)
                self.assertEqual(loaded.brawler_id, brawler_id)
                self.assertEqual(loaded.skin_id, skin_id)
                self.assertEqual(loaded.brawlers_trophies[str(brawler_id)], 6)
                home_payload = self.process_home(loaded)
                assert_complete_home(self, home_payload, brawler_id)

    def test_real_message_loop_returns_home_and_keeps_the_connection_open(self):
        cases = (
            ("3v3-victory", 7, 23, 0, 0, 0, 6),
            ("3v3-defeat", 7, 1, 1, 0, 100, -2),
            ("solo-victory", 13, 23, 1, 1, 0, 8),
            ("solo-eighth-low", 13, 20, 8, 8, 0, 2),
            ("solo-defeat", 13, 7, 10, 10, 100, -4),
        )
        for case_index, (label, map_id, brawler_id, result, rank, old_trophies, expected_gain) in enumerate(cases):
            with self.subTest(flow=label):
                GameRoomService.init()
                player = self.make_account(2000 + case_index, f"loop-{label}")
                skin_id = self.configure_brawler(player, brawler_id, old_trophies)
                player.crypto = Crypto({"Enabled": False})
                server = LoopServer()
                player.ClientDict = server.Clients
                server_socket, client_socket = socket.socketpair()
                server_socket.settimeout(3)
                client_socket.settimeout(3)
                thread = ClientThread(server_socket, ("local", 0), server)
                thread.player = player
                server.Clients["Clients"][str(player.low_id)] = {
                    "SocketInfo": server_socket,
                    "Crypto": player.crypto,
                    "Lock": player.send_lock,
                    "Status": 1,
                }
                server.Clients["ClientCounts"] = 1
                thread.start()
                try:
                    send_packet(client_socket, 14366, status_payload(4))
                    send_packet(client_socket, 14350, create_payload(map_id))
                    self.assertEqual(receive_packet(client_socket)[0], 24124)
                    self.assertEqual(receive_packet(client_socket)[0], 24131)
                    room = GameRoomService.for_player(player)
                    self.assertIsNotNone(room)
                    entries = BattleParticipants.build(room)
                    own_index = BattleParticipants.own_index(entries, player)
                    self.assertEqual(entries[own_index]["brawler_id"], brawler_id)
                    self.assertEqual(entries[own_index]["skin_id"], skin_id)

                    send_packet(client_socket, 14355, ready_payload())
                    self.assertEqual(receive_packet(client_socket)[0], 24124)
                    self.assertEqual(receive_packet(client_socket), (20406, b""))

                    payload = battle_payload(entries, own_index, map_id, result, rank)
                    send_packet(client_socket, 14366, status_payload(10))
                    send_packet(client_socket, 14110, payload)
                    message_id, response_payload = receive_packet(client_socket)
                    self.assertEqual(message_id, 23456)
                    response = read_native_result(response_payload)
                    self.assertEqual(response["header"][3], expected_gain)
                    self.assertTrue(response["flags"][4])
                    self.assertEqual(response["participants"][own_index]["brawler"], (16, brawler_id))
                    self.assertEqual(response["participants"][own_index]["skin"], (29, skin_id))

                    send_packet(client_socket, 14366, status_payload(8))
                    send_packet(client_socket, 14109, b"\x00")
                    message_id, home_payload = receive_packet(client_socket)
                    self.assertEqual(message_id, 24101)
                    assert_complete_home(self, home_payload, brawler_id)

                    send_packet(client_socket, 14366, status_payload(-1))
                    send_packet(client_socket, 10108)
                    self.assertEqual(receive_packet(client_socket), (20108, b""))
                    self.assertTrue(thread.is_alive())

                    loaded = self.reload(player)
                    expected_trophies = old_trophies + expected_gain
                    self.assertEqual(loaded.trophies, expected_trophies)
                    self.assertEqual(loaded.brawlers_trophies[str(brawler_id)], expected_trophies)
                    self.assertEqual(loaded.brawler_id, brawler_id)
                    self.assertEqual(loaded.skin_id, skin_id)
                finally:
                    client_socket.close()
                    thread.join(3)
                    self.assertFalse(thread.is_alive())
                    server_socket.close()
