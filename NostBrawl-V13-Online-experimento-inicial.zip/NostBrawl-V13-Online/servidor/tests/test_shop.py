import copy
import importlib.util
import json
import os
import random
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

PROJECT_ROOT = Path(__file__).resolve().parents[1]
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from Database.DatabaseManager import DataBase
from Files.CsvLogic.Cards import Cards
from Files.CsvLogic.Characters import Characters
from Files.CsvLogic.Skins import Skins
from Logic.BillingService import BillingService
from Logic.BoxInventory import BoxInventory
from Logic.EventSlots import EventSlots
from Logic.Player import Players
from Logic.Rewards import RewardError, RewardTransaction
from Logic.ShopCatalog import ShopCatalog
from Logic.ShopService import ShopService
from Packets.Commands.Client.LogicBoxDataEchoCommand import LogicBoxDataEchoCommand
from Packets.Commands.Client.LogicClearShopTickersCommand import LogicClearShopTickersCommand
from Packets.Commands.Client.LogicPurchaseBoxCommand import LogicPurchaseBoxCommand
from Packets.Commands.Client.LogicPurchaseOfferCommand import LogicPurchaseOfferCommand
from Packets.Commands.Server.LogicBuyItem import LogicBuyItem
from Packets.LogicMessageFactory import packets
from Packets.LogicCommandManager import EndClientTurn
from Packets.Messages.Client.Billing.GoogleBillingRequestMessage import GoogleBillingRequestMessage
from Packets.Messages.Server.Billing.BillingRequestFailedMessage import BillingRequestFailedMessage
from Packets.Messages.Server.Billing.BuyBundleBillingPackResponseMessage import BuyBundleBillingPackResponseMessage
from Packets.Messages.Server.Billing.GoogleBillingProcessedByServerMessage import GoogleBillingProcessedByServerMessage
from Packets.Messages.Server.Home.OwnHomeDataMessage import OwnHomeDataMessage
from Utils.Reader import BSMessageReader
from Utils.Writer import Writer
from test_own_home_data_wire import OwnHomeDataReader

NOW = 1700000000
FRIDAY = 1700222400
SATURDAY = 1700308800
SUNDAY = 1700395200
MONDAY = 1700481600
NEXT_SATURDAY = 1700913600


def vint(value):
    writer = Writer(None)
    writer.writeVint(value)
    return writer.buffer


def packet_parts(packet):
    return (
        int.from_bytes(packet[:2], "big"),
        int.from_bytes(packet[2:5], "big"),
        packet[7:],
    )


class CaptureClient:
    def __init__(self):
        self.packets = []

    def sendall(self, data):
        self.packets.append(bytes(data))


class ShopAccountTestCase(unittest.TestCase):
    def setUp(self):
        self.temp_directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp_directory.cleanup)
        self.database_path = str(Path(self.temp_directory.name) / "players.db")
        path_patch = patch.object(DataBase, "_database_path", lambda: self.database_path)
        path_patch.start()
        self.addCleanup(path_patch.stop)
        time_patch = patch("Logic.ShopService.time.time", return_value=NOW)
        time_patch.start()
        self.addCleanup(time_patch.stop)
        self.player, _ = self.make_account(1, "shop-token")

    def make_account(self, low_id, token):
        player = Players(SimpleNamespace())
        player.low_id = low_id
        player.high_id = 0
        player.token = token
        player.name = f"Shop {low_id}"
        DataBase.createAccount(SimpleNamespace(player=player))
        return player, token

    def reload(self, player=None):
        source = player or self.player
        loaded = Players(SimpleNamespace())
        loaded.token = source.token
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=loaded)))
        return loaded

    def echo_box(self, client, player, packet):
        _, _, payload = packet_parts(packet)
        reader = BSMessageReader(payload)
        self.assertEqual(reader.read_Vint(), 203)
        echo = LogicBoxDataEchoCommand(client, player, reader.read())
        echo.decode()
        self.assertEqual(echo.read(), b"")
        result = echo.process()
        return echo, result

    def empty_turn(self, client, player):
        payload = b"".join(vint(value) for value in (0, 0, 0, 0))
        payload += b"\x00" * 4
        turn = EndClientTurn(client, player, payload)
        turn.decode()
        self.assertEqual(turn.command_count, 0)
        return turn.process()

    def echo_box_turn(self, client, player, packet):
        _, _, payload = packet_parts(packet)
        reader = BSMessageReader(payload)
        self.assertEqual(reader.read_Vint(), 203)
        turn_payload = b"".join(vint(value) for value in (0, 0, 0, 1, 203))
        turn_payload += reader.read() + b"\xff" * 4
        turn = EndClientTurn(client, player, turn_payload)
        turn.decode()
        self.assertEqual(turn.command_count, 1)
        self.assertIsNone(turn.process())
        return turn

    def update(self, values):
        self.assertTrue(DataBase.replaceValues(SimpleNamespace(player=self.player), values))
        attributes = {
            "gems": "gems",
            "gold": "gold",
            "brawlBoxes": "brawl_boxes",
            "bigBoxes": "big_boxes",
            "tickets": "tickets",
            "tokensdoubler": "tokensdoubler",
            "UnlockedBrawlers": "BrawlersUnlockedState",
            "brawlersUpgradePoints": "brawlers_upgradium",
            "brawlerStarPower": "Brawler_starPower",
            "brawlerPowerLevel": "Brawler_level",
        }
        for column, value in values.items():
            if column in attributes:
                setattr(self.player, attributes[column], copy.deepcopy(value))

    def offer(self, **changes):
        result = {
            "key": "test",
            "items": [{"offerId": 1, "amount": 50, "value": 0, "target": None}],
            "currency": 0,
            "price": 10,
            "originalPrice": 10,
            "display": 0,
            "expiresAt": NOW + 3600,
            "seen": False,
            "purchased": False,
            "title": "",
            "daily": True,
        }
        result.update(changes)
        if "price" in changes and "originalPrice" not in changes:
            result["originalPrice"] = result["price"]
        return result

    def install(self, offers, player=None):
        player = player or self.player
        state = ShopService.get_state(player)
        state["offers"] = copy.deepcopy(offers)
        ShopService._save_state(player, state)
        return state

    def read_offers(self, reader):
        offers = []
        for _ in range(reader.v()):
            items = []
            for _ in range(reader.v()):
                offer_id, amount = reader.v(), reader.v()
                csv_id = reader.v()
                item_id = reader.v() if csv_id else -1
                value = reader.v()
                items.append((offer_id, amount, (csv_id, item_id), value))
            numeric = [reader.v() for _ in range(5)]
            purchased = reader.b()
            auxiliary = reader.v()
            daily = reader.b()
            original_price = reader.v()
            title = reader.s()
            offers.append({
                "items": items,
                "numeric": numeric,
                "purchased": purchased,
                "auxiliary": auxiliary,
                "daily": daily,
                "originalPrice": original_price,
                "title": title,
            })
        return offers

    def seek_offers(self, reader):
        [reader.v() for _ in range(2)]
        [reader.v() for _ in range(5)]
        reader.v(), reader.v()
        reader.v()
        reader.references()
        reader.references()
        reader.b()
        [reader.v() for _ in range(6)]
        reader.b()
        reader.v()
        reader.b()
        reader.v(), reader.v()
        [reader.b() for _ in range(4)]
        [reader.v() for _ in range(3)]
        reader.b()
        return reader.tell()


class ShopCatalogTests(ShopAccountTestCase):
    def test_csv_catalog_and_new_daily_config_are_complete(self):
        self.assertEqual(sorted(ShopCatalog.shop_items()), list(range(17)))
        self.assertEqual(len(ShopCatalog.billing_packages()), 11)
        config = ShopCatalog.daily_definitions()
        self.assertEqual(len(config["daily"]), 2)
        self.assertEqual(len(config["once"]), 2)
        self.assertNotIn("rotatingBundles", config)
        for definition in config["daily"] + config["once"]:
            self.assertLessEqual(len(definition["items"]), 3)
            for item in definition["items"]:
                self.assertIn(item["offerId"], ShopCatalog.shop_items())
                if item["offerId"] == 0:
                    self.assertEqual(item["value"], 1)
                if item["offerId"] == 8:
                    self.assertEqual((item["amount"], item["value"]), (20, 0))
                    self.assertEqual(item["target"][0], 16)
        big_three, bundle = config["once"]
        self.assertEqual(
            (big_three["key"], big_three["title"]),
            ("the_big_three", "The big Three"),
        )
        self.assertEqual(
            [(item["offerId"], item["amount"], item["target"]) for item in big_three["items"]],
            [(3, 1, [16, 12]), (3, 1, [16, 23]), (3, 1, [16, 5])],
        )
        self.assertEqual(
            (bundle["key"], bundle["title"]),
            ("gems_big_mega", "50 Gemas + 3 BIGBOX + 2 MEGABOX"),
        )
        for offer in (big_three, bundle):
            self.assertEqual((offer["price"], offer["display"]), (0, 1))
        self.assertEqual(
            [(item["offerId"], item["amount"]) for item in bundle["items"]],
            [(16, 50), (14, 3), (10, 2)],
        )
        self.assertEqual(Characters.get_brawler_id_by_name("Ninja"), 23)
        self.assertNotIn(21, Characters.get_brawlers_id())
        self.assertNotIn(22, Characters.get_brawlers_id())
        self.assertEqual(Cards.get_brawler_unlock_by_character(23), 115)
        self.assertEqual(Cards.get_brawler_star_power(23), 119)
        self.assertEqual(Skins.getBrawler(Skins.get_default_skin(23)), 23)
        starter = ShopCatalog.billing_packages()["com.supercell.laser.starterpack1"]
        self.assertEqual(
            (starter["diamonds"], starter["bigBoxCount"], starter["xpLevelReq"]),
            (80, 1, 5),
        )

    def test_catalog_rejects_unsafe_free_box_and_hero_power_items(self):
        invalid_items = [
            {"offerId": 0, "amount": 1, "value": 0, "target": None},
            {"offerId": 8, "amount": 20, "value": 40, "target": None},
            {"offerId": 8, "amount": 20, "value": -1, "target": [16, 0]},
        ]
        for item in invalid_items:
            with self.subTest(item=item), self.assertRaises(ValueError):
                ShopCatalog.validate_item(item)

    def test_removed_shop_modules_stay_removed(self):
        for name in (
            "Logic.Shop",
            "Utils.OfferGenerator",
            "Entries.LogicGemOffer",
        ):
            with self.subTest(name=name):
                self.assertIsNone(importlib.util.find_spec(name))
        self.assertIs(packets[10151], GoogleBillingRequestMessage)


class ShopStateTests(ShopAccountTestCase):
    def test_daily_generation_is_stable_persistent_and_account_isolated(self):
        first = ShopService.get_state(self.player)
        self.assertEqual(len(first["offers"]), 4)
        self.assertEqual(first, ShopService.get_state(self.player))
        self.assertEqual(first, self.reload().progression["shop"])
        second, _ = self.make_account(2, "second-shop-token")
        second_state = ShopService.get_state(second)
        ShopService.clear_tickers(self.player)
        self.assertTrue(all(
            offer["seen"] for offer in self.reload().progression["shop"]["offers"]
        ))
        self.assertFalse(any(
            offer["seen"] for offer in self.reload(second).progression["shop"]["offers"]
        ))
        self.assertEqual(len(second_state["offers"]), 4)

    def test_r53_offer_is_replaced_by_two_new_offers(self):
        for old_claimed in (False, True):
            with self.subTest(old_claimed=old_claimed):
                player, _ = self.make_account(
                    20 + int(old_claimed), f"r53-migration-{old_claimed}"
                )
                old = ShopService.get_state(player)
                old["version"] = 3
                old["offers"] = [
                    offer for offer in old["offers"]
                    if offer["key"] not in {"the_big_three", "gems_big_mega"}
                ]
                old_offer = self.offer(
                    key="test",
                    items=[
                        {"offerId": 10, "amount": 1, "value": 0, "target": None},
                        {"offerId": 14, "amount": 2, "value": 0, "target": None},
                    ],
                    price=0,
                    display=1,
                    daily=False,
                    purchased=old_claimed,
                    title="test",
                )
                old_offer["oneTime"] = True
                old["offers"].append(old_offer)
                old["claimed"] = {"test": True} if old_claimed else {}
                old["billing"]["transactions"]["r53"] = {"product": "legacy"}
                ShopService._save_state(player, old)
                migrated = ShopService.get_state(player)
                self.assertEqual(migrated["version"], 7)
                self.assertFalse(any(
                    offer["key"] in {"test", "mega_box_5"}
                    for offer in migrated["offers"]
                ))
                new_offers = [
                    offer for offer in migrated["offers"]
                    if offer["key"] in {"the_big_three", "gems_big_mega"}
                ]
                self.assertEqual(len(new_offers), 2)
                self.assertTrue(all(not offer["purchased"] for offer in new_offers))
                self.assertEqual(
                    migrated["claimed"].get("test", False), old_claimed
                )
                self.assertNotIn("mega_box_5", migrated["claimed"])
                self.assertEqual(
                    migrated["billing"]["transactions"]["r53"],
                    {"product": "legacy"},
                )

    def test_legacy_claim_migration_replaces_offer_without_replay(self):
        for old_version in (4, 5, 6):
            for old_claimed in (False, True):
                with self.subTest(old_version=old_version, old_claimed=old_claimed):
                    player, _ = self.make_account(
                        40 + old_version * 2 + int(old_claimed),
                        f"shop-migration-{old_version}-{old_claimed}",
                    )
                    old = ShopService.get_state(player)
                    old["version"] = old_version
                    old["offers"] = [
                        offer for offer in old["offers"]
                        if offer["key"] not in {"the_big_three", "gems_big_mega"}
                    ]
                    items = [{
                        "offerId": 10, "amount": 5, "value": 0, "target": None,
                    }]
                    if old_version == 6:
                        items.append({
                            "offerId": 14, "amount": 5, "value": 0, "target": None,
                        })
                    legacy = self.offer(
                        key="mega_box_5",
                        items=items,
                        price=0,
                        display=1,
                        daily=False,
                        purchased=old_claimed,
                        title="legacy",
                    )
                    legacy["oneTime"] = True
                    old["offers"].append(legacy)
                    old["claimed"] = {"mega_box_5": True} if old_claimed else {}
                    receipt = f"r{old_version}"
                    old["billing"]["transactions"][receipt] = {"product": "legacy"}
                    ShopService._save_state(player, old)
                    with patch("Logic.BoxService.generate_rewards") as generate:
                        migrated = ShopService.get_state(player)
                    generate.assert_not_called()
                    self.assertEqual(migrated["version"], 7)
                    self.assertEqual(
                        migrated["claimed"].get("mega_box_5", False), old_claimed
                    )
                    self.assertFalse(any(
                        offer["key"] == "mega_box_5"
                        for offer in migrated["offers"]
                    ))
                    new_offers = [
                        offer for offer in migrated["offers"]
                        if offer["key"] in {"the_big_three", "gems_big_mega"}
                    ]
                    self.assertEqual(len(new_offers), 2)
                    self.assertTrue(all(not offer["purchased"] for offer in new_offers))
                    self.assertNotIn("the_big_three", migrated["claimed"])
                    self.assertNotIn("gems_big_mega", migrated["claimed"])
                    self.assertEqual(
                        migrated["billing"]["transactions"][receipt],
                        {"product": "legacy"},
                    )
                    self.assertEqual(migrated, self.reload(player).progression["shop"])

    def test_two_unlocked_brawlers_generate_two_distinct_power_offers(self):
        brawlers = Characters.get_brawlers_id()[:2]
        self.update({
            "UnlockedBrawlers": {str(brawler): 1 for brawler in brawlers},
            "brawlersUpgradePoints": {str(brawler): 0 for brawler in brawlers},
            "brawlerPowerLevel": {str(brawler): 1 for brawler in brawlers},
        })
        state = ShopService.get_state(self.player)
        power = [offer for offer in state["offers"] if offer["key"] == "power_points"]
        self.assertEqual(len(state["offers"]), 5)
        self.assertEqual(state["offers"][0]["key"], "free_box")
        self.assertEqual(len(power), 2)
        self.assertEqual(
            {offer["items"][0]["target"][1] for offer in power},
            set(brawlers),
        )
        for offer in power:
            item = offer["items"][0]
            self.assertEqual((item["offerId"], item["amount"], item["value"]), (8, 20, 0))
            self.assertEqual((offer["currency"], offer["price"]), (1, 40))

    def test_daily_power_offers_are_limited_to_five_and_stay_persistent(self):
        brawlers = Characters.get_brawlers_id()[:12]
        self.update({
            "UnlockedBrawlers": {str(brawler): 1 for brawler in brawlers},
            "brawlersUpgradePoints": {str(brawler): 0 for brawler in brawlers},
            "brawlerPowerLevel": {str(brawler): 1 for brawler in brawlers},
        })
        state = ShopService.get_state(self.player)
        power = [offer for offer in state["offers"] if offer["key"] == "power_points"]
        self.assertEqual(len(state["offers"]), 8)
        self.assertEqual(len(power), ShopService.MAX_DAILY_POWER_OFFERS)
        self.assertEqual(len({offer["items"][0]["target"][1] for offer in power}), 5)
        self.assertTrue(all(
            offer["items"][0]["target"][1] in brawlers for offer in power
        ))
        self.assertEqual(state, ShopService.get_state(self.player))
        self.assertEqual(state, self.reload().progression["shop"])

    def test_star_power_eligibility_is_not_limited_by_power_offer_cap(self):
        brawlers = Characters.get_brawlers_id()[:12]
        levels = {str(brawler): 1 for brawler in brawlers}
        self.update({
            "UnlockedBrawlers": {str(brawler): 1 for brawler in brawlers},
            "brawlersUpgradePoints": {str(brawler): 0 for brawler in brawlers},
            "brawlerPowerLevel": levels,
        })
        selected = set(ShopService._daily_brawlers(self.player, NOW))
        outside = next(brawler for brawler in brawlers if brawler not in selected)
        levels[str(outside)] = 8
        self.update({"brawlerPowerLevel": levels})
        with patch.object(ShopService, "STAR_POWER_DAILY_CHANCE", 100):
            state = ShopService.get_state(self.player)
        power = [offer for offer in state["offers"] if offer["key"] == "power_points"]
        stars = [offer for offer in state["offers"] if offer["key"].startswith("star_power")]
        self.assertEqual(len(power), 5)
        self.assertEqual([offer["items"][0]["target"][1] for offer in stars], [outside])
        self.assertNotIn(outside, {offer["items"][0]["target"][1] for offer in power})

    def test_daily_star_power_eligibility_price_purchase_and_zero_chance(self):
        self.assertEqual(ShopService.STAR_POWER_DAILY_CHANCE, 5)
        brawlers = Characters.get_brawlers_id()[:3]
        self.update({
            "gold": 2000,
            "UnlockedBrawlers": {str(brawler): 1 for brawler in brawlers},
            "brawlersUpgradePoints": {str(brawler): 0 for brawler in brawlers},
            "brawlerPowerLevel": {str(brawlers[0]): 8, str(brawlers[1]): 7, str(brawlers[2]): 8},
            "brawlerStarPower": {
                str(brawlers[0]): 0,
                str(brawlers[1]): 0,
                str(brawlers[2]): Cards.get_brawler_star_power(brawlers[2]),
            },
        })
        with patch.object(ShopService, "STAR_POWER_DAILY_CHANCE", 100):
            state = ShopService.get_state(self.player)
        stars = [offer for offer in state["offers"] if offer["key"].startswith("star_power")]
        self.assertEqual(len([offer for offer in state["offers"] if offer["key"] == "power_points"]), 3)
        self.assertEqual(len(stars), 1)
        star = stars[0]
        item = star["items"][0]
        self.assertEqual(star["key"], f"star_power_{brawlers[0]}")
        self.assertEqual((star["currency"], star["price"], star["originalPrice"]), (1, 2000, 2000))
        self.assertEqual(item, {
            "offerId": 5,
            "amount": 1,
            "value": 0,
            "target": [16, brawlers[0]],
        })
        with patch.object(ShopService, "STAR_POWER_DAILY_CHANCE", 0):
            without_stars = ShopService._generate(self.player, NOW, state)
        self.assertFalse(any(
            offer["key"].startswith("star_power") for offer in without_stars["offers"]
        ))
        result = ShopService.purchase(self.player, state["offers"].index(star))
        self.assertEqual(result["rewards"], [{
            "type": 8, "amount": 1, "brawler": brawlers[0],
        }])
        self.assertEqual(self.player.gold, 0)
        self.assertEqual(
            self.player.Brawler_starPower[str(brawlers[0])],
            Cards.get_brawler_star_power(brawlers[0]),
        )
        loaded = self.reload()
        self.assertEqual(loaded.gold, 0)
        self.assertTrue(loaded.progression["shop"]["offers"][state["offers"].index(star)]["purchased"])
        with self.assertRaises(RewardError):
            ShopService.purchase(self.player, state["offers"].index(star))

    def test_daily_layout_migration_preserves_matching_purchases_and_billing(self):
        brawlers = Characters.get_brawlers_id()[:12]
        self.update({
            "UnlockedBrawlers": {str(brawler): 1 for brawler in brawlers},
            "brawlersUpgradePoints": {str(brawler): 0 for brawler in brawlers},
            "brawlerPowerLevel": {str(brawler): 1 for brawler in brawlers},
        })
        with patch.object(ShopService, "MAX_DAILY_POWER_OFFERS", 8):
            old = ShopService.get_state(self.player)
        old["version"] = 2
        old["offers"] = [
            offer for offer in old["offers"]
            if offer["key"] not in {"the_big_three", "gems_big_mega"}
        ]
        old["offers"][0]["purchased"] = True
        old["offers"][0]["seen"] = True
        old["offers"][1]["purchased"] = True
        for offer in old["offers"]:
            if offer["key"] == "power_points":
                offer["items"][0]["value"] = 40
        purchased_brawler = old["offers"][1]["items"][0]["target"][1]
        old["billing"]["transactions"]["receipt"] = {"product": "pack"}
        ShopService._save_state(self.player, old)
        migrated = ShopService.get_state(self.player)
        self.assertEqual(migrated["version"], ShopService.STATE_VERSION)
        self.assertEqual(len(migrated["offers"]), 8)
        self.assertTrue(migrated["offers"][0]["purchased"])
        self.assertTrue(migrated["offers"][0]["seen"])
        power = [offer for offer in migrated["offers"] if offer["key"] == "power_points"]
        self.assertEqual(len(power), 5)
        self.assertEqual(len({offer["items"][0]["target"][1] for offer in power}), 5)
        for offer in power:
            expected = offer["items"][0]["target"][1] == purchased_brawler
            self.assertEqual(offer["purchased"], expected)
            self.assertEqual(offer["items"][0]["value"], 0)
        self.assertEqual(migrated["billing"]["transactions"]["receipt"], {"product": "pack"})
        self.assertEqual(migrated, self.reload().progression["shop"])

    def test_new_day_resets_daily_offers_and_preserves_billing_history(self):
        state = ShopService.get_state(self.player)
        state["offers"][0]["purchased"] = True
        state["billing"]["transactions"]["abc"] = {"product": "pack"}
        ShopService._save_state(self.player, state)
        with patch("Logic.ShopService.time.time", return_value=NOW + 86400):
            refreshed = ShopService.get_state(self.player)
        self.assertNotEqual(refreshed["day"], state["day"])
        self.assertFalse(any(offer["purchased"] for offer in refreshed["offers"]))
        self.assertEqual(refreshed["billing"]["transactions"]["abc"], {"product": "pack"})
        self.assertEqual(refreshed, self.reload().progression["shop"])

    def test_expired_offer_is_removed_without_touching_other_offers(self):
        state = self.install([
            self.offer(key="expired", expiresAt=NOW - 1),
            self.offer(key="active", expiresAt=NOW + 100),
        ])
        self.assertEqual(len(state["offers"]), 2)
        current = ShopService.get_state(self.player)
        self.assertEqual([offer["key"] for offer in current["offers"]], ["active"])
        self.assertEqual(current, self.reload().progression["shop"])

    def test_previous_state_is_relocated_without_losing_history(self):
        state = ShopService.get_state(self.player)
        state["offers"][0]["purchased"] = True
        state["offers"][0]["seen"] = True
        state["billing"]["transactions"]["receipt"] = {"product": "pack"}
        state["billing"]["bundles"]["starter"] = {"quantity": 1}
        progression = copy.deepcopy(self.player.progression)
        progression.pop(ShopService.STATE_KEY, None)
        progression["previous_shop"] = copy.deepcopy(state)
        self.assertTrue(DataBase.replaceValues(
            SimpleNamespace(player=self.player), {"progression": progression}
        ))
        self.player.progression = progression
        migrated = ShopService.get_state(self.player)
        self.assertTrue(migrated["offers"][0]["purchased"])
        self.assertTrue(migrated["offers"][0]["seen"])
        self.assertEqual(
            migrated["billing"]["transactions"]["receipt"], {"product": "pack"}
        )
        loaded = self.reload()
        self.assertNotIn("previous_shop", loaded.progression)
        self.assertEqual(loaded.progression[ShopService.STATE_KEY], migrated)
        progression = copy.deepcopy(loaded.progression)
        progression["previous_shop"] = copy.deepcopy(state)
        progression["previous_shop"]["offers"][0]["purchased"] = False
        self.assertTrue(DataBase.replaceValues(
            SimpleNamespace(player=loaded), {"progression": progression}
        ))
        loaded.progression = progression
        canonical = ShopService.get_state(loaded)
        self.assertTrue(canonical["offers"][0]["purchased"])
        reloaded = self.reload()
        self.assertNotIn("previous_shop", reloaded.progression)
        self.assertEqual(reloaded.progression[ShopService.STATE_KEY], canonical)

    def test_clear_tickers_decoder_and_persistence(self):
        self.install([self.offer()])
        payload = b"".join(vint(0) for _ in range(4))
        payload += b"".join(vint(value) for value in (7, 8, 9)) + b"x"
        command = LogicClearShopTickersCommand(None, self.player, payload)
        command.decode()
        self.assertEqual(command.read(), b"x")
        result = command.process()
        self.assertEqual(result, {"cleared": True, "count": 1})
        self.assertTrue(self.reload().progression["shop"]["offers"][0]["seen"])
        self.assertEqual(command.process(), {"cleared": False, "count": 1})


class WeekendTicketTests(ShopAccountTestCase):
    def test_two_tickets_are_granted_once_per_weekend_and_persist(self):
        self.update({"tickets": 5})
        ShopService.get_state(self.player, FRIDAY)
        self.assertEqual(self.player.tickets, 5)
        self.assertNotIn(
            ShopService.WEEKEND_TICKET_STATE_KEY, self.player.progression
        )

        ShopService.get_state(self.player, SATURDAY)
        self.assertEqual(self.player.tickets, 7)
        claims = self.player.progression[ShopService.WEEKEND_TICKET_STATE_KEY]["claims"]
        self.assertEqual(claims, {"2023-11-18": True})

        ShopService.get_state(self.player, SATURDAY + 3600)
        self.assertEqual(self.player.tickets, 7)
        loaded = self.reload()
        self.assertEqual(loaded.tickets, 7)
        ShopService.get_state(loaded, SUNDAY)
        self.assertEqual(loaded.tickets, 7)
        self.assertEqual(self.reload(loaded).tickets, 7)

        ShopService.get_state(loaded, MONDAY)
        self.assertEqual(loaded.tickets, 7)
        ShopService.get_state(loaded, NEXT_SATURDAY)
        self.assertEqual(loaded.tickets, 9)
        persisted = self.reload(loaded)
        self.assertEqual(persisted.tickets, 9)
        self.assertEqual(
            persisted.progression[ShopService.WEEKEND_TICKET_STATE_KEY]["claims"],
            {"2023-11-18": True, "2023-11-25": True},
        )

    def test_first_login_on_sunday_also_grants_the_same_weekend_once(self):
        self.update({"tickets": 0})
        self.assertTrue(ShopService.sync_weekend_tickets(self.player, SUNDAY))
        self.assertEqual(self.player.tickets, 2)
        self.assertFalse(ShopService.sync_weekend_tickets(self.player, SUNDAY))
        self.assertEqual(self.player.tickets, 2)
        self.assertEqual(
            self.player.progression[ShopService.WEEKEND_TICKET_STATE_KEY]["claims"],
            {"2023-11-18": True},
        )
        loaded = self.reload()
        self.assertFalse(ShopService.sync_weekend_tickets(loaded, SUNDAY + 7200))
        self.assertEqual(loaded.tickets, 2)


class ShopPurchaseTests(ShopAccountTestCase):
    def test_coin_offer_charges_once_and_replay_is_persistent(self):
        self.update({"gems": 100, "gold": 100})
        self.install([self.offer()])
        result = ShopService.purchase(self.player, 0, rng=random.Random(1))
        self.assertEqual(result["rewards"], [{"type": 1, "amount": 50}])
        self.assertEqual(result["storedBoxes"], [])
        self.assertEqual((self.player.gems, self.player.gold), (90, 150))
        with self.assertRaises(RewardError):
            ShopService.purchase(self.player, 0)
        self.assertEqual((self.player.gems, self.player.gold), (90, 150))
        loaded = self.reload()
        self.assertEqual((loaded.gems, loaded.gold), (90, 150))
        self.assertTrue(loaded.progression["shop"]["offers"][0]["purchased"])
        with self.assertRaises(RewardError):
            ShopService.purchase(loaded, 0)
        self.assertEqual((loaded.gems, loaded.gold), (90, 150))

    def test_bundle_applies_three_items_in_one_transaction(self):
        self.update({"gems": 100, "gold": 10, "tickets": 0, "tokensdoubler": 0})
        self.install([self.offer(
            key="bundle",
            items=[
                {"offerId": 1, "amount": 50, "value": 0, "target": None},
                {"offerId": 9, "amount": 500, "value": 0, "target": None},
                {"offerId": 7, "amount": 2, "value": 0, "target": None},
            ],
            price=25,
        )])
        result = ShopService.purchase(self.player, 0)
        self.assertEqual(len(result["rewards"]), 3)
        self.assertEqual(result["storedBoxes"], [])
        self.assertEqual(self.player.gems, 75)
        self.assertEqual(self.player.gold, 60)
        self.assertEqual(self.player.tokensdoubler, 500)
        self.assertEqual(self.player.tickets, 2)
        loaded = self.reload()
        self.assertEqual((loaded.gems, loaded.gold, loaded.tokensdoubler, loaded.tickets), (75, 60, 500, 2))

    def test_insufficient_funds_and_invalid_reward_are_atomic(self):
        self.update({"gems": 100, "gold": 100})
        self.install([self.offer(price=101)])
        with self.assertRaises(RewardError):
            ShopService.purchase(self.player, 0)
        self.assertEqual((self.player.gems, self.player.gold), (100, 100))
        self.install([self.offer(
            price=10,
            items=[{"offerId": 11, "amount": 1, "value": 0, "target": None}],
        )])
        with self.assertRaises(RewardError):
            ShopService.purchase(self.player, 0)
        self.assertEqual((self.player.gems, self.player.gold), (100, 100))
        stored = self.reload().progression["shop"]["offers"][0]
        self.assertFalse(stored["purchased"])

    def test_first_generated_power_points_are_positive_immediately_and_persistent(self):
        self.update({
            "gold": 40,
            "UnlockedBrawlers": {"0": 1},
            "brawlersUpgradePoints": {"0": 0},
            "brawlerPowerLevel": {"0": 0},
        })
        state = ShopService.get_state(self.player)
        index = next(
            index for index, offer in enumerate(state["offers"])
            if offer["key"] == "power_points"
        )
        self.assertEqual(state["offers"][index]["items"][0]["value"], 0)
        client = CaptureClient()
        command = LogicPurchaseOfferCommand(client, self.player, b"")
        command.offer_index = index
        command.target_reference = (0, -1)
        result = command.process()
        self.assertEqual(result["rewards"], [{
            "type": 5, "amount": 20, "brawler": 0,
        }])
        self.assertEqual((self.player.gold, self.player.brawlers_upgradium["0"]), (0, 20))
        self.assertEqual(len(client.packets), 1)
        packet_id, _, payload = packet_parts(client.packets[0])
        self.assertEqual(packet_id, 24111)
        reader = BSMessageReader(payload)
        self.assertEqual([reader.read_Vint() for _ in range(5)], [203, 0, 1, 100, 1])
        self.assertEqual(reader.read_Vint(), 20)
        self.assertEqual((reader.read_Vint(), reader.read_Vint()), (16, 0))
        self.assertEqual([reader.read_Vint() for _ in range(3)], [6, 0, 0])
        self.assertEqual(reader.read_Vint(), 0)
        self.assertEqual([reader.read_Vint() for _ in range(5)], [0, 0, 0, 0, 0])
        self.assertEqual(reader.read(), b"")
        loaded = self.reload()
        self.assertEqual((loaded.gold, loaded.brawlers_upgradium["0"]), (0, 20))

    def test_first_power_points_after_new_unlock_keep_zero_based_level(self):
        transaction = RewardTransaction(self.player)
        transaction.add_reward("Brawler", 23)
        transaction.commit()
        self.assertEqual(self.player.Brawler_level["23"], 0)
        self.assertEqual(self.player.brawlers_upgradium["23"], 0)
        self.install([self.offer(
            key="first_power_points",
            items=[{
                "offerId": 8,
                "amount": 20,
                "value": 0,
                "target": [16, 23],
            }],
            price=0,
        )])

        client = CaptureClient()
        command = LogicPurchaseOfferCommand(client, self.player, b"")
        command.offer_index = 0
        command.target_reference = (16, 23)
        result = command.process()
        self.assertEqual(result["rewards"], [{
            "type": 5, "amount": 20, "brawler": 23,
        }])
        self.assertEqual(self.player.brawlers_upgradium["23"], 20)
        self.assertEqual(self.player.Brawler_level["23"], 0)
        self.assertEqual(len(client.packets), 1)
        self.echo_box_turn(client, self.player, client.packets[0])
        self.assertEqual(self.player.brawlers_upgradium["23"], 20)
        loaded = self.reload()
        self.assertEqual(loaded.brawlers_upgradium["23"], 20)
        self.assertEqual(loaded.Brawler_level["23"], 0)

    def test_the_big_three_offer_delivers_crow_leon_spike_once(self):
        self.update({
            "gold": 70,
            "gems": 90,
            "UnlockedBrawlers": {"0": 1, "12": 1},
            "brawlersUpgradePoints": {"12": 321},
            "brawlerPowerLevel": {"12": 7},
        })
        state = ShopService.get_state(self.player)
        index = next(
            index for index, offer in enumerate(state["offers"])
            if offer["key"] == "the_big_three"
        )
        offer = state["offers"][index]
        self.assertEqual(
            (offer["title"], offer["price"], offer["daily"]),
            ("The big Three", 0, False),
        )
        self.assertTrue(offer["oneTime"])
        self.assertEqual(
            [(item["offerId"], item["amount"], item["target"]) for item in offer["items"]],
            [(3, 1, [16, 12]), (3, 1, [16, 23]), (3, 1, [16, 5])],
        )
        self.assertTrue(any(
            item["key"] == "gems_big_mega" and not item["purchased"]
            for item in state["offers"]
        ))
        client = CaptureClient()
        command = LogicPurchaseOfferCommand(client, self.player, b"")
        command.offer_index = index
        command.target_reference = (0, -1)
        with patch("Logic.BoxService.generate_rewards") as generate:
            result = command.process()
        generate.assert_not_called()
        self.assertEqual(result["rewards"], [
            {"type": 6, "amount": 1, "brawler": 12},
            {"type": 6, "amount": 1, "brawler": 23},
            {"type": 6, "amount": 1, "brawler": 5},
        ])
        self.assertEqual(result["storedBoxes"], [])
        self.assertEqual(result["openedBoxes"], [])
        self.assertEqual(len(result["responses"]), 1)
        self.assertEqual(result["responses"][0]["kind"], "item")
        self.assertEqual(len(client.packets), 1)
        for brawler in (12, 23, 5):
            self.assertEqual(self.player.BrawlersUnlockedState[str(brawler)], 1)
        self.assertEqual(self.player.brawlers_upgradium["12"], 321)
        self.assertEqual(self.player.Brawler_level["12"], 7)
        for brawler in (23, 5):
            self.assertEqual(self.player.brawlers_upgradium[str(brawler)], 0)
            self.assertEqual(self.player.Brawler_level[str(brawler)], 0)
        leon_position = self.player.brawlers_id.index(23)
        self.assertEqual(self.player.card_unlock_id[leon_position], 115)
        self.assertTrue(self.player.progression["shop"]["claimed"]["the_big_three"])
        self.assertNotIn("gems_big_mega", self.player.progression["shop"]["claimed"])

        packet_id, _, payload = packet_parts(client.packets[0])
        self.assertEqual(packet_id, 24111)
        reader = BSMessageReader(payload)
        self.assertEqual([reader.read_Vint() for _ in range(5)], [203, 0, 1, 100, 3])
        for brawler in (12, 23, 5):
            self.assertEqual(
                [reader.read_Vint() for _ in range(6)],
                [1, 16, brawler, 1, 0, 0],
            )
        self.assertEqual([reader.read_Vint() for _ in range(6)], [0] * 6)
        self.assertEqual(reader.read(), b"")

        home = OwnHomeDataMessage(None, self.player)
        home.encode()
        self.assertGreater(len(home.buffer), 100)
        loaded = self.reload()
        for brawler in (12, 23, 5):
            self.assertEqual(loaded.BrawlersUnlockedState[str(brawler)], 1)
        self.assertEqual(loaded.brawlers_upgradium["12"], 321)
        self.assertEqual(loaded.Brawler_level["12"], 7)
        self.assertTrue(loaded.progression["shop"]["claimed"]["the_big_three"])
        with self.assertRaises(RewardError):
            ShopService.purchase(loaded, index)
        with patch("Logic.ShopService.time.time", return_value=NOW + 86400):
            rotated = ShopService.get_state(loaded)
        self.assertFalse(any(
            item["key"] in {"the_big_three", "mega_box_5"}
            for item in rotated["offers"]
        ))
        self.assertTrue(any(
            item["key"] == "gems_big_mega" and not item["purchased"]
            for item in rotated["offers"]
        ))
        self.assertTrue(rotated["claimed"]["the_big_three"])
        second, _ = self.make_account(2, "second-big-three-token")
        second_state = ShopService.get_state(second)
        self.assertTrue(all(
            any(offer["key"] == key and not offer["purchased"] for offer in second_state["offers"])
            for key in ("the_big_three", "gems_big_mega")
        ))

    def test_gems_big_mega_offer_is_free_complete_persistent_and_never_regenerated(self):
        self.update({"gold": 70, "gems": 90, "bigBoxes": 0, "brawlBoxes": 0})
        state = ShopService.get_state(self.player)
        index = next(
            index for index, offer in enumerate(state["offers"])
            if offer["key"] == "gems_big_mega"
        )
        offer = state["offers"][index]
        self.assertEqual(
            (offer["title"], offer["price"], offer["daily"]),
            ("50 Gemas + 3 BIGBOX + 2 MEGABOX", 0, False),
        )
        self.assertTrue(offer["oneTime"])
        self.assertEqual(
            [(item["offerId"], item["amount"]) for item in offer["items"]],
            [(16, 50), (14, 3), (10, 2)],
        )
        self.assertTrue(any(
            item["key"] == "the_big_three" and not item["purchased"]
            for item in state["offers"]
        ))
        self.assertFalse(any(item.get("storedBox") for item in state["offers"]))
        client = CaptureClient()
        command = LogicPurchaseOfferCommand(client, self.player, b"")
        command.offer_index = index
        command.target_reference = (0, -1)

        def generated(player, box_type, rng, box_count=1):
            return [{"name": "Coins", "amount": 10 * box_count, "target": 0}]

        with patch("Logic.BoxService.generate_rewards", side_effect=generated) as generate:
            result = command.process()
            self.assertEqual(generate.call_count, 5)
            self.assertEqual(
                [call.args[1] for call in generate.call_args_list],
                [12] * 3 + [11] * 2,
            )
            self.assertTrue(all(
                call.kwargs["box_count"] == 1
                for call in generate.call_args_list
            ))
            self.assertEqual(result["rewards"], [{"type": 2, "amount": 50}])
            self.assertEqual(result["storedBoxes"], [])
            self.assertEqual(len(result["openedBoxes"]), 2)
            for opened, box_type, count in zip(result["openedBoxes"], (12, 11), (3, 2)):
                self.assertEqual((opened["boxType"], opened["boxCount"]), (box_type, count))
                self.assertEqual(opened["initial"], count)
                self.assertEqual(opened["unitCount"], count)
                self.assertEqual(opened["rewards"], [10] * count)
                self.assertEqual(opened["rewardNames"], ["Coins"] * count)
                self.assertEqual(len(opened["rewardUnits"]), count)
                for unit in opened["rewardUnits"]:
                    self.assertEqual((unit["boxType"], unit["boxCount"]), (box_type, 1))
                    self.assertEqual(unit["rewards"], [10])
            self.assertEqual(len(result["responses"]), 1)
            self.assertEqual(result["responses"][0]["kind"], "box")
            combined = result["responses"][0]["result"]
            self.assertEqual((combined["boxType"], combined["boxCount"]), (12, 5))
            self.assertEqual(combined["initial"], 5)
            self.assertEqual(combined["unitCount"], 5)
            self.assertEqual(combined["rewards"], [50] + [10] * 5)
            self.assertEqual(combined["rewardNames"], ["gems"] + ["Coins"] * 5)
            self.assertEqual(
                [unit["boxType"] for unit in combined["rewardUnits"]],
                [12] * 3 + [11] * 2,
            )
            self.assertEqual(combined["rewardUnits"][0]["rewards"], [50, 10])
            self.assertEqual(combined["rewardUnits"][0]["rewardNames"], ["gems", "Coins"])
            for unit in combined["rewardUnits"][1:]:
                self.assertEqual(unit["rewards"], [10])
            self.assertEqual((self.player.gold, self.player.gems), (120, 140))
            self.assertEqual(BoxInventory.count(self.player, 11), 0)
            self.assertEqual(BoxInventory.count(self.player, 12), 0)
            self.assertTrue(self.player.progression["shop"]["claimed"]["gems_big_mega"])
            self.assertNotIn("the_big_three", self.player.progression["shop"]["claimed"])
            self.assertEqual(len(client.packets), 1)

            echo, ignored = self.echo_box(client, self.player, client.packets[0])
            self.assertIsNone(ignored)
            self.assertEqual((echo.box_count_or_type, echo.box_id), (5, 12))
            self.assertEqual(echo.box_count, 5)
            self.assertEqual(len(echo.reward_units), 5)
            self.assertEqual(len(echo.rewards), 6)
            self.assertEqual(
                [unit_type for unit_type, _ in echo.reward_units],
                [12] * 3 + [11] * 2,
            )
            self.assertEqual(len(echo.reward_units[0][1]), 2)
            for _, unit_rewards in echo.reward_units[1:]:
                self.assertEqual(len(unit_rewards), 1)
            self.assertIsNone(self.empty_turn(client, self.player))
            self.assertEqual(len(client.packets), 1)
            self.assertEqual(generate.call_count, 5)

        packet_id, _, payload = packet_parts(client.packets[0])
        self.assertEqual(packet_id, 24111)
        reader = BSMessageReader(payload)
        self.assertEqual([reader.read_Vint() for _ in range(5)], [203, 5, 5, 12, 2])
        self.assertEqual([reader.read_Vint() for _ in range(5)], [50, 0, 8, 0, 0])
        self.assertEqual([reader.read_Vint() for _ in range(5)], [10, 0, 7, 0, 0])
        for unit_index in range(1, 5):
            unit_type = 12 if unit_index < 3 else 11
            self.assertEqual([reader.read_Vint() for _ in range(2)], [unit_type, 1])
            self.assertEqual([reader.read_Vint() for _ in range(5)], [10, 0, 7, 0, 0])
        self.assertEqual([reader.read_Vint() for _ in range(6)], [0] * 6)
        self.assertEqual(reader.read(), b"")

        loaded = self.reload()
        self.assertEqual((loaded.gold, loaded.gems, loaded.big_boxes), (120, 140, 0))
        self.assertEqual(BoxInventory.count(loaded, 11), 0)
        self.assertEqual(BoxInventory.count(loaded, 12), 0)
        self.assertTrue(loaded.progression["shop"]["claimed"]["gems_big_mega"])
        with self.assertRaises(RewardError):
            ShopService.purchase(loaded, index)
        with patch("Logic.ShopService.time.time", return_value=NOW + 86400):
            rotated = ShopService.get_state(loaded)
        self.assertFalse(any(
            offer["key"] in {"gems_big_mega", "mega_box_5"}
            for offer in rotated["offers"]
        ))
        self.assertTrue(any(
            offer["key"] == "the_big_three" and not offer["purchased"]
            for offer in rotated["offers"]
        ))
        self.assertTrue(rotated["claimed"]["gems_big_mega"])

    def test_special_box_units_observe_previous_pending_rewards(self):
        target = 1
        self.update({
            "gold": 0,
            "gems": 0,
            "UnlockedBrawlers": {"0": 1},
            "brawlersUpgradePoints": {"0": 0},
            "brawlerPowerLevel": {"0": 1},
        })
        state = ShopService.get_state(self.player)
        index = next(
            index for index, offer in enumerate(state["offers"])
            if offer["key"] == "gems_big_mega"
        )
        seen = []

        def generated(player, box_type, rng, box_count=1):
            seen.append(player.BrawlersUnlockedState.get(str(target), 0))
            if len(seen) == 1:
                return [{"name": "Brawler", "amount": target, "target": 0}]
            if len(seen) == 2:
                return [{"name": "UpgradePoints", "amount": 9, "target": target}]
            return [{"name": "Coins", "amount": 1, "target": 0}]

        with patch("Logic.BoxService.generate_rewards", side_effect=generated):
            result = ShopService.purchase(self.player, index)
        self.assertEqual(seen, [0] + [1] * 4)
        big = result["openedBoxes"][0]
        self.assertEqual(big["boxType"], 12)
        self.assertEqual(big["rewardUnits"][0]["rewardNames"], ["Brawler"])
        self.assertEqual(big["rewardUnits"][1]["rewardNames"], ["UpgradePoints"])
        self.assertEqual(self.player.BrawlersUnlockedState[str(target)], 1)
        self.assertEqual(self.player.brawlers_upgradium[str(target)], 9)
        self.assertEqual((self.player.gold, self.player.gems), (3, 50))
        loaded = self.reload()
        self.assertEqual(loaded.BrawlersUnlockedState[str(target)], 1)
        self.assertEqual(loaded.brawlers_upgradium[str(target)], 9)
        self.assertEqual((loaded.gold, loaded.gems), (3, 50))

    def test_real_generator_delivers_three_big_two_mega_and_gems_without_skins(self):
        for seed in range(40):
            with self.subTest(seed=seed):
                self.player, self.owner = self.make_account(
                    5000 + seed, f"real-mega-big-{seed}"
                )
                self.update({
                    "gold": 0,
                    "gems": 1000,
                    "brawlBoxes": 0,
                    "bigBoxes": 0,
                    "UnlockedSkins": {"Skins": []},
                })
                state = ShopService.get_state(self.player)
                index = next(
                    index for index, offer in enumerate(state["offers"])
                    if offer["key"] == "gems_big_mega"
                )
                result = ShopService.purchase(
                    self.player, index, rng=random.Random(seed)
                )
                self.assertEqual(result["storedBoxes"], [])
                self.assertEqual(len(result["openedBoxes"]), 2)
                details = []
                for opened, box_type, count in zip(result["openedBoxes"], (12, 11), (3, 2)):
                    self.assertEqual((opened["boxType"], opened["boxCount"]), (box_type, count))
                    self.assertEqual(opened["initial"], count)
                    self.assertEqual(len(opened["rewardUnits"]), count)
                    self.assertNotIn("Skin", opened["rewardNames"])
                    self.assertTrue(opened["rewards"])
                    self.assertTrue(all(amount >= 0 for amount in opened["rewards"]))
                    for unit in opened["rewardUnits"]:
                        self.assertEqual((unit["boxType"], unit["boxCount"]), (box_type, 1))
                        self.assertTrue(unit["rewards"])
                        self.assertNotIn("Skin", unit["rewardNames"])
                    details.extend(opened["rewardDetails"])
                self.assertEqual(len(result["responses"]), 1)
                combined = result["responses"][0]["result"]
                self.assertEqual(combined["unitCount"], 5)
                self.assertEqual(
                    [unit["boxType"] for unit in combined["rewardUnits"]],
                    [12] * 3 + [11] * 2,
                )
                self.assertEqual(combined["rewardUnits"][0]["rewardNames"][0], "gems")
                self.assertEqual(self.player.UnlockedSkins["Skins"], [])
                expected_gold = sum(
                    detail["amount"] for detail in details
                    if detail["name"] == "Coins"
                )
                expected_gems = 1050 + sum(
                    detail["amount"] for detail in details
                    if detail["name"] == "gems"
                )
                self.assertEqual(self.player.gold, expected_gold)
                self.assertEqual(self.player.gems, expected_gems)
                self.assertEqual(BoxInventory.count(self.player, 11), 0)
                self.assertEqual(BoxInventory.count(self.player, 12), 0)
                with self.assertRaises(RewardError):
                    ShopService.purchase(self.player, index)
                loaded = self.reload()
                self.assertEqual(loaded.gold, expected_gold)
                self.assertEqual(loaded.gems, expected_gems)
                self.assertEqual(loaded.UnlockedSkins["Skins"], [])
                self.assertTrue(loaded.progression["shop"]["claimed"]["gems_big_mega"])
                with self.assertRaises(RewardError):
                    ShopService.purchase(loaded, index)

    def test_gems_big_mega_echoes_and_empty_turns_do_not_open_inventory(self):
        self.update({"gold": 70, "gems": 90, "bigBoxes": 0, "brawlBoxes": 0})
        state = ShopService.get_state(self.player)
        index = next(
            index for index, offer in enumerate(state["offers"])
            if offer["key"] == "gems_big_mega"
        )
        client = CaptureClient()
        command = LogicPurchaseOfferCommand(client, self.player, b"")
        command.offer_index = index
        command.target_reference = (0, -1)

        def generated(player, box_type, rng, box_count=1):
            return [{"name": "Coins", "amount": 9 * box_count, "target": 0}]

        with patch("Logic.BoxService.generate_rewards", side_effect=generated) as generate:
            command.process()
            self.assertEqual(len(client.packets), 1)
            for _ in range(2):
                box_echo = self.echo_box_turn(client, self.player, client.packets[0])
                self.assertEqual(box_echo.box_id, 12)
                self.assertEqual(box_echo.box_count, 5)
                self.assertEqual(len(box_echo.reward_units), 5)
                self.assertEqual(len(box_echo.reward_units[0][1]), 2)
                self.assertEqual(
                    [unit_type for unit_type, _ in box_echo.reward_units],
                    [12] * 3 + [11] * 2,
                )
                self.assertIsNone(self.empty_turn(client, self.player))
                self.assertEqual(len(client.packets), 1)
                self.assertEqual(BoxInventory.count(self.player, 11), 0)
                self.assertEqual(BoxInventory.count(self.player, 12), 0)
            self.assertEqual(generate.call_count, 5)
        self.assertEqual((self.player.gold, self.player.gems), (115, 140))
        loaded = self.reload()
        self.assertEqual((loaded.gold, loaded.gems), (115, 140))
        replay_client = CaptureClient()
        _, ignored = self.echo_box(replay_client, loaded, client.packets[0])
        self.assertIsNone(ignored)
        self.assertIsNone(self.empty_turn(replay_client, loaded))
        self.assertEqual(replay_client.packets, [])

    def test_gems_big_mega_rewards_survive_reconnect_before_echo(self):
        self.update({"gold": 70, "gems": 90, "bigBoxes": 0, "brawlBoxes": 0})
        state = ShopService.get_state(self.player)
        index = next(
            index for index, offer in enumerate(state["offers"])
            if offer["key"] == "gems_big_mega"
        )
        client = CaptureClient()
        command = LogicPurchaseOfferCommand(client, self.player, b"")
        command.offer_index = index
        command.target_reference = (0, -1)
        with patch(
            "Logic.BoxService.generate_rewards",
            return_value=[{"name": "Coins", "amount": 7, "target": 0}],
        ) as generate:
            command.process()
        self.assertEqual(generate.call_count, 5)
        self.assertEqual(len(client.packets), 1)
        self.assertEqual((self.player.gold, self.player.gems), (105, 140))
        loaded = self.reload()
        self.assertEqual((loaded.gold, loaded.gems, loaded.big_boxes), (105, 140, 0))
        self.assertEqual(BoxInventory.count(loaded, 11), 0)
        self.assertEqual(BoxInventory.count(loaded, 12), 0)
        self.assertTrue(loaded.progression["shop"]["claimed"]["gems_big_mega"])
        replay_client = CaptureClient()
        box_echo, ignored = self.echo_box(replay_client, loaded, client.packets[0])
        self.assertIsNone(ignored)
        self.assertEqual(box_echo.box_count, 5)
        self.assertEqual(len(box_echo.reward_units), 5)
        self.assertEqual(len(box_echo.reward_units[0][1]), 2)
        self.assertEqual(
            [unit_type for unit_type, _ in box_echo.reward_units],
            [12] * 3 + [11] * 2,
        )
        self.assertIsNone(self.empty_turn(replay_client, loaded))
        self.assertEqual(replay_client.packets, [])
        with self.assertRaises(RewardError):
            ShopService.purchase(loaded, index)

    def test_stored_boxes_remain_recoverable_without_old_bundle(self):
        self.update({"gold": 70, "gems": 90, "bigBoxes": 0, "brawlBoxes": 0})
        transaction = RewardTransaction(self.player)
        BoxInventory.add(transaction, 11, 1)
        BoxInventory.add(transaction, 12, 2)
        transaction.commit()
        loaded = self.reload()
        stored_state = ShopService.get_state(loaded)
        stored = {
            offer["storedBox"]: offer
            for offer in stored_state["offers"] if offer.get("storedBox")
        }
        self.assertEqual(set(stored), {11, 12})
        remaining = []
        with patch(
            "Logic.BoxService.generate_rewards",
            return_value=[{"name": "Coins", "amount": 1, "target": 0}],
        ) as generate:
            for box_type in (11, 12, 12):
                current = ShopService.get_state(loaded)
                offer_index = next(
                    index for index, offer in enumerate(current["offers"])
                    if offer.get("storedBox") == box_type
                )
                opening_client = CaptureClient()
                opening = LogicPurchaseOfferCommand(opening_client, loaded, b"")
                opening.offer_index = offer_index
                opening.target_reference = (0, -1)
                opened = opening.process()
                self.assertEqual(opened["openingSource"], "storedOffer")
                self.assertEqual(opened["boxType"], box_type)
                remaining.append(opened["storedBoxes"])
                self.assertEqual(len(opening_client.packets), 1)
        self.assertEqual(generate.call_count, 3)
        self.assertEqual(remaining, [0, 1, 0])
        self.assertEqual((loaded.gold, loaded.gems, loaded.big_boxes), (73, 90, 0))
        self.assertEqual(BoxInventory.count(loaded, 11), 0)
        self.assertEqual(BoxInventory.count(loaded, 12), 0)
        final = self.reload()
        self.assertEqual((final.gold, final.gems, final.big_boxes), (73, 90, 0))

    def test_gems_big_mega_failure_is_atomic_and_retryable(self):
        self.update({"gold": 70, "gems": 90, "bigBoxes": 0, "brawlBoxes": 0})
        state = ShopService.get_state(self.player)
        index = next(
            index for index, offer in enumerate(state["offers"])
            if offer["key"] == "gems_big_mega"
        )
        with patch(
            "Logic.BoxService.generate_rewards",
            side_effect=[
                *[[{"name": "Coins", "amount": 10, "target": 0}] for _ in range(4)],
                RewardError("Falha dirigida nas Mega Boxes"),
            ],
        ) as generate:
            with self.assertRaises(RewardError):
                ShopService.purchase(self.player, index)
            self.assertEqual(generate.call_count, 5)
            self.assertEqual(generate.call_args.args[1], 11)
            self.assertEqual(generate.call_args.kwargs["box_count"], 1)
        self.assertEqual((self.player.gold, self.player.gems), (70, 90))
        self.assertNotIn("gems_big_mega", self.player.progression["shop"]["claimed"])
        self.assertFalse(self.player.progression["shop"]["offers"][index]["purchased"])
        self.assertEqual(BoxInventory.count(self.player, 11), 0)
        self.assertEqual(BoxInventory.count(self.player, 12), 0)
        loaded = self.reload()
        self.assertEqual((loaded.gold, loaded.gems), (70, 90))
        self.assertFalse(loaded.progression["shop"]["offers"][index]["purchased"])
        with patch(
            "Logic.BoxService.generate_rewards",
            return_value=[{"name": "Coins", "amount": 25, "target": 0}],
        ) as generate_retry:
            result = ShopService.purchase(loaded, index)
        self.assertEqual(generate_retry.call_count, 5)
        self.assertEqual(len(result["openedBoxes"]), 2)
        for opened, box_type, count in zip(result["openedBoxes"], (12, 11), (3, 2)):
            self.assertEqual((opened["boxType"], opened["boxCount"]), (box_type, count))
            self.assertEqual(len(opened["rewardUnits"]), count)
        combined = result["responses"][0]["result"]
        self.assertEqual(combined["unitCount"], 5)
        self.assertEqual((loaded.gold, loaded.gems), (195, 140))
        self.assertTrue(loaded.progression["shop"]["claimed"]["gems_big_mega"])
        persisted = self.reload()
        self.assertEqual((persisted.gold, persisted.gems), (195, 140))
        self.assertTrue(persisted.progression["shop"]["claimed"]["gems_big_mega"])

        other, _ = self.make_account(99, "combined-box-atomicity")
        other.gold = 70
        other.gems = 90
        DataBase.replaceValues(SimpleNamespace(player=other), {
            "gold": 70, "gems": 90,
        })
        other_state = ShopService.get_state(other)
        other_index = next(
            index for index, offer in enumerate(other_state["offers"])
            if offer["key"] == "gems_big_mega"
        )
        with patch(
            "Logic.BoxService.generate_rewards",
            return_value=[{"name": "Coins", "amount": 5, "target": 0}],
        ) as generate_other, patch.object(
            ShopService, "_combined_box_results",
            side_effect=RewardError("Divergência dirigida no pacote"),
        ):
            with self.assertRaises(RewardError):
                ShopService.purchase(other, other_index)
        self.assertEqual(generate_other.call_count, 5)
        self.assertEqual((other.gold, other.gems), (70, 90))
        self.assertNotIn("gems_big_mega", other.progression["shop"]["claimed"])
        self.assertFalse(other_state["offers"][other_index]["purchased"])
        other_loaded = self.reload(other)
        self.assertEqual((other_loaded.gold, other_loaded.gems), (70, 90))
        self.assertFalse(
            other_loaded.progression["shop"]["offers"][other_index]["purchased"]
        )

    def test_paid_box_offer_ids_store_the_nost_box_types_without_opening(self):
        native = {10: ("brawl_boxes", 100), 12: ("big_boxes", 10)}
        for offer_id, expected in ((6, 10), (10, 11), (14, 12), (15, 10)):
            with self.subTest(offer_id=offer_id):
                self.player, self.owner = self.make_account(
                    1000 + offer_id, f"box-offer-{offer_id}"
                )
                self.update({"brawlBoxes": 0})
                before = BoxInventory.count(self.player, expected)
                balance = None
                if expected in native:
                    attribute, cost = native[expected]
                    balance = getattr(self.player, attribute)
                self.install([self.offer(
                    price=0,
                    items=[{
                        "offerId": offer_id,
                        "amount": 3,
                        "value": 1 if offer_id == 0 else 0,
                        "target": None,
                    }],
                )])
                with patch("Logic.BoxService.generate_rewards") as generate:
                    result = ShopService.purchase(self.player, 0, rng=random.Random(1))
                generate.assert_not_called()
                self.assertEqual(result["rewards"], [])
                self.assertEqual(result["storedBoxes"], [{
                    "boxType": expected, "amount": 3,
                }])
                self.assertEqual(BoxInventory.count(self.player, expected), before + 3)
                loaded = self.reload()
                self.assertEqual(BoxInventory.count(loaded, expected), before + 3)
                if expected in native:
                    self.assertEqual(getattr(loaded, attribute), balance + 3 * cost)
                    self.assertEqual(loaded.progression["boxInventory"]["boxes"][str(expected)], 0)
                else:
                    self.assertEqual(loaded.progression["boxInventory"]["boxes"][str(expected)], 3)

    def test_mega_boxes_and_thousand_power_points_are_fully_delivered(self):
        self.update({"gems": 500, "brawlersUpgradePoints": {"0": 0}})
        self.install([self.offer(
            key="mega-and-power",
            price=100,
            items=[
                {"offerId": 10, "amount": 2, "value": 0, "target": None},
                {"offerId": 8, "amount": 1000, "value": 2000, "target": [16, 0]},
            ],
        )])
        with patch("Logic.BoxService.generate_rewards") as generate:
            result = ShopService.purchase(self.player, 0)
        generate.assert_not_called()
        self.assertEqual(self.player.gems, 400)
        self.assertEqual(self.player.brawlers_upgradium["0"], 1000)
        self.assertEqual(BoxInventory.count(self.player, 11), 2)
        self.assertEqual(result["storedBoxes"], [{"boxType": 11, "amount": 2}])
        self.assertEqual(result["rewards"], [{
            "type": 5, "amount": 1000, "brawler": 0,
        }])
        loaded = self.reload()
        self.assertEqual(loaded.gems, 400)
        self.assertEqual(loaded.brawlers_upgradium["0"], 1000)
        self.assertEqual(BoxInventory.count(loaded, 11), 2)
        with self.assertRaises(RewardError):
            ShopService.purchase(loaded, 0)
        self.assertEqual(BoxInventory.count(loaded, 11), 2)
        self.assertEqual(loaded.brawlers_upgradium["0"], 1000)

    def test_purchase_command_aggregates_items_and_never_opens_the_box(self):
        self.update({"gems": 500, "brawlersUpgradePoints": {"0": 0}})
        self.install([self.offer(
            price=100,
            items=[
                {"offerId": 10, "amount": 1, "value": 0, "target": None},
                {"offerId": 8, "amount": 1000, "value": 2000, "target": [16, 0]},
            ],
        )])
        client = CaptureClient()
        command = LogicPurchaseOfferCommand(client, self.player, b"")
        command.offer_index = 0
        with patch("Logic.BoxService.generate_rewards") as generate:
            result = command.process()
        generate.assert_not_called()
        self.assertEqual(len(client.packets), 1)
        packet_id, _, payload = packet_parts(client.packets[0])
        self.assertEqual(packet_id, 24111)
        reader = BSMessageReader(payload)
        self.assertEqual([reader.read_Vint() for _ in range(5)], [203, 0, 1, 100, 1])
        self.assertEqual(reader.read_Vint(), 1000)
        self.assertEqual((reader.read_Vint(), reader.read_Vint()), (16, 0))
        self.assertEqual([reader.read_Vint() for _ in range(3)], [6, 0, 0])
        self.assertEqual(reader.read_Vint(), 0)
        self.assertEqual([reader.read_Vint() for _ in range(5)], [0, 0, 0, 0, 0])
        self.assertEqual(reader.read(), b"")
        self.assertEqual(result["storedBoxes"], [{"boxType": 11, "amount": 1}])

    def test_box_only_mega_purchase_waits_for_explicit_opening(self):
        self.install([self.offer(
            price=0,
            items=[{"offerId": 10, "amount": 4, "value": 0, "target": None}],
        )])
        client = CaptureClient()
        command = LogicPurchaseOfferCommand(client, self.player, b"")
        command.offer_index = 0
        result = command.process()
        self.assertEqual(client.packets, [])
        self.assertEqual(result["responses"], [])
        self.assertEqual(BoxInventory.count(self.player, 11), 4)
        stored = ShopService.get_state(self.player)
        self.assertEqual(stored["offers"][-1]["storedBox"], 11)
        self.assertNotIn("storedBox", self.reload().progression["shop"]["offers"][-1])

    def test_mixed_bundle_stores_then_opens_mega_box_with_native_v13_wire(self):
        self.update({"gems": 500, "gold": 0, "brawlBoxes": 0, "tokensdoubler": 0})
        self.install([self.offer(
            key="resource-bundle",
            price=99,
            items=[
                {"offerId": 1, "amount": 500, "value": 0, "target": None},
                {"offerId": 9, "amount": 500, "value": 0, "target": None},
                {"offerId": 10, "amount": 1, "value": 0, "target": None},
            ],
        )])
        purchase_client = CaptureClient()
        purchase = LogicPurchaseOfferCommand(purchase_client, self.player, b"")
        purchase.offer_index = 0
        with patch("Logic.BoxService.generate_rewards") as generate:
            result = purchase.process()
        generate.assert_not_called()
        self.assertEqual(result["storedBoxes"], [{"boxType": 11, "amount": 1}])
        self.assertEqual((self.player.gems, self.player.gold, self.player.tokensdoubler), (401, 500, 500))
        self.assertEqual(BoxInventory.count(self.player, 11), 1)
        self.assertEqual(len(purchase_client.packets), 1)
        packet_id, _, payload = packet_parts(purchase_client.packets[0])
        self.assertEqual(packet_id, 24111)
        reader = BSMessageReader(payload)
        self.assertEqual([reader.read_Vint() for _ in range(5)], [203, 0, 1, 100, 2])
        self.assertEqual([reader.read_Vint() for _ in range(5)], [500, 0, 7, 0, 0])
        self.assertEqual([reader.read_Vint() for _ in range(5)], [500, 0, 2, 0, 0])
        self.assertEqual(reader.read_Vint(), 0)
        self.assertEqual([reader.read_Vint() for _ in range(5)], [0, 0, 0, 0, 0])
        self.assertEqual(reader.read(), b"")

        loaded = self.reload()
        self.assertEqual(BoxInventory.count(loaded, 11), 1)
        open_client = CaptureClient()
        opening = LogicPurchaseBoxCommand(open_client, loaded, b"")
        opening.box_id = 3
        native_rewards = [
            {"name": "Coins", "amount": 172, "target": 0},
            {"name": "UpgradePoints", "amount": 50, "target": 0},
            {"name": "Brawler", "amount": 4, "target": 0},
        ]
        with patch("Logic.BoxService.generate_rewards", return_value=native_rewards):
            opened = opening.process()
        self.assertEqual(opened["openingSource"], "inventory")
        self.assertEqual(BoxInventory.count(loaded, 11), 0)
        self.assertEqual((loaded.gems, loaded.gold, loaded.tokensdoubler), (401, 672, 500))
        packet_id, _, payload = packet_parts(open_client.packets[0])
        self.assertEqual(packet_id, 24111)
        self.assertEqual(payload, bytes.fromhex(
            "8b0301010b03ac0200070000321000060000011004010000000000000000"
        ))
        persisted = self.reload(loaded)
        self.assertEqual((persisted.gems, persisted.gold, persisted.tokensdoubler), (401, 672, 500))
        self.assertEqual(BoxInventory.count(persisted, 11), 0)
        self.assertEqual(persisted.BrawlersUnlockedState["4"], 1)

    def test_shop_power_points_never_silently_truncate_or_partially_commit(self):
        self.update({"gems": 500, "brawlersUpgradePoints": {"0": 500}})
        self.install([self.offer(
            price=100,
            items=[
                {"offerId": 10, "amount": 1, "value": 0, "target": None},
                {"offerId": 8, "amount": 1000, "value": 2000, "target": [16, 0]},
            ],
        )])
        with self.assertRaises(RewardError):
            ShopService.purchase(self.player, 0)
        self.assertEqual(self.player.gems, 500)
        self.assertEqual(self.player.brawlers_upgradium["0"], 500)
        self.assertEqual(BoxInventory.count(self.player, 11), 0)
        loaded = self.reload()
        self.assertEqual(loaded.gems, 500)
        self.assertEqual(loaded.brawlers_upgradium["0"], 500)
        self.assertFalse(loaded.progression["shop"]["offers"][0]["purchased"])

    def test_power_points_require_a_valid_unlocked_data_reference(self):
        self.update({"gems": 100})
        item = {"offerId": 8, "amount": 25, "value": 50, "target": [16, 1]}
        self.install([self.offer(items=[item])])
        with self.assertRaises(RewardError):
            ShopService.purchase(self.player, 0)
        self.assertEqual(self.player.gems, 100)
        states = dict(self.player.BrawlersUnlockedState)
        states["1"] = 1
        self.update({"UnlockedBrawlers": states})
        result = ShopService.purchase(self.player, 0, selected_brawler=2)
        self.assertEqual(result["rewards"][0], {
            "type": 5, "amount": 25, "brawler": 1,
        })
        self.assertEqual(self.player.brawlers_upgradium["1"], 25)
        self.assertNotEqual(self.player.brawlers_upgradium.get("2"), 25)
        self.assertEqual(self.reload().brawlers_upgradium["1"], 25)

    def test_wildcard_power_uses_the_selected_brawler_and_type_nine(self):
        self.update({"gems": 100})
        states = dict(self.player.BrawlersUnlockedState)
        states["1"] = 1
        self.update({"UnlockedBrawlers": states})
        self.install([self.offer(
            items=[{"offerId": 12, "amount": 25, "value": 0, "target": None}],
        )])
        result = ShopService.purchase(self.player, 0, selected_brawler=1)
        self.assertEqual(result["rewards"], [{
            "type": 9, "amount": 25, "brawler": 1,
        }])
        self.assertEqual(self.reload().brawlers_upgradium["1"], 25)

    def test_brawler_default_skin_nondefault_skin_and_star_power(self):
        self.update({"gems": 100})
        self.install([self.offer(
            price=0,
            items=[{"offerId": 3, "amount": 1, "value": 0, "target": [16, 1]}],
        )])
        result = ShopService.purchase(self.player, 0)
        self.assertEqual(result["rewards"][0]["type"], 6)
        self.assertEqual(self.player.BrawlersUnlockedState["1"], 1)
        default_skin = next(
            skin for skin in Skins.get_skins_id()
            if Skins.getBrawler(skin) == 2 and Skins.getIsDefaultSkin(skin)
        )
        self.install([self.offer(
            price=0,
            items=[{"offerId": 4, "amount": 1, "value": default_skin, "target": None}],
        )])
        result = ShopService.purchase(self.player, 0)
        self.assertEqual(result["rewards"][0]["brawler"], 2)
        self.assertEqual(self.player.BrawlersUnlockedState["2"], 1)
        self.install([self.offer(
            price=0,
            items=[{"offerId": 4, "amount": 1, "value": 0, "target": [29, 29]}],
        )])
        result = ShopService.purchase(self.player, 0)
        self.assertEqual(result["rewards"], [{
            "type": 7, "amount": 1, "skin": 29,
        }])
        self.assertIn(29, self.player.UnlockedSkins["Skins"])
        star_power = Cards.get_brawler_star_power(0)
        self.install([self.offer(
            price=0,
            items=[{"offerId": 5, "amount": 1, "value": 0, "target": [16, 0]}],
        )])
        result = ShopService.purchase(self.player, 0)
        self.assertEqual(result["rewards"], [{
            "type": 8, "amount": 1, "brawler": 0,
        }])
        self.assertEqual(self.player.Brawler_starPower["0"], star_power)
        loaded = self.reload()
        self.assertEqual(loaded.BrawlersUnlockedState["1"], 1)
        self.assertEqual(loaded.BrawlersUnlockedState["2"], 1)
        self.assertIn(29, loaded.UnlockedSkins["Skins"])
        self.assertEqual(loaded.Brawler_starPower["0"], star_power)

    def test_purchase_command_always_reads_nullable_data_reference(self):
        null_payload = b"".join(vint(0) for _ in range(5)) + vint(0) + b"x"
        null_command = LogicPurchaseOfferCommand(None, self.player, null_payload)
        null_command.decode()
        self.assertEqual(null_command.target_reference, (0, -1))
        self.assertEqual(null_command.read(), b"x")
        target_payload = b"".join(vint(0) for _ in range(5))
        target_payload += vint(16) + vint(1) + b"x"
        target_command = LogicPurchaseOfferCommand(None, self.player, target_payload)
        target_command.decode()
        self.assertEqual(target_command.target_reference, (16, 1))
        self.assertEqual(target_command.read(), b"x")

    def test_buy_item_keeps_three_rewards_and_native_tail(self):
        command = LogicBuyItem(None, self.player, [
            {"type": 1, "amount": 50},
            {"type": 5, "amount": 25, "brawler": 1},
            {"type": 7, "amount": 1, "skin": 29},
        ])
        command.encode()
        reader = BSMessageReader(command.buffer)
        self.assertEqual([reader.read_Vint() for _ in range(5)], [203, 0, 1, 100, 3])
        self.assertEqual([reader.read_Vint() for _ in range(5)], [50, 0, 7, 0, 0])
        self.assertEqual([reader.read_Vint() for _ in range(5)], [25, 16, 1, 6, 0])
        self.assertEqual(reader.read_Vint(), 0)
        self.assertEqual([reader.read_Vint() for _ in range(5)], [1, 0, 9, 29, 29])
        self.assertEqual(reader.read_Vint(), 0)
        self.assertEqual(reader.read_Vint(), 0)
        self.assertEqual([reader.read_Vint() for _ in range(5)], [0, 0, 0, 0, 0])
        self.assertEqual(reader.read(), b"")


class ShopHomeWireTests(ShopAccountTestCase):
    def encode_offers(self):
        writer = OwnHomeDataMessage(None, self.player)
        ShopService.encode_home(writer, self.player, NOW)
        reader = OwnHomeDataReader(writer.buffer)
        offers = self.read_offers(reader)
        self.assertEqual(reader.read(), b"")
        return offers

    def test_generated_offers_use_amount_value_and_neutral_bundle_fields(self):
        offers = self.encode_offers()
        self.assertEqual(len(offers), 4)
        self.assertEqual(offers[0]["items"], [(0, 1, (0, -1), 1)])
        power = offers[1]
        power_item = power["items"][0]
        self.assertEqual((power_item[0], power_item[1], power_item[3]), (8, 20, 0))
        self.assertEqual(power_item[2][0], 16)
        self.assertIn(power_item[2][1], Characters.get_brawlers_id())
        self.assertEqual(power["numeric"][:2], [1, 40])
        self.assertEqual([offer["originalPrice"] for offer in offers], [0, 0, 0, 0])
        self.assertEqual([offer["daily"] for offer in offers], [True, True, False, False])
        big_three = offers[2]
        self.assertEqual(big_three["items"], [
            (3, 1, (16, 12), 0),
            (3, 1, (16, 23), 0),
            (3, 1, (16, 5), 0),
        ])
        self.assertEqual(big_three["numeric"][:2], [0, 0])
        self.assertEqual(big_three["title"], "The big Three")
        bundle = offers[3]
        self.assertEqual(bundle["items"], [
            (16, 50, (0, -1), 0),
            (14, 3, (0, -1), 0),
            (10, 2, (0, -1), 0),
        ])
        self.assertEqual(bundle["numeric"][:2], [0, 0])
        self.assertEqual(bundle["title"], "50 Gemas + 3 BIGBOX + 2 MEGABOX")
        for offer in offers:
            self.assertEqual(offer["numeric"][3:], [0, 100])
            self.assertFalse(offer["purchased"])
            self.assertEqual(offer["auxiliary"], 0)

    def test_multiple_daily_power_and_star_power_offers_encode_completely(self):
        brawlers = Characters.get_brawlers_id()[:3]
        self.update({
            "UnlockedBrawlers": {str(brawler): 1 for brawler in brawlers},
            "brawlersUpgradePoints": {str(brawler): 0 for brawler in brawlers},
            "brawlerPowerLevel": {str(brawler): 8 for brawler in brawlers},
            "brawlerStarPower": {str(brawler): 0 for brawler in brawlers},
        })
        with patch.object(ShopService, "STAR_POWER_DAILY_CHANCE", 100):
            offers = self.encode_offers()
        self.assertEqual(len(offers), 9)
        self.assertEqual([offer["items"][0][0] for offer in offers], [0, 8, 8, 8, 5, 5, 5, 3, 16])
        self.assertEqual(
            {offer["items"][0][2][1] for offer in offers[1:4]},
            set(brawlers),
        )
        self.assertEqual(
            {offer["items"][0][2][1] for offer in offers[4:7]},
            set(brawlers),
        )
        for offer in offers[4:7]:
            self.assertEqual(offer["numeric"][:2], [1, 2000])
            self.assertEqual(offer["items"][0][1], 1)
            self.assertTrue(offer["daily"])

    def test_diagnostic_log_does_not_change_home_bytes(self):
        with patch("Logic.ShopService.Config.GetValue", return_value={
            "ShowPacketsInLog": False,
        }), patch("builtins.print") as disabled_log:
            expected = self.encode_offers()
        disabled_log.assert_not_called()
        with patch("Logic.ShopService.Config.GetValue", return_value={
            "ShowPacketsInLog": True,
        }), patch("builtins.print") as enabled_log:
            actual = self.encode_offers()
        self.assertEqual(actual, expected)
        lines = [call.args[0] for call in enabled_log.call_args_list]
        self.assertEqual(len(lines), 5)
        self.assertIn("ShopState account=1", lines[0])
        self.assertIn("count=4", lines[0])
        payloads = [
            json.loads(line.split("ShopOffer ", 1)[1])
            for line in lines[1:]
        ]
        self.assertEqual([payload["index"] for payload in payloads], [0, 1, 2, 3])
        self.assertEqual(payloads[0]["items"], [{
            "offerId": 0, "amount": 1, "value": 1, "target": None,
        }])
        self.assertEqual(payloads[1]["currency"], 1)
        self.assertEqual(payloads[1]["cost"], 40)
        self.assertEqual(payloads[1]["timer"], payloads[0]["timer"])
        self.assertEqual(payloads[2]["title"], "The big Three")
        self.assertEqual(payloads[2]["items"], [
            {"offerId": 3, "amount": 1, "value": 0, "target": [16, 12]},
            {"offerId": 3, "amount": 1, "value": 0, "target": [16, 23]},
            {"offerId": 3, "amount": 1, "value": 0, "target": [16, 5]},
        ])
        self.assertEqual(payloads[3]["title"], "50 Gemas + 3 BIGBOX + 2 MEGABOX")
        self.assertEqual(payloads[3]["items"], [
            {"offerId": 16, "amount": 50, "value": 0, "target": None},
            {"offerId": 14, "amount": 3, "value": 0, "target": None},
            {"offerId": 10, "amount": 2, "value": 0, "target": None},
        ])
        self.assertEqual(
            [payload["daily"] for payload in payloads],
            [True, True, False, False],
        )
        for payload in payloads:
            self.assertEqual(payload["percentage"], 100)
            self.assertEqual(payload["auxiliary"], 0)
            self.assertEqual(payload["newTag"], 0)
            self.assertFalse(payload["purchased"])

    def test_clear_tickers_changes_only_new_tag_state(self):
        self.install([self.offer(seen=False, purchased=True, daily=False, display=1)])
        before = self.encode_offers()
        ShopService.clear_tickers(self.player, NOW)
        after = self.encode_offers()
        self.assertEqual(before[0]["numeric"][:3], after[0]["numeric"][:3])
        self.assertEqual((before[0]["numeric"][3], after[0]["numeric"][3]), (0, 1))
        self.assertEqual(before[0]["numeric"][4], after[0]["numeric"][4])
        for key in ("items", "purchased", "auxiliary", "daily", "originalPrice", "title"):
            self.assertEqual(before[0][key], after[0][key])

    def test_r28_state_encodes_without_resetting_purchases(self):
        state = ShopService.get_state(self.player, NOW)
        state["offers"][1].update({
            "seen": True,
            "purchased": True,
            "daily": True,
            "reroll": 2,
            "claim": 3,
        })
        ShopService._save_state(self.player, state)
        offers = self.encode_offers()
        decoded = offers[1]
        self.assertEqual(len(offers), 4)
        self.assertEqual(decoded["items"][0][0], 8)
        self.assertEqual(decoded["items"][0][1], 20)
        self.assertEqual(decoded["items"][0][3], 0)
        self.assertEqual(decoded["numeric"][3:], [1, 100])
        self.assertTrue(decoded["purchased"])
        self.assertEqual(decoded["auxiliary"], 0)
        self.assertTrue(decoded["daily"])
        self.assertEqual(decoded["originalPrice"], 0)
        self.assertTrue(self.reload().progression["shop"]["offers"][1]["purchased"])

    def test_legacy_free_box_and_null_hero_power_migrate_without_replays(self):
        state = ShopService.get_state(self.player, NOW)
        state["offers"][0]["items"][0]["value"] = 0
        state["offers"][0]["purchased"] = True
        state["offers"][1]["purchased"] = True
        state["offers"][1].update({
            "items": [{"offerId": 8, "amount": 200, "value": 0, "target": None}],
            "currency": 0,
            "price": 30,
            "originalPrice": 40,
            "seen": True,
            "purchased": True,
            "reroll": 2,
            "claim": 3,
        })
        state["billing"]["transactions"]["legacy"] = {"product": "pack"}
        ShopService._save_state(self.player, state)
        offers = self.encode_offers()
        self.assertEqual(offers[0]["items"], [(0, 1, (0, -1), 1)])
        power = offers[1]
        self.assertEqual(power["items"][0][:2], (8, 20))
        self.assertEqual(power["items"][0][2][0], 16)
        self.assertEqual(power["items"][0][3], 0)
        self.assertEqual(power["numeric"][:2], [1, 40])
        for index in (0, 1):
            self.assertTrue(offers[index]["purchased"])
        stored = self.reload().progression["shop"]
        self.assertNotIn("reroll", stored["offers"][1])
        self.assertNotIn("claim", stored["offers"][1])
        self.assertEqual(stored["billing"]["transactions"]["legacy"], {"product": "pack"})
        with self.assertRaises(RewardError):
            ShopService.purchase(self.player, 1)

    def test_real_offer_vector_preserves_every_following_home_byte(self):
        offer = self.offer(
            title="BUNDLE",
            seen=True,
            purchased=True,
            daily=False,
            display=1,
            originalPrice=20,
            items=[{"offerId": 8, "amount": 25, "value": 7, "target": [16, 1]}],
        )
        self.install([offer])
        with patch.object(EventSlots, "Timer", lambda self: 49020):
            real_message = OwnHomeDataMessage(None, self.player)
            real_message.encode()
            with patch(
                "Packets.Messages.Server.Home.OwnHomeDataMessage.ShopService.encode_home",
                lambda writer, player: writer.v(0),
            ):
                empty_message = OwnHomeDataMessage(None, self.player)
                empty_message.encode()
        reader = OwnHomeDataReader(real_message.buffer)
        offer_start = self.seek_offers(reader)
        offers = self.read_offers(reader)
        offer_end = reader.tell()
        self.assertEqual(len(offers), 1)
        decoded = offers[0]
        self.assertEqual(decoded["items"], [(8, 25, (16, 1), 7)])
        self.assertEqual(decoded["numeric"], [0, 10, 3600, 1, 100])
        self.assertTrue(decoded["purchased"])
        self.assertEqual(decoded["auxiliary"], 0)
        self.assertFalse(decoded["daily"])
        self.assertEqual(decoded["originalPrice"], 20)
        self.assertEqual(decoded["title"], "BUNDLE")
        self.assertEqual(
            empty_message.buffer,
            real_message.buffer[:offer_start] + b"\x00" + real_message.buffer[offer_end:],
        )
        self.assertEqual([reader.v() for _ in range(6)], [0] * 6)
        self.assertEqual((reader.v(), reader.v()), (16, 0))

    def test_offer_matches_independent_lib_golden_bytes(self):
        self.install([self.offer(
            title="A",
            expiresAt=NOW + 63,
            seen=False,
            purchased=True,
            daily=True,
        )])
        message = OwnHomeDataMessage(None, self.player)
        with patch.object(EventSlots, "Timer", lambda self: 49020):
            message.encode()
        reader = OwnHomeDataReader(message.buffer)
        offer_start = self.seek_offers(reader)
        decoded = self.read_offers(reader)[0]
        offer_end = reader.tell()
        self.assertEqual(
            message.buffer[offer_start:offer_end].hex(),
            "010101320000000a3f00a401010001000000000141",
        )
        self.assertEqual(decoded["numeric"], [0, 10, 63, 0, 100])
        self.assertTrue(decoded["purchased"])
        self.assertTrue(decoded["daily"])
        self.assertEqual(decoded["originalPrice"], 0)
        self.assertEqual(decoded["title"], "A")
        self.assertEqual([reader.v() for _ in range(6)], [0] * 6)
        self.assertEqual((reader.v(), reader.v()), (16, 0))

    def test_null_item_reference_occupies_exactly_one_vint(self):
        self.install([self.offer(title="")])
        message = OwnHomeDataMessage(None, self.player)
        with patch.object(EventSlots, "Timer", lambda self: 49020):
            message.encode()
        reader = OwnHomeDataReader(message.buffer)
        self.seek_offers(reader)
        decoded = self.read_offers(reader)[0]
        self.assertEqual(decoded["items"], [(1, 50, (0, -1), 0)])
        self.assertEqual([reader.v() for _ in range(6)], [0] * 6)


class BillingTests(ShopAccountTestCase):
    def values(self, product, token):
        return [product, token, "", "", "", ""]

    def request(self, values):
        writer = Writer(None)
        for value in values:
            writer.writeString(value)
        client = CaptureClient()
        message = GoogleBillingRequestMessage(client, self.player, writer.buffer)
        message.decode()
        self.assertEqual(message.values, values)
        self.assertEqual(message.read(), b"")
        result = message.process()
        return client, result

    def test_gem_pack_response_and_distinct_transactions(self):
        self.update({"gems": 0})
        values = self.values("com.supercell.laser.gempack0", "token-1")
        client, result = self.request(values)
        self.assertTrue(result["accepted"])
        self.assertEqual(self.player.gems, 30)
        self.assertEqual(len(client.packets), 2)
        packet_id, _, payload = packet_parts(client.packets[0])
        self.assertEqual(packet_id, 20152)
        reader = BSMessageReader(payload)
        self.assertEqual(reader.read_string(), "com.supercell.laser.gempack0")
        self.assertEqual(len(reader.read_string()), 64)
        self.assertEqual(reader.read_int(), 0)
        self.assertEqual(reader.read(), b"")
        replay_client, replay = self.request(values)
        self.assertFalse(replay["accepted"])
        self.assertEqual(packet_parts(replay_client.packets[0])[0], 20121)
        self.assertEqual(len(replay_client.packets), 1)
        self.assertEqual(self.player.gems, 30)
        other_client, other = self.request(self.values(
            "com.supercell.laser.gempack0", "token-2"
        ))
        self.assertTrue(other["accepted"])
        self.assertEqual(self.player.gems, 60)
        self.assertEqual(self.reload().gems, 60)
        self.assertEqual(len(other_client.packets), 2)

    def test_starter_pack_uses_bundle_response_and_csv_box_count(self):
        self.update({"gems": 0})
        self.player.experience_level = 35
        values = self.values("com.supercell.laser.starterpack1", "starter-1")
        with patch("Logic.BoxService.generate_rewards") as generate:
            client, result = self.request(values)
        generate.assert_not_called()
        self.assertTrue(result["accepted"])
        self.assertEqual(self.player.gems, 80)
        self.assertEqual(len(client.packets), 3)
        packet_id, _, payload = packet_parts(client.packets[0])
        self.assertEqual(packet_id, 28363)
        reader = BSMessageReader(payload)
        self.assertEqual((reader.read_Vint(), reader.read_Vint()), (2, 1))
        self.assertEqual(reader.read(), b"")
        item_payload = packet_parts(client.packets[1])[2]
        self.assertEqual(BSMessageReader(item_payload).read_Vint(), 203)
        resource = BSMessageReader(packet_parts(client.packets[2])[2])
        self.assertEqual(
            [resource.read_Vint() for _ in range(8)],
            [207, 5000009, 10, 0, 0, 0, 0, 0],
        )
        self.assertEqual(resource.read(), b"")
        loaded = self.reload()
        self.assertEqual(loaded.gems, 80)
        self.assertEqual(BoxInventory.count(loaded, 12), 1)
        self.assertEqual(BoxInventory.count(loaded, 11), 0)
        bundles = loaded.progression["shop"]["billing"]["bundles"]
        self.assertIn("com.supercell.laser.starterpack1", bundles)
        replay_client, replay = self.request(self.values(
            "com.supercell.laser.starterpack1", "starter-2"
        ))
        self.assertFalse(replay["accepted"])
        self.assertEqual(packet_parts(replay_client.packets[0])[0], 20121)
        self.assertEqual(self.player.gems, 80)

    def test_xmas_bundle_uses_type_three_and_two_csv_boxes(self):
        self.update({"gems": 0})
        with patch("Logic.BoxService.generate_rewards") as generate:
            result = BillingService.purchase(self.player, self.values(
                "com.supercell.laser.xmas2018pack", "xmas-1"
            ))
        generate.assert_not_called()
        self.assertTrue(result["isBundle"])
        self.assertEqual(result["package"]["type"], 3)
        self.assertEqual(result["package"]["starterPackNumber"], 0)
        self.assertEqual(result["package"]["bigBoxCount"], 2)
        self.assertEqual(self.player.gems, 170)
        self.assertEqual(result["rewards"], [{"type": 2, "amount": 170}])
        self.assertEqual(result["storedBoxes"], [{"boxType": 12, "amount": 2}])
        self.assertEqual(result["responses"][-1], {
            "kind": "resource", "resource": 5000009, "amount": 20,
        })
        loaded = self.reload()
        self.assertEqual(loaded.gems, 170)
        self.assertEqual(BoxInventory.count(loaded, 12), 2)
        self.assertEqual(BoxInventory.count(loaded, 11), 0)

    def test_level_requirement_and_unknown_product_do_not_change_economy(self):
        self.update({"gems": 12})
        self.player.experience_level = 0
        with self.assertRaises(RewardError):
            BillingService.purchase(self.player, self.values(
                "com.supercell.laser.starterpack2", "locked"
            ))
        self.assertEqual(self.player.gems, 12)
        client, result = self.request(self.values("unknown.product", "unknown"))
        self.assertFalse(result["accepted"])
        self.assertEqual(self.player.gems, 12)
        packet_id, _, payload = packet_parts(client.packets[0])
        self.assertEqual(packet_id, 20121)
        reader = BSMessageReader(payload)
        self.assertEqual(reader.read_int(), 1)
        self.assertTrue(reader.read_string())
        self.assertEqual(reader.read_int(), 0)
        self.assertEqual(reader.read(), b"")
        self.assertEqual(self.reload().gems, 12)

    def test_billing_response_encoders_match_txt_primitive_types(self):
        processed = GoogleBillingProcessedByServerMessage(None, self.player, "p", "t", 0)
        processed.encode()
        reader = BSMessageReader(processed.buffer)
        self.assertEqual((reader.read_string(), reader.read_string(), reader.read_int()), ("p", "t", 0))
        self.assertEqual(reader.read(), b"")
        bundle = BuyBundleBillingPackResponseMessage(None, self.player, 3, 0)
        bundle.encode()
        self.assertEqual(bundle.buffer, vint(3) + vint(0))
        failed = BillingRequestFailedMessage(None, self.player, "erro", 1)
        failed.encode()
        reader = BSMessageReader(failed.buffer)
        self.assertEqual((reader.read_int(), reader.read_string(), reader.read_int()), (1, "erro", 0))
        self.assertEqual(reader.read(), b"")


if __name__ == "__main__":
    unittest.main()
