import unittest

from Logic.EventRotation import EventError, EventRotation
from Logic.GameRoomService import GameRoomService
from Packets.Messages.Client.Gameroom.TeamSetRankedLocationMessage import (
    TeamSetRankedLocationMessage,
)
from Utils.Writer import Writer
from tests.test_battle_end import CaptureClient
from tests.test_gamerooms import make_player


class RankedLocationTests(unittest.TestCase):
    def setUp(self):
        GameRoomService.init()
        self.addCleanup(GameRoomService.init)
        self.player = make_player(1)
        self.room = GameRoomService.create(self.player, 0, 0, 0)

    @staticmethod
    def payload(map_id, slot, trailing=False):
        writer = Writer(None).enable_native_v13()
        writer.writeVint(map_id)
        writer.writeVint(slot)
        if trailing:
            writer.writeVint(0)
        return writer.buffer

    def test_native_map_id_then_slot_selects_every_event(self):
        for event in EventRotation.snapshot(self.player):
            client = CaptureClient()
            message = TeamSetRankedLocationMessage(
                client, self.player, self.payload(event["map_id"], event["slot"])
            )
            message.decode()
            self.assertEqual(
                (message.map_id, message.slot),
                (event["map_id"], event["slot"]),
            )
            room = message.process()
            self.assertEqual(
                (room["map_id"], room["slot_index"], room["map_slot"]),
                (event["map_id"], event["slot"], event["slot"]),
            )
            self.assertEqual(client.payload(), client.packets[0][7:])
            self.assertEqual(client.message_id, 24124)

    def test_mismatched_map_and_invalid_slots_do_not_change_room(self):
        events = EventRotation.snapshot(self.player)
        event = events[0]
        other_map = next(item["map_id"] for item in events[1:] if item["map_id"] != event["map_id"])
        before = (self.room["map_id"], self.room["slot_index"], self.room["map_slot"])

        client = CaptureClient()
        message = TeamSetRankedLocationMessage(
            client, self.player, self.payload(other_map, event["slot"])
        )
        message.decode()
        with self.assertRaises(ValueError):
            message.process()
        self.assertEqual(client.packets, [])
        current = GameRoomService.for_player(self.player)
        self.assertEqual(
            (current["map_id"], current["slot_index"], current["map_slot"]),
            before,
        )

        for slot in (0, len(events) + 1):
            message = TeamSetRankedLocationMessage(
                CaptureClient(), self.player, self.payload(event["map_id"], slot)
            )
            message.decode()
            with self.assertRaises(EventError):
                message.process()
        current = GameRoomService.for_player(self.player)
        self.assertEqual(
            (current["map_id"], current["slot_index"], current["map_slot"]),
            before,
        )

    def test_decoder_rejects_truncation_and_trailing_bytes(self):
        event = EventRotation.snapshot(self.player)[0]
        writer = Writer(None).enable_native_v13()
        writer.writeVint(event["map_id"])
        with self.assertRaises(ValueError):
            TeamSetRankedLocationMessage(None, self.player, writer.buffer).decode()
        with self.assertRaises(ValueError):
            TeamSetRankedLocationMessage(
                None, self.player, self.payload(event["map_id"], event["slot"], True)
            ).decode()
