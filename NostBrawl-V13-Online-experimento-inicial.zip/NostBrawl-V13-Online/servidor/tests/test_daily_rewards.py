import sqlite3
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor
from contextlib import closing
from datetime import datetime, timedelta
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from Database.DatabaseManager import DataBase
from Logic.BattleInstances import BattleInstanceService
from Logic.BattleResultAdapter import apply_battle_result_rewards
from Logic.DailyRewards import DailyRewards
from Logic.EventRotation import EventRotation
from Logic.Player import Players
from Packets.Messages.Client.Battle.AskForBattleEndMessage import AskForBattleEndMessage
from Packets.Messages.Client.Home.GoHomeFromOfflinePractiseMessage import (
    GoHomeFromOfflinePractiseMessage,
)
from Packets.Messages.Server.Home.OwnHomeDataMessage import OwnHomeDataMessage
from tests.test_battle_end import BattleAccountTestCase, CaptureClient, make_battle
from tests.test_own_home_data_wire import HOME_TIMESTAMP, read_home_commodities


class DailyRewardTests(BattleAccountTestCase):
    def setUp(self):
        super().setUp()
        self.day = datetime.now().replace(microsecond=0)
        self.next_day = self.day + timedelta(days=1)

    def make_daily_account(self, low_id=1, tokens=700, doubler=0):
        if low_id == self.player.low_id:
            player = self.player
        else:
            player = self.make_account(low_id, f"daily-{low_id}-{uuid.uuid4().hex}")
        player.map_id = 0
        player.battle_tokens = tokens
        player.tokensdoubler = doubler
        DataBase.replaceValues(SimpleNamespace(player=player), {
            "battleTokens": tokens,
            "tokensdoubler": doubler,
        })
        return player

    def reward(self, player, map_id=0, battle_id=None, now=None, map_slot=0):
        player.map_id = map_id
        player.locationID = map_slot
        player.battle_result = 0
        player.rank = 0
        return apply_battle_result_rewards(
            player, 0, battle_id or uuid.uuid4().hex, now or self.day
        )

    def daily_rows(self, player):
        with closing(sqlite3.connect(self.database_path)) as connection:
            return connection.execute(
                "SELECT day, used FROM daily_token_limits WHERE player_id = ? "
                "ORDER BY day",
                (player.low_id,),
            ).fetchall()

    def star_rows(self, player):
        with closing(sqlite3.connect(self.database_path)) as connection:
            return connection.execute(
                "SELECT day, map_id, amount FROM daily_star_rewards "
                "WHERE player_id = ? ORDER BY day, map_id",
                (player.low_id,),
            ).fetchall()

    def restart_schema(self):
        DataBase._initialized_paths.discard(str(Path(self.database_path).resolve()))

    def test_daily_allowance_and_balances_survive_reload_and_schema_restart(self):
        player = self.make_daily_account(tokens=700)
        initial = DailyRewards.sync_player(player, self.day)
        self.assertEqual((initial["used"], initial["remaining"]), (0, 700))
        rewards = self.reward(player)
        self.assertEqual(rewards.totaltokens, 20)
        self.assertEqual(
            (player.brawl_boxes, player.big_boxes, player.battle_tokens),
            (20, 1, 680),
        )
        self.restart_schema()
        loaded = self.reload(player)
        synced = DailyRewards.sync_player(loaded, self.day)
        self.assertEqual(synced["remaining"], 680)
        self.assertEqual((loaded.brawl_boxes, loaded.big_boxes), (20, 1))
        self.assertEqual(self.daily_rows(loaded), [(self.day.date().isoformat(), 20)])

    def test_legacy_remaining_is_preserved_until_the_next_server_day(self):
        player = self.make_daily_account(tokens=137)
        initial = DailyRewards.sync_player(player, self.day)
        self.assertEqual((initial["used"], initial["remaining"]), (563, 137))
        self.restart_schema()
        loaded = self.reload(player)
        self.assertEqual(DailyRewards.sync_player(loaded, self.day)["remaining"], 137)
        following = DailyRewards.sync_player(loaded, self.next_day)
        self.assertEqual((following["used"], following["remaining"]), (0, 700))
        self.assertEqual(self.daily_rows(loaded), [
            (self.day.date().isoformat(), 563),
            (self.next_day.date().isoformat(), 0),
        ])

    def test_doubler_cannot_cross_limit_and_empty_allowance_grants_no_tokens(self):
        player = self.make_daily_account(tokens=25, doubler=100)
        first = self.reward(player)
        self.assertEqual(
            (first.token, first.doubledtokens, first.totaltokens),
            (20, 5, 25),
        )
        self.assertEqual(
            (player.battle_tokens, player.tokensdoubler, player.brawl_boxes),
            (0, 95, 25),
        )
        trophies = player.trophies
        second = self.reward(player)
        self.assertEqual((second.token, second.doubledtokens, second.totaltokens), (0, 0, 0))
        self.assertEqual(player.brawl_boxes, 25)
        self.assertEqual(player.tokensdoubler, 95)
        self.assertGreater(player.trophies, trophies)
        self.assertEqual(self.daily_rows(player), [(self.day.date().isoformat(), 700)])

    def test_consecutive_battles_stop_at_exactly_700(self):
        player = self.make_daily_account(tokens=700)
        for _ in range(35):
            self.reward(player)
        self.assertEqual((player.brawl_boxes, player.battle_tokens), (700, 0))
        for _ in range(3):
            result = self.reward(player)
            self.assertEqual(result.totaltokens, 0)
        self.assertEqual(player.brawl_boxes, 700)
        self.assertEqual(self.daily_rows(player), [(self.day.date().isoformat(), 700)])

    def test_concurrent_battles_cannot_cross_limit_or_duplicate_event_star(self):
        player = self.make_daily_account(tokens=50)
        players = [self.reload(player) for _ in range(10)]
        barrier = threading.Barrier(len(players))

        def reward(clone):
            barrier.wait()
            return self.reward(clone)

        with ThreadPoolExecutor(max_workers=len(players)) as executor:
            results = list(executor.map(reward, players))
        self.assertEqual(sum(item.totaltokens for item in results), 50)
        loaded = self.reload(player)
        self.assertEqual((loaded.brawl_boxes, loaded.big_boxes, loaded.battle_tokens), (50, 1, 0))
        self.assertEqual(self.daily_rows(loaded), [(self.day.date().isoformat(), 700)])
        self.assertEqual(len(self.star_rows(loaded)), 1)

    def test_star_is_daily_per_map_and_different_events_are_independent(self):
        player = self.make_daily_account(tokens=700)
        first = self.reward(player, map_id=0)
        replay = self.reward(player, map_id=0)
        other = self.reward(player, map_id=1)
        self.assertTrue(first.rewards["hasStarKey"])
        self.assertFalse(replay.rewards["hasStarKey"])
        self.assertTrue(other.rewards["hasStarKey"])
        self.assertEqual(player.big_boxes, 2)

        self.restart_schema()
        loaded = self.reload(player)
        self.reward(loaded, map_id=0)
        self.assertEqual(loaded.big_boxes, 2)
        following = self.reward(loaded, map_id=0, now=self.next_day)
        self.assertTrue(following.rewards["hasStarKey"])
        self.assertEqual(loaded.big_boxes, 3)
        self.assertEqual(loaded.battle_tokens, 680)
        self.assertEqual(len(self.star_rows(loaded)), 3)

    def test_event_slot_is_server_validated_and_solo_map_flow_is_preserved(self):
        event = EventRotation.events(self.day)[0]
        matched = self.make_daily_account(low_id=1)
        matched_result = self.reward(
            matched, event["map_id"], map_slot=event["slot"]
        )
        self.assertEqual(matched.big_boxes, 1)

        mismatched = self.make_daily_account(low_id=2)
        mismatched_result = self.reward(
            mismatched, event["map_id"], map_slot=2
        )
        self.assertEqual(mismatched.big_boxes, 0)
        self.assertEqual(mismatched_result.totaltokens, 20)
        self.assertEqual(self.star_rows(mismatched), [])

        solo = self.make_daily_account(low_id=3)
        solo_result = self.reward(solo, 0, map_slot=0)
        self.assertEqual(solo.big_boxes, 1)
        self.assertEqual(self.star_rows(solo), [
            (self.day.date().isoformat(), 0, 1),
        ])

    def test_replay_does_not_consume_daily_limit_even_on_following_day(self):
        player = self.make_daily_account(tokens=700)
        battle_id = uuid.uuid4().hex
        self.reward(player, battle_id=battle_id)
        self.restart_schema()
        loaded = self.reload(player)
        replay = self.reward(loaded, battle_id=battle_id, now=self.next_day)
        self.assertTrue(replay.rewards["_replayed"])
        self.assertEqual((loaded.brawl_boxes, loaded.big_boxes), (20, 1))
        self.assertEqual(self.daily_rows(loaded), [(self.day.date().isoformat(), 20)])
        self.assertEqual(len(self.star_rows(loaded)), 1)

    def test_event_claim_uses_daily_limit_and_next_day_allows_new_claim(self):
        player = self.make_daily_account(tokens=5)
        first = EventRotation.claim(player, 1, self.day)
        replay = EventRotation.claim(player, 1, self.day)
        other = EventRotation.claim(player, 2, self.day)
        self.assertEqual((first["granted"], first["balance"]), (5, 5))
        self.assertEqual((replay["granted"], other["granted"]), (0, 0))
        self.assertEqual(player.brawl_boxes, 5)
        self.assertEqual(player.battle_tokens, 0)

        loaded = self.reload(player)
        following = EventRotation.claim(loaded, 1, self.next_day)
        self.assertEqual(following["granted"], 10)
        self.assertEqual((loaded.brawl_boxes, loaded.battle_tokens), (15, 690))

    def test_failure_rolls_back_daily_consumption_star_and_resources(self):
        player = self.make_daily_account(tokens=700)
        client = CaptureClient()
        message = AskForBattleEndMessage(client, player, make_battle())
        message.decode()
        with patch.object(DataBase, "_write_state", side_effect=sqlite3.OperationalError("injected")):
            with self.assertRaises(sqlite3.OperationalError):
                message.process()
        loaded = self.reload(player)
        self.assertEqual((loaded.trophies, loaded.brawl_boxes, loaded.big_boxes), (0, 0, 0))
        self.assertEqual(self.daily_rows(loaded), [])
        self.assertEqual(self.star_rows(loaded), [])
        self.reward(loaded)
        self.assertEqual(self.daily_rows(loaded), [(self.day.date().isoformat(), 20)])
        self.assertEqual(len(self.star_rows(loaded)), 1)

    def test_home_uses_persistent_daily_state_and_real_timestamps(self):
        player = self.make_daily_account(tokens=0)
        DailyRewards.sync_player(player, self.day)
        player.battle_tokens = 700
        message = OwnHomeDataMessage(None, player)
        with patch("Logic.DailyRewards.datetime") as clock, \
             patch("Packets.Messages.Server.Home.OwnHomeDataMessage.time.time", return_value=HOME_TIMESTAMP), \
             patch("Packets.Messages.Server.Home.OwnHomeDataMessage.ShopService.encode_home", lambda writer, target: writer.v(0)):
            clock.now.return_value = self.day
            payload = message._encode_payload()
        reader, _ = read_home_commodities(payload)
        self.assertEqual(reader.daily_timestamp, HOME_TIMESTAMP)
        self.assertEqual(reader.shop_timestamp, HOME_TIMESTAMP)
        self.assertEqual(reader.daily_fields, [0, 20, 8640, 10, 5])
        self.assertTrue(reader.token_limit)
        self.assertEqual(player.battle_tokens, 0)

    def test_consecutive_battle_home_cycles_can_start_another_match(self):
        player = self.make_daily_account(tokens=700)
        for index in range(6):
            previous = getattr(player, "battle_instance_id", None)
            battle_id = BattleInstanceService.begin(player)
            self.assertIsNotNone(battle_id)
            if index:
                self.assertNotEqual(battle_id, previous)
            client = CaptureClient()
            result = AskForBattleEndMessage(client, player, make_battle())
            result.decode()
            result.process()
            self.assertEqual(int.from_bytes(client.packets[0][:2], "big", signed=True), 23456)
            home = GoHomeFromOfflinePractiseMessage(client, player, b"\x00")
            home.decode()
            home.process()
            self.assertEqual(len(client.packets), 2)
            self.assertEqual(int.from_bytes(client.packets[-1][:2], "big", signed=True), 24101)
            self.assertEqual(player.battle_tokens, 700 - 20 * (index + 1))
        self.assertEqual((player.brawl_boxes, player.big_boxes), (120, 1))
        self.assertEqual(len(self.star_rows(player)), 1)
