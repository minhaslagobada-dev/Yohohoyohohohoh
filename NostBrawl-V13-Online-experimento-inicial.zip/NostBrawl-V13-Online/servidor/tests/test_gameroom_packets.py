import os
import socket
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace


PROJECT_ROOT = Path(__file__).resolve().parents[1]
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from Logic.GameRoomService import GameRoomService
from Logic.Player import Players
from Packets.Messages.Client.Gameroom.TeamCreateMessage import TeamCreateMessage
from Packets.Messages.Client.Gameroom.TeamLeaveMessage import TeamLeaveMessage
from Packets.Messages.Client.Gameroom.TeamPostAdMessage import TeamPostAdMessage
from Packets.Messages.Client.Gameroom.TeamRequestJoinMessage import TeamRequestJoinMessage
from Packets.Messages.Client.Gameroom.TeamSetLocationMessage import TeamSetLocationMessage
from Packets.Messages.Client.Gameroom.TeamSpectateMessage import TeamSpectateMessage
from Packets.Messages.Client.Gameroom.TeamToggleMemberSideMessage import TeamToggleMemberSideMessage
from Utils.Reader import BSMessageReader
from Utils.Writer import Writer


def native_writer():
    return Writer(None).enable_native_v13()


def native_reader(payload):
    return BSMessageReader(payload).enable_native_v13()


def receive_exact(connection, length):
    data = bytearray()
    while len(data) < length:
        chunk = connection.recv(length - len(data))
        if not chunk:
            raise ConnectionError("socket fechado")
        data.extend(chunk)
    return bytes(data)


def receive_packet(connection):
    header = receive_exact(connection, 7)
    return (
        int.from_bytes(header[:2], "big"),
        receive_exact(connection, int.from_bytes(header[2:5], "big")),
    )


def make_player(low_id):
    player = Players(SimpleNamespace())
    player.low_id = low_id
    player.high_id = 0
    player.token = ""
    player.name = f"Player {low_id}"
    player.room_id = 0
    player.online = 3
    player.brawler_id = 0
    player.skin_id = 0
    player.profile_icon = 0
    player.name_color = 0
    player.brawlers_trophies = {"0": 100}
    player.Brawler_level = {"0": 3}
    player.ClientDict = {"ClientCounts": 0, "Clients": {}}
    player.crypto = None
    return player


def stream_events(payload):
    reader = native_reader(payload)
    reader.read_Vint()
    reader.read_Vint()
    events = []
    for _ in range(reader.read_Vint()):
        kind = reader.read_Vint()
        reader.read_Vint()
        reader.read_Vint()
        reader.read_Vint()
        reader.read_Vint()
        reader.read_string()
        reader.read_Vint()
        reader.read_Vint()
        reader.read_boolean()
        event = None
        if kind == 2:
            reader.read_string()
        elif kind == 4:
            event = reader.read_Vint()
            if reader.read_boolean():
                reader.read_Vint()
                reader.read_Vint()
                reader.read_string()
        events.append(event)
    reader.ensure_end()
    return events


class MissingGameRoomPacketTests(unittest.TestCase):
    def setUp(self):
        GameRoomService.init()
        self.addCleanup(GameRoomService.init)
        self.sockets = []
        self.addCleanup(self.close_sockets)

    def close_sockets(self):
        for connection in self.sockets:
            try:
                connection.close()
            except OSError:
                pass

    def socket_pair(self):
        server, client = socket.socketpair()
        server.settimeout(1)
        client.settimeout(1)
        self.sockets.extend((server, client))
        return server, client

    def register(self, *players_and_sockets):
        clients = {"ClientCounts": len(players_and_sockets), "Clients": {}}
        for player, connection in players_and_sockets:
            player.ClientDict = clients
            clients["Clients"][str(player.low_id)] = {
                "SocketInfo": connection,
                "Crypto": None,
                "Lock": player.send_lock,
            }

    def test_spectate_14358_joins_and_synchronizes_both_connections(self):
        owner = make_player(1)
        guest = make_player(2)
        room = GameRoomService.create(owner, 0, 7, 0, False)
        owner_server, owner_client = self.socket_pair()
        guest_server, guest_client = self.socket_pair()
        self.register((owner, owner_client), (guest, guest_client))
        writer = native_writer()
        for value in (0, room["id"], 0):
            writer.writeVint(value)
        message = TeamSpectateMessage(guest_client, guest, writer.buffer)
        message.decode()
        self.assertEqual(message.room_id, room["id"])
        joined = message.process()
        self.assertEqual(joined["player_count"], 2)
        self.assertEqual(guest.room_id, room["id"])
        for connection in (guest_server, owner_server):
            self.assertEqual(receive_packet(connection)[0], 24124)
            packet_id, payload = receive_packet(connection)
            self.assertEqual(packet_id, 24131)
            self.assertEqual(stream_events(payload), [101, 102])

    def test_spectate_resolves_an_existing_room_in_the_third_vint(self):
        owner = make_player(1)
        guest = make_player(2)
        room = GameRoomService.create(owner, 0, 7, 0, False)
        owner_server, owner_client = self.socket_pair()
        guest_server, guest_client = self.socket_pair()
        self.register((owner, owner_client), (guest, guest_client))
        writer = native_writer()
        for value in (0, 0, room["id"]):
            writer.writeVint(value)
        message = TeamSpectateMessage(guest_client, guest, writer.buffer)
        message.decode()
        self.assertEqual(message.process()["player_count"], 2)
        self.assertEqual(guest.room_id, room["id"])
        for connection in (guest_server, owner_server):
            self.assertEqual(receive_packet(connection)[0], 24124)
            self.assertEqual(receive_packet(connection)[0], 24131)

    def test_request_join_14881_uses_native_logic_longs(self):
        owner = make_player(1)
        guest = make_player(2)
        room = GameRoomService.create(owner, 0, 7, 0, False)
        owner_server, owner_client = self.socket_pair()
        guest_server, guest_client = self.socket_pair()
        self.register((owner, owner_client), (guest, guest_client))
        writer = native_writer()
        writer.writeInt(0)
        writer.writeInt(room["id"])
        writer.writeInt(0)
        writer.writeInt(owner.low_id)
        message = TeamRequestJoinMessage(guest_client, guest, writer.buffer)
        message.decode()
        self.assertEqual(
            (message.room_high_id, message.room_id,
             message.owner_high_id, message.owner_id),
            (0, room["id"], 0, owner.low_id),
        )
        self.assertEqual(message.process()["player_count"], 2)
        for connection in (guest_server, owner_server):
            self.assertEqual(receive_packet(connection)[0], 24124)
            self.assertEqual(receive_packet(connection)[0], 24131)

    def test_toggle_side_and_post_ad_update_real_room_state(self):
        owner = make_player(1)
        guest = make_player(2)
        room = GameRoomService.create(owner, 0, 7, 0, False)
        GameRoomService.request_join_transition(guest, room["id"])
        owner_server, owner_client = self.socket_pair()
        guest_server, guest_client = self.socket_pair()
        self.register((owner, owner_client), (guest, guest_client))
        writer = native_writer()
        writer.writeVint(2)
        for player in (owner, guest):
            writer.writeInt(0)
            writer.writeInt(player.low_id)
        writer.writeVint(3)
        toggle = TeamToggleMemberSideMessage(owner_client, owner, writer.buffer)
        toggle.decode()
        changed = toggle.process()
        self.assertEqual([member["team"] for member in changed["members"]], [1, 1])
        for connection in (owner_server, guest_server):
            self.assertEqual(receive_packet(connection)[0], 24124)

        for expected in (True, False):
            writer = native_writer()
            writer.writeVint(0)
            post = TeamPostAdMessage(owner_client, owner, writer.buffer)
            post.decode()
            changed = post.process()
            self.assertEqual(changed["advertise_band"], expected)
            for connection in (owner_server, guest_server):
                self.assertEqual(receive_packet(connection)[0], 24124)

    def test_leave_14353_sends_stream_event_to_remaining_member(self):
        owner = make_player(1)
        guest = make_player(2)
        room = GameRoomService.create(owner, 0, 7, 0, False)
        GameRoomService.request_join_transition(guest, room["id"])
        owner_server, owner_client = self.socket_pair()
        guest_server, guest_client = self.socket_pair()
        self.register((owner, owner_client), (guest, guest_client))
        message = TeamLeaveMessage(guest_client, guest, b"")
        message.decode()
        remaining = message.process()
        self.assertEqual(remaining["player_count"], 1)
        self.assertEqual(receive_packet(guest_server)[0], 24125)
        self.assertEqual(receive_packet(owner_server)[0], 24124)
        packet_id, payload = receive_packet(owner_server)
        self.assertEqual(packet_id, 24131)
        self.assertEqual(stream_events(payload), [101, 102, 103])

    def test_create_leaves_the_previous_room_without_ghost_members(self):
        owner = make_player(1)
        guest = make_player(2)
        previous = GameRoomService.create(owner, 0, 7, 0, False)
        GameRoomService.request_join_transition(guest, previous["id"])
        owner_server, owner_client = self.socket_pair()
        guest_server, guest_client = self.socket_pair()
        self.register((owner, owner_client), (guest, guest_client))
        writer = native_writer()
        for value in (0, 8, 0):
            writer.writeVint(value)
        writer.writeBoolean(False)
        message = TeamCreateMessage(owner_client, owner, writer.buffer)
        message.decode()
        created = message.process()
        self.assertNotEqual(created["id"], previous["id"])
        self.assertEqual(created["player_count"], 1)
        remaining = GameRoomService.get(previous["id"])
        self.assertEqual(remaining["player_count"], 1)
        self.assertEqual(remaining["members"][0]["low_id"], guest.low_id)
        self.assertEqual(receive_packet(owner_server)[0], 24125)
        self.assertEqual(receive_packet(owner_server)[0], 24124)
        self.assertEqual(receive_packet(owner_server)[0], 24131)
        self.assertEqual(receive_packet(guest_server)[0], 24124)
        packet_id, payload = receive_packet(guest_server)
        self.assertEqual(packet_id, 24131)
        self.assertEqual(stream_events(payload), [101, 102, 103])

    def test_location_update_rebinds_every_member_to_the_same_map(self):
        owner = make_player(1)
        guest = make_player(2)
        room = GameRoomService.create(owner, 0, 7, 0, False)
        GameRoomService.request_join_transition(guest, room["id"])
        owner_server, owner_client = self.socket_pair()
        guest_server, guest_client = self.socket_pair()
        self.register((owner, owner_client), (guest, guest_client))
        writer = native_writer()
        writer.writeScId(15, 8)
        message = TeamSetLocationMessage(owner_client, owner, writer.buffer)
        message.decode()
        changed = message.process()
        self.assertEqual((changed["map_id"], changed["slot_index"]), (8, 0))
        self.assertEqual((owner.map_id, guest.map_id), (8, 8))
        for connection in (owner_server, guest_server):
            self.assertEqual(receive_packet(connection)[0], 24124)


if __name__ == "__main__":
    unittest.main()
