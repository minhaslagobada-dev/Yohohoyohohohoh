import json
import os
import socket
import sqlite3
import struct
import sys
import tempfile
import unittest
from contextlib import closing
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch


PROJECT_ROOT = Path(__file__).resolve().parents[1]
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from Core import NaCl19
from Core.Crypto import Crypto, CryptoError, Nonce
from Database.DatabaseManager import DataBase
from Files.CsvLogic.Cards import Cards
from Logic.EventRotation import EventRotation
from Logic.EventSlots import EventSlots
from Logic.LeaderboardService import LeaderboardService
from Logic.NotificationFactory import NotificationFactory
from Logic.Player import Players
from Packets.Commands.Client.LogicClaimRankUpRewardCommand import LogicClaimRankUpRewardCommand
from Packets.Commands.Client.LogicNewEventCommand import LogicNewEventCommand
from Packets.Commands.Client.LogicPurchaseDoubleCoinsCommand import LogicPurchaseDoubleCoinsCommand
from Packets.Commands.Client.LogicSelectSkinCommand import LogicSelectSkinCommand
from Packets.LogicCommandManager import EndClientTurn
from Packets.LogicMessageFactory import packets
from Packets.Messages.Client.Battle.OnPlay import OnPlay
from Packets.Messages.Client.Login.ClientHelloMessage import ClientHelloMessage
from Packets.Messages.Client.Login.LoginMessage import LoginMessage
from Packets.Messages.Client.SetDeviceToken import SetDeviceToken
from Packets.Messages.Client.SetNameMessage import SetNameMessage
from Packets.Messages.Server.Battle.MatchMakingCancelledMessage import MatchMakingCancelledMessage
from Packets.Messages.Server.Home.OwnHomeDataMessage import OwnHomeDataMessage
from Packets.Messages.Server.Leaderboard.TopGlobalPlayersDataMessage import GetLeaderboardGlobalOkMessage
from Packets.Messages.Server.Login.LoginFailedMessage import LoginFailedMessage
from Packets.Messages.Server.Login.LoginOkMessage import LoginOkMessage
from SCIDClient.Game import SCIDGame
from Utils.Helpers import Helpers
from Utils.Reader import BSMessageReader
from Utils.Writer import Writer


FIXTURES = Path(__file__).resolve().parent / "fixtures"
_SCID_TEST_PATCH = None


def setUpModule():
    global _SCID_TEST_PATCH
    _SCID_TEST_PATCH = patch.object(
        SCIDGame, "enabled", staticmethod(lambda: False)
    )
    _SCID_TEST_PATCH.start()


def tearDownModule():
    if _SCID_TEST_PATCH is not None:
        _SCID_TEST_PATCH.stop()


def int32(value):
    return struct.pack(">I", value)


def vint(value):
    writer = Writer(None)
    writer.writeVint(value)
    return writer.buffer


def native_status_payload(status):
    writer = Writer(None).enable_native_v13()
    writer.writeVint(status)
    return writer.buffer


def string(value=None):
    if value is None:
        return b"\xff\xff\xff\xff"
    encoded = value.encode("utf-8")
    return int32(len(encoded)) + encoded


def packet(packet_id, payload=b"", version=0):
    return (
        struct.pack(">H", packet_id)
        + len(payload).to_bytes(3, "big")
        + struct.pack(">H", version)
        + payload
    )


def login_payload(low_id=0, token="", major=13, minor=283, build=1):
    return (
        int32(0)
        + int32(low_id)
        + string(token)
        + int32(major)
        + int32(minor)
        + int32(build)
        + string("fingerprint")
        + int32(0)
        + string("open-udid")
        + string("android-id")
        + string("android-version")
    )


def battle_end_payload(map_id=7):
    writer = Writer(None).enable_native_v13()
    for value in (0, 0, 0, map_id, 0, 6):
        writer.writeVint(value)
    for index in range(6):
        writer.writeVint(16)
        writer.writeVint(index)
        if index == 0:
            writer.writeVint(29)
        writer.writeVint(0)
        writer.writeVint(index % 2)
        writer.writeBoolean(index == 0)
        writer.writeString("Local" if index == 0 else f"Bot {index}")
    return writer.buffer


def notification_claim_payload(notification_index=1):
    writer = Writer(None)
    for value in (0, 0, 0, 1, 528, 0, 0, 0, 0, notification_index):
        writer.writeVint(value)
    return writer.buffer


def notification_delete_payload(action=8):
    writer = Writer(None)
    for value in (0, 137, 0, 1, 514, 136, 136, -64, -64, action):
        writer.writeVint(value)
    return writer.buffer + b"\xff" * 4


def receive_exact(sock, length):
    data = bytearray()
    while len(data) < length:
        chunk = sock.recv(length - len(data))
        if not chunk:
            raise ConnectionError("Socket closed while reading test packet")
        data.extend(chunk)
    return bytes(data)


def receive_packet(sock):
    header = receive_exact(sock, 7)
    packet_id = int.from_bytes(header[:2], "big")
    length = int.from_bytes(header[2:5], "big")
    version = int.from_bytes(header[5:7], "big")
    return packet_id, version, receive_exact(sock, length)


def fake_player():
    return SimpleNamespace(
        high_id=0,
        low_id=0,
        token="",
        device=SimpleNamespace(),
        maintenance=False,
        maintenance_time=0,
        patch=False,
        patch_sha="fingerprint",
        patch_url="",
        update_url="",
        region="BR",
        err_code=0,
        logged_in=False,
        online=0,
    )


class ClientHelloTests(unittest.TestCase):
    def test_empty_hello_sends_only_server_hello(self):
        server, client = socket.socketpair()
        self.addCleanup(server.close)
        self.addCleanup(client.close)
        client.settimeout(1)

        player = fake_player()
        message = ClientHelloMessage(server, player, b"")
        message.decode()
        message.process()

        packet_id, version, payload = receive_packet(client)
        self.assertEqual(packet_id, 20100)
        self.assertEqual(version, 0)
        self.assertEqual(len(payload), 28)
        self.assertEqual(int.from_bytes(payload[:4], "big"), 24)
        self.assertEqual(payload[-13:], bytes.fromhex("00446f6e277420747279203a29"))

    def test_v13_hello_fields_are_decoded(self):
        server, client = socket.socketpair()
        self.addCleanup(server.close)
        self.addCleanup(client.close)
        payload = (
            int32(0) + int32(0) + int32(13) + int32(283) + int32(1)
            + string("sha") + int32(0) + int32(0)
        )
        player = fake_player()
        message = ClientHelloMessage(server, player, payload)
        message.decode()
        self.assertEqual((message.major, message.minor, message.build), (13, 283, 1))
        self.assertEqual(message.fingerprint_sha, "sha")
        self.assertEqual(player.client_major, 13)


class LoginOkCompatibilityTests(unittest.TestCase):
    def test_login_ok_matches_v13_reference(self):
        player = fake_player()
        player.high_id = 1
        player.low_id = 2
        player.token = "token"

        ours = LoginOkMessage(None, player)
        ours.encode()
        expected = (FIXTURES / "loginok_v13.bin").read_bytes()
        self.assertEqual(ours.buffer, expected)


class NativeV13CodecTests(unittest.TestCase):
    def test_signed_vint_matches_native_arm_vectors(self):
        vectors = (
            (-2147483648, "c080808000"),
            (-134217728, "c08080800f"),
            (-134217727, "c1808000"),
            (-1048576, "c080807f"),
            (-1048575, "c18000"),
            (-8192, "c0807f"),
            (-8191, "c100"),
            (-65, "ff7e"),
            (-64, "c07f"),
            (-63, "41"),
            (-2, "7e"),
            (-1, "7f"),
            (0, "00"),
            (1, "01"),
            (63, "3f"),
            (64, "8001"),
            (65, "8101"),
            (8191, "bf7f"),
            (8192, "808001"),
            (1048575, "bfff7f"),
            (1048576, "80808001"),
            (134217727, "bfffff7f"),
            (134217728, "8080808001"),
            (2147483647, "bfffffff0f"),
        )
        for value, expected_hex in vectors:
            with self.subTest(value=value):
                writer = Writer(None).enable_native_v13()
                writer.writeVint(value)
                self.assertEqual(writer.buffer, bytes.fromhex(expected_hex))
                reader = BSMessageReader(writer.buffer).enable_native_v13()
                self.assertEqual(reader.read_Vint(), value)
                self.assertEqual(reader.read(), b"")

    def test_packed_booleans_align_before_vint_and_string(self):
        flags = [True, False, True, True, False, False, True, True, True, False]
        writer = Writer(None).enable_native_v13()
        for flag in flags:
            writer.writeBoolean(flag)
        writer.writeVint(-64)
        writer.writeString("A")
        self.assertEqual(writer.buffer, bytes.fromhex("cd01c07f0000000141"))

        reader = BSMessageReader(writer.buffer).enable_native_v13()
        self.assertEqual([reader.read_boolean() for _ in flags], flags)
        self.assertEqual(reader.read_Vint(), -64)
        self.assertEqual(reader.read_string(), "A")
        self.assertEqual(reader.read(), b"")

    def test_invalid_string_lengths_fail_before_allocation(self):
        payloads = (
            bytes.fromhex("7fffffff"),
            bytes.fromhex("4000000000"),
            bytes.fromhex("fffffffe"),
        )
        for payload in payloads:
            with self.subTest(payload=payload.hex()):
                reader = BSMessageReader(payload).enable_native_v13()
                with self.assertRaises(ValueError):
                    reader.read_string()


class WriterCompatibilityTests(unittest.TestCase):
    def test_signed_integers_use_cpp_twos_complement_layout(self):
        writer = Writer(None)
        writer.writeInt(-1)
        writer.writeInt(-2, 2)
        writer.writeInt(1)
        self.assertEqual(
            writer.buffer,
            b"\xff\xff\xff\xff\xff\xfe\x00\x00\x00\x01",
        )

    def test_directed_send_uses_recipient_crypto_and_clean_framing(self):
        class DirectedMessage(Writer):
            def __init__(self, client, player):
                super().__init__(client)
                self.id = 20999
                self.version = 0
                self.player = player

            def encode(self):
                self.writeVint(500)
                self.writeString("ok")

        class TargetCrypto:
            def __init__(self):
                self.calls = []

            def encrypt(self, packet_id, payload):
                self.calls.append((packet_id, payload))
                return b"secret:" + payload

        class UnexpectedSenderCrypto:
            def encrypt(self, packet_id, payload):
                raise AssertionError("the sender crypto must not encrypt a directed packet")

        recipient_server, recipient_client = socket.socketpair()
        self.addCleanup(recipient_server.close)
        self.addCleanup(recipient_client.close)
        target_crypto = TargetCrypto()
        player = SimpleNamespace(
            crypto=UnexpectedSenderCrypto(),
            ClientDict={
                "ClientCounts": 1,
                "Clients": {
                    "42": {
                        "SocketInfo": recipient_server,
                        "Crypto": target_crypto,
                    }
                },
            },
        )
        message = DirectedMessage(None, player)
        raw_payload = vint(500) + string("ok")

                                                                         
                                                                        
        self.assertTrue(message.sendWithLowID(42))
        self.assertTrue(message.sendWithLowID(42))
        for _ in range(2):
            self.assertEqual(
                receive_packet(recipient_client),
                (20999, 0, b"secret:" + raw_payload),
            )
        self.assertEqual(target_crypto.calls, [(20999, raw_payload)] * 2)

        recipient_client.setblocking(False)
        with self.assertRaises(BlockingIOError):
            recipient_client.recv(1)
        self.assertFalse(message.sendWithLowID(404))


class OwnHomeDataCompatibilityTests(unittest.TestCase):
    def setUp(self):
        shop_patch = patch(
            "Packets.Messages.Server.Home.OwnHomeDataMessage.ShopService.encode_home",
            lambda writer, player: writer.writeVint(0),
        )
        shop_patch.start()
        self.addCleanup(shop_patch.stop)

    def test_home_level_uses_persisted_experience_not_legacy_points(self):
        player = Players(SimpleNamespace())
        player.player_experience = 99999
        player.exp_points = 0
        message = OwnHomeDataMessage(None, player)
        message.encode()
        reader = BSMessageReader(message.buffer)
        daily_values = [reader.read_Vint() for _ in range(7)]
        self.assertEqual(daily_values[-1], 99999)

    def test_real_v13_player_has_consistent_array_counts(self):
        player = Players(SimpleNamespace())
        message = OwnHomeDataMessage(None, player)
        message.encode()
        self.assertEqual(player.player_experience, 99999)
        self.assertGreater(len(message.buffer), 100)
        self.assertEqual(len(player.brawlers_id), 22)
        self.assertEqual(len(player.card_unlock_id), 22)
        leon_index = player.brawlers_id.index(23)
        self.assertEqual(player.card_unlock_id[leon_index], 115)


class DeviceTokenTests(unittest.TestCase):
    def test_v12_device_token_is_registered_and_fully_decoded(self):
        self.assertIs(packets[10113], SetDeviceToken)
        token = bytes(range(131))
        payload = int32(len(token)) + token + int32(7)
        self.assertEqual(len(payload), 139)
        message = SetDeviceToken(None, SimpleNamespace(), payload)
        message.decode()
        self.assertEqual(message.device_token, token)
        self.assertEqual(message.value, 7)
        self.assertEqual(message.read(), b"")
        self.assertIsNone(message.process())


class CryptoCompatibilityTests(unittest.TestCase):
    def test_reference_ciphertext_vectors(self):
        crypto = Crypto({"Enabled": True})
        login = (FIXTURES / "crypto_login.bin").read_bytes()
        self.assertEqual(crypto.decrypt(10101, login), b"raw-login-payload")
        self.assertEqual(bytes(crypto.decryptNonce), bytes(range(24, 48)))

        crypto.encryptNonce = Nonce(bytes(range(48, 72)))
        crypto.shared_en = bytes(range(72, 104))
        self.assertEqual(
            crypto.encrypt(20104, b"login-ok"),
            (FIXTURES / "crypto_loginok.bin").read_bytes(),
        )
        self.assertEqual(
            crypto.encrypt(24101, b"own-home"),
            (FIXTURES / "crypto_ownhome.bin").read_bytes(),
        )
        self.assertEqual(
            crypto.decrypt(
                10108, (FIXTURES / "crypto_keepalive.bin").read_bytes()
            ),
            b"keepalive",
        )

    def test_raw_mode_and_tampered_ciphertext(self):
        raw = Crypto({"Enabled": False})
        self.assertEqual(raw.decrypt(10101, b"plain"), b"plain")
        self.assertEqual(raw.encrypt(20104, b"plain"), b"plain")

        crypto = Crypto({"Enabled": True})
        login = bytearray((FIXTURES / "crypto_login.bin").read_bytes())
        login[-1] ^= 1
        with self.assertRaises(CryptoError):
            crypto.decrypt(10101, bytes(login))


class SQLiteAccountTests(unittest.TestCase):
    def setUp(self):
        self.temp_directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp_directory.cleanup)
        self.database_path = str(Path(self.temp_directory.name) / "players.db")
        path_patch = patch.object(
            DataBase, "_database_path", lambda: self.database_path
        )
        path_patch.start()
        self.addCleanup(path_patch.stop)

    def make_player(self, low_id=1001, token="sqlite-token"):
        player = Players(SimpleNamespace())
        player.low_id = low_id
        player.high_id = 0
        player.token = token
        player.name = "SQLite Player"
        return player

    def test_account_round_trip_and_relational_updates(self):
        player = self.make_player()
        owner = SimpleNamespace(player=player)

        self.assertEqual(DataBase.createAccount(owner), 1001)
        self.assertEqual(player.player_experience, 99999)
        self.assertTrue(Path(self.database_path).is_file())
        self.assertEqual(DataBase.checkID(owner, 1001), 0)
        self.assertEqual(DataBase.checkID(owner, 1002), 1)
        with closing(sqlite3.connect(self.database_path)) as connection:
            columns = [
                row[1] for row in connection.execute("PRAGMA table_info(players)")
            ]
            self.assertEqual(columns, list(DataBase.PLAYER_STORAGE_COLUMNS))
            self.assertFalse(DataBase.STATE_COLUMNS.intersection(columns))
            self.assertEqual(
                connection.execute(
                    "SELECT COUNT(*) FROM player_state_entries "
                    "WHERE player_id = 1001 AND path = ''"
                ).fetchone()[0],
                len(DataBase.STATE_COLUMNS),
            )

        player.brawlers_trophies["0"] = 321
        player.UnlockedSkins["Skins"].append(7)
        self.assertTrue(
            DataBase.replaceValue(
                owner, "brawlersTrophies", player.brawlers_trophies
            )
        )
        self.assertTrue(
            DataBase.replaceValue(owner, "UnlockedSkins", player.UnlockedSkins)
        )
        self.assertTrue(DataBase.replaceOtherValue(owner, 1001, "gold", 456))
        self.assertTrue(DataBase.replaceValue(owner, "playerExp", 54321))

        loaded = self.make_player()
        loaded_owner = SimpleNamespace(player=loaded)
        self.assertTrue(DataBase.loadAccount(loaded_owner))
        self.assertEqual(loaded.name, "SQLite Player")
        self.assertEqual(loaded.low_id, 1001)
        self.assertEqual(loaded.brawlers_trophies["0"], 321)
        self.assertEqual(loaded.UnlockedSkins, {"Skins": [7]})
        self.assertEqual(loaded.gold, 456)
        self.assertEqual(loaded.player_experience, 54321)
        loaded.exp_points = 0
        home = OwnHomeDataMessage(None, loaded)
        home.encode()
        home_reader = BSMessageReader(home.buffer)
        daily_values = [home_reader.read_Vint() for _ in range(7)]
        self.assertEqual(daily_values[-1], 54321)

        rows = DataBase.loadById(owner, 1001)
        self.assertEqual(len(rows), 1)
        self.assertEqual(len(rows[0]), 40)                                   
        self.assertEqual(DataBase.loadMembersById(owner, 1001)[4], 1001)
        self.assertEqual(DataBase.getLeaders(owner)[0][0], 1001)

        missing = self.make_player(token="missing-token")
        self.assertFalse(DataBase.loadAccount(SimpleNamespace(player=missing)))

    def test_legacy_db_is_migrated_to_players_sqlite_without_overwrite(self):
        legacy_path = Path(self.database_path)
        sqlite_path = legacy_path.with_name("players.sqlite")
        states = {
            "brawlersSkins": {"0": 52, "1": 59},
            "brawlersTrophies": {"0": 321, "6": 40},
            "brawlersTrophiesForRank": {"0": 400, "6": 40},
            "brawlersUpgradePoints": {"0": 20, "6": 0},
            "brawlerPowerLevel": {"0": 9, "6": 1},
            "brawlerStarPower": {"0": 52},
            "UnlockedBrawlers": {"0": 1, "6": 1},
            "UnlockedSkins": {"Skins": [52, 59]},
            "Friends": {"legacy": {"lowID": 2, "name": "Amigo"}},
            "Notifications": {
                "0": {
                    "ID": 94,
                    "Read": False,
                    "Time": 1234.5,
                    "Text": "Olá",
                    "Payload": None,
                }
            },
            "progression": {
                "shop": {
                    "claimed": {"test": True},
                    "offers": [
                        {"items": [{"offerId": 10, "amount": 1}], "title": "test"}
                    ],
                },
                "nested": {
                    "array": [1, False, 2.5, "text", None, {"key/with/slash": "value"}],
                    "empty": {},
                    "emptyList": [],
                },
            },
        }
        self.assertEqual(set(states), DataBase.STATE_COLUMNS)
        legacy = sqlite3.connect(legacy_path)
        try:
            legacy.executescript(DataBase.PLAYER_TABLE_SCHEMA)
            for column in DataBase.STATE_COLUMNS:
                legacy.execute(f'ALTER TABLE players ADD COLUMN "{column}" TEXT')
            legacy.executescript(DataBase.CLUB_SCHEMA)
            legacy.executescript(DataBase.SOCIAL_SCHEMA)
            legacy.execute("PRAGMA journal_mode = WAL")
            columns = ["token", "name", "lowID", "gold"] + list(states)
            values = ["legacy-sqlite", "Legacy SQLite", 1042, 123]
            values += [json.dumps(states[column], ensure_ascii=False) for column in states]
            legacy.execute(
                f"INSERT INTO players ({', '.join(columns)}) "
                f"VALUES ({', '.join('?' for _ in columns)})",
                values,
            )
            legacy.commit()
            self.assertTrue(Path(str(legacy_path) + "-wal").exists())
            with patch.object(DataBase, "DATABASE_PATH", str(sqlite_path)), \
                 patch.object(DataBase, "LEGACY_DATABASE_PATH", str(legacy_path)), \
                 patch.object(DataBase, "_database_path", lambda: str(sqlite_path)):
                resolved = str(sqlite_path.resolve())
                self.addCleanup(DataBase._initialized_paths.discard, resolved)
                connection = DataBase._connect()
                try:
                    row = connection.execute(
                        "SELECT token, gold FROM players WHERE lowID = 1042"
                    ).fetchone()
                    self.assertEqual(row, ("legacy-sqlite", 123))
                    for column, expected in states.items():
                        self.assertEqual(
                            DataBase._read_state(connection, 1042, column),
                            expected,
                            column,
                        )
                    restored = DataBase._read_state(connection, 1042, "progression")
                    nested = restored["nested"]["array"]
                    self.assertIs(type(nested[0]), int)
                    self.assertIs(type(nested[1]), bool)
                    self.assertIs(type(nested[2]), float)
                    self.assertIs(type(nested[3]), str)
                    self.assertIsNone(nested[4])
                    self.assertIs(restored["shop"]["claimed"]["test"], True)
                    physical_columns = {
                        row[1] for row in connection.execute("PRAGMA table_info(players)")
                    }
                    self.assertFalse(DataBase.STATE_COLUMNS.intersection(physical_columns))
                    self.assertGreater(
                        connection.execute(
                            "SELECT COUNT(*) FROM player_state_entries WHERE player_id = 1042"
                        ).fetchone()[0],
                        1,
                    )
                    self.assertEqual(
                        connection.execute("PRAGMA integrity_check").fetchone()[0],
                        "ok",
                    )
                    self.assertEqual(connection.execute("PRAGMA foreign_key_check").fetchall(), [])
                    self.assertEqual(
                        connection.execute("PRAGMA user_version").fetchone()[0],
                        DataBase.RELATIONAL_SCHEMA_VERSION,
                    )
                finally:
                    connection.close()
                self.assertEqual(sqlite_path.read_bytes()[:16], b"SQLite format 3\x00")
                self.assertTrue(legacy_path.exists())
                with closing(sqlite3.connect(sqlite_path)) as connection:
                    connection.execute("UPDATE players SET gold = 999 WHERE lowID = 1042")
                    connection.commit()
                connection = DataBase._connect()
                try:
                    self.assertEqual(
                        connection.execute(
                            "SELECT gold FROM players WHERE lowID = 1042"
                        ).fetchone()[0],
                        999,
                    )
                    for column, expected in states.items():
                        self.assertEqual(
                            DataBase._read_state(connection, 1042, column),
                            expected,
                            column,
                        )
                finally:
                    connection.close()
        finally:
            legacy.close()

    def test_name_and_brawler_selection_survive_second_load(self):
        player = self.make_player()
        owner = SimpleNamespace(player=player)
        DataBase.createAccount(owner)

        server, client = socket.socketpair()
        try:
            rename = SetNameMessage(
                client, player, string("Persisted") + b"\x01"
            )
            rename.decode()
            rename.process()
            self.assertEqual(receive_packet(server)[0], 24111)
        finally:
            server.close()
            client.close()

        for brawler_id in player.brawlers_id:
            self.assertIsNotNone(
                Cards.get_spg_by_brawler_id(owner, brawler_id, 4),
                f"Brawler {brawler_id} has no valid V13 star power",
            )

        player.BrawlersUnlockedState["20"] = 1
        DataBase.replaceValue(
            owner, "UnlockedBrawlers", player.BrawlersUnlockedState
        )
        selection = LogicSelectSkinCommand(None, player, b"")
        player.skin_id = 0
        player.brawler_id = 20
        selection.process()
        self.assertEqual(player.starpower, 104)

        loaded = self.make_player()
        loaded_owner = SimpleNamespace(player=loaded)
        self.assertTrue(DataBase.loadAccount(loaded_owner))
        self.assertEqual(loaded.name, "Persisted")
        self.assertEqual(loaded.brawler_id, 20)
        self.assertEqual(loaded.starpower, 104)
        self.assertEqual(loaded.brawlers_skins["20"], 0)

    def test_legacy_experience_is_migrated_exactly_once(self):
        with closing(sqlite3.connect(self.database_path)) as connection:
            connection.executescript(DataBase.PLAYER_SCHEMA)
            connection.execute(
                "INSERT INTO players (token, name, lowID, playerExp) "
                "VALUES (?, ?, ?, ?)",
                ("legacy-exp", "Legacy", 1003, 17),
            )
            connection.commit()

        resolved_path = str(Path(self.database_path).resolve())
        self.addCleanup(DataBase._initialized_paths.discard, resolved_path)
        player = Players(SimpleNamespace())
        player.token = "legacy-exp"
        owner = SimpleNamespace(player=player)
        self.assertTrue(DataBase.loadAccount(owner))
        self.assertEqual(player.player_experience, 99999)

        with closing(sqlite3.connect(self.database_path)) as connection:
            saved = connection.execute(
                "SELECT playerExp FROM players WHERE lowID = 1003"
            ).fetchone()[0]
            version = connection.execute("PRAGMA user_version").fetchone()[0]
            self.assertEqual((saved, version), (99999, DataBase.RELATIONAL_SCHEMA_VERSION))
            connection.execute(
                "UPDATE players SET playerExp = 100020 WHERE lowID = 1003"
            )
            connection.commit()

        DataBase._initialized_paths.discard(resolved_path)
        reloaded = Players(SimpleNamespace())
        reloaded.token = "legacy-exp"
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=reloaded)))
        self.assertEqual(reloaded.player_experience, 100020)

    def test_zero_power_levels_are_preserved_on_reload(self):
        player = self.make_player(low_id=1002, token="power-token")
        self.assertEqual(player.Brawler_level["0"], 0)
        player.Brawler_level = {
            key: 0 for key in player.Brawler_level
        }
        owner = SimpleNamespace(player=player)
        DataBase.createAccount(owner)

        loaded = Players(SimpleNamespace())
        loaded.token = player.token
        loaded_owner = SimpleNamespace(player=loaded)
        self.assertTrue(DataBase.loadAccount(loaded_owner))
        self.assertEqual(loaded.Brawler_level["0"], 0)
        self.assertTrue(all(level >= 0 for level in loaded.Brawler_level.values()))
        self.assertEqual(
            loaded.progression["powerLevelWireVersion"],
            DataBase.POWER_LEVEL_WIRE_VERSION,
        )

    def test_legacy_one_based_power_levels_are_migrated_exactly_once(self):
        player = self.make_player(low_id=1004, token="legacy-power-levels")
        player.Brawler_level = {
            key: 1 for key in player.Brawler_level
        }
        player.Brawler_level["6"] = 9
        owner = SimpleNamespace(player=player)
        DataBase.createAccount(owner)
        legacy_progression = dict(player.progression)
        legacy_progression.pop("powerLevelWireVersion", None)
        self.assertTrue(DataBase.replaceValues(owner, {
            "brawlerPowerLevel": player.Brawler_level,
            "progression": legacy_progression,
        }))

        loaded = Players(SimpleNamespace())
        loaded.token = player.token
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=loaded)))
        self.assertEqual(loaded.Brawler_level["0"], 0)
        self.assertEqual(loaded.Brawler_level["6"], 8)
        self.assertEqual(
            loaded.progression["powerLevelWireVersion"],
            DataBase.POWER_LEVEL_WIRE_VERSION,
        )

        reloaded = Players(SimpleNamespace())
        reloaded.token = player.token
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=reloaded)))
        self.assertEqual(reloaded.Brawler_level, loaded.Brawler_level)

    def test_update_rejects_unknown_columns(self):
        owner = SimpleNamespace(player=self.make_player())
        with self.assertRaises(ValueError):
            DataBase.replaceValue(owner, "name; DROP TABLE players", "x")


class ClientActionTests(unittest.TestCase):
    def test_on_play_never_invalidates_the_login(self):
        player = fake_player()
        message = OnPlay(None, player, b"\x00\x00\x00\x01")
        message.decode()
        with patch.object(MatchMakingCancelledMessage, "send") as cancelled, \
             patch.object(LoginFailedMessage, "send") as login_failed:
            message.process()

        self.assertEqual(player.map_id, 15)
        self.assertEqual(player.mmplayers, 1)
        cancelled.assert_called_once()
        login_failed.assert_not_called()

    def test_event_action_rejects_unknown_slot_without_legacy_slots(self):
        player = Players(SimpleNamespace())
        message = LogicNewEventCommand(None, player, b"")
        message.event_index = 10
        with patch.object(
            EventSlots, "loadEvents",
            side_effect=AssertionError("legacy event JSON must not be read"),
        ):
            with self.assertRaises(ValueError):
                message.process()

    def test_end_client_turn_with_zero_commands_is_accepted(self):
        payload = vint(0) + vint(123) + vint(0) + vint(0) + b"\x00\x00\x00\x00"
        message = EndClientTurn(None, fake_player(), payload)
        message.decode()
        self.assertEqual(message.command_count, 0)
        self.assertIsNone(message.commandID)
        message.process()

    def test_short_end_client_turn_does_not_disconnect_session(self):
                                                                        
                                                                    
        payload = vint(0) + vint(1) + vint(0) + vint(1) + vint(506) + b"\x00\x00\x00"
        self.assertEqual(len(payload), 9)                                     
        message = EndClientTurn(None, fake_player(), payload)
        message.decode()
        with patch.object(LogicSelectSkinCommand, "process") as process:
            message.process()
        process.assert_not_called()

    def test_end_client_turn_still_dispatches_valid_command(self):
        payload = vint(0) + vint(1) + vint(0) + vint(1) + vint(509)
        payload += b"".join(vint(value) for value in (1, 1, -1, -1))
        payload += b"\xff" * 4
        message = EndClientTurn(None, fake_player(), payload)
        message.decode()
        with patch.object(LogicPurchaseDoubleCoinsCommand, "process") as process:
            message.process()
        process.assert_called_once_with(message)

    def test_unavailable_reward_does_not_invalidate_login(self):
        player = Players(SimpleNamespace())
        player.trophy_road = 0
        command = LogicClaimRankUpRewardCommand(None, player, b"")
        command.brawlerID = 0
        with patch.object(LoginFailedMessage, "send") as login_failed:
            command.process()
        login_failed.assert_not_called()


class LoginFlowTests(unittest.TestCase):
    def run_login(self, player, payload, database_events):
        message = LoginMessage(None, player, payload)
        message.decode()
        with patch.object(LoginOkMessage, "send", lambda self: database_events.append("loginok")), \
             patch.object(OwnHomeDataMessage, "send", lambda self: database_events.append("ownhome")), \
             patch.object(DataBase, "replaceValue", lambda self, column, value: True), \
             patch.object(NotificationFactory, "ensure_star_shelly", lambda player: False), \
             patch.object(LoginFailedMessage, "send", lambda self: database_events.append("failed")):
            result = message.process()
        return result

    def test_new_account_is_created_before_success_packets(self):
        events = []
        player = fake_player()
        with patch.object(Helpers, "randomID", lambda self: 1234), \
             patch.object(Helpers, "randomStringDigits", lambda self: "new-token"), \
             patch.object(DataBase, "createAccount", lambda self: events.append("create")):
            result = self.run_login(player, login_payload(), events)

        self.assertTrue(result)
        self.assertTrue(player.logged_in)
        self.assertEqual(player.online, 1)
        self.assertEqual((player.low_id, player.token), (1234, "new-token"))
        self.assertEqual(events, ["create", "loginok", "ownhome"])

    def test_existing_account_is_loaded_before_success_packets(self):
        events = []
        player = fake_player()
        player.low_id = 1234
        player.token = "saved-token"

        def load_account(message):
            events.append("load")
            return True

        with patch.object(DataBase, "loadAccount", load_account):
            result = self.run_login(
                player, login_payload(low_id=1234, token="saved-token"), events
            )

        self.assertTrue(result)
        self.assertEqual(events, ["load", "loginok", "ownhome"])

    def test_wrong_version_stops_before_database_and_home(self):
        events = []
        player = fake_player()
        with patch.object(DataBase, "createAccount") as create:
            result = self.run_login(player, login_payload(major=26), events)
        self.assertFalse(result)
        self.assertFalse(player.logged_in)
        self.assertEqual(events, ["failed"])
        create.assert_not_called()

    def test_missing_existing_account_is_rejected(self):
        events = []
        player = fake_player()
        player.low_id = 1234
        player.token = "bad-token"
        with patch.object(DataBase, "loadAccount", lambda self: False):
            result = self.run_login(
                player, login_payload(low_id=1234, token="bad-token"), events
            )
        self.assertFalse(result)
        self.assertEqual(events, ["failed"])


class ServerMaintenanceTests(unittest.TestCase):
    def test_rotation_does_not_start_legacy_daily_refresh(self):
        from main import Server

        self.assertFalse(hasattr(Server, "daily_timer"))


class LeaderboardCompatibilityTests(unittest.TestCase):
    def test_global_player_leaderboard_matches_v13_reference(self):
        player = SimpleNamespace(low_id=55113832, region="PT")
        entries = [{
            "low_id": 55113832,
            "name": "ABC",
            "trophies": 0,
            "profile_icon": 0,
            "name_color": 0,
            "club_id": 0,
            "club_name": "",
            "player_experience": 0,
            "online": 0,
        }]
        with patch.object(
            LeaderboardService, "players", lambda brawler_id=None: entries
        ):
            message = GetLeaderboardGlobalOkMessage(None, player)
            message.encode()
        self.assertEqual(
            message.buffer,
            (FIXTURES / "leaderboard_v13.bin").read_bytes(),
        )


class PlayerIsolationTests(unittest.TestCase):
    def test_mutable_brawler_and_skin_data_is_not_shared(self):
        first = Players(SimpleNamespace())
        second = Players(SimpleNamespace())

        first.brawlers_trophies["0"] = 777
        first.brawlers_skins["0"] = 12
        first.UnlockedSkins["Skins"].append(12)

        self.assertNotEqual(second.brawlers_trophies["0"], 777)
        self.assertNotEqual(second.brawlers_skins["0"], 12)
        self.assertNotIn(12, second.UnlockedSkins["Skins"])


class TcpFlowTests(unittest.TestCase):
    def test_two_tcp_clients_share_club_chat_and_profile(self):
        from main import ClientThread, Server

        server = Server("127.0.0.1", 0)
        server.crypto_settings = {"Enabled": False}
        server.Clients = {"ClientCounts": 0, "Clients": {}}
        self.addCleanup(server.server.close)
        connections = []
        threads = []

        def open_client():
            server_side, client_side = socket.socketpair()
            client_side.settimeout(2)
            thread = ClientThread(server_side, ("local", 0), server)
            connections.append(client_side)
            threads.append(thread)
            thread.start()
            client_side.sendall(packet(10100))
            self.assertEqual(receive_packet(client_side)[0], 20100)
            client_side.sendall(packet(10101, login_payload()))
            self.assertEqual(receive_packet(client_side)[0], 20104)
            self.assertEqual(receive_packet(client_side)[0], 24101)
            return client_side

        with tempfile.TemporaryDirectory() as directory:
            database_path = str(Path(directory) / "players.db")
            with patch.object(DataBase, "_database_path", lambda: database_path), \
                 patch.object(Helpers, "randomID", side_effect=[6101, 6102]), \
                 patch.object(
                     Helpers,
                     "randomStringDigits",
                     side_effect=["owner-token", "member-token"],
                 ), \
                 patch.object(Helpers, "randomClubID", lambda self: 620000), \
                 patch.object(EventSlots, "Timer", lambda self: 49020), \
                 patch("Logic.NotificationFactory.time.time", return_value=1000):
                owner = open_client()
                member = open_client()
                try:
                    owner.sendall(packet(10212, string("Owner TCP") + vint(1)))
                    self.assertEqual(receive_packet(owner)[0], 24111)
                    member.sendall(packet(10212, string("Member TCP") + vint(1)))
                    self.assertEqual(receive_packet(member)[0], 24111)

                    owner.sendall(packet(14303))
                    self.assertEqual(
                        receive_packet(owner),
                        (24304, 11, vint(0)),
                    )

                    create_payload = string("TCP Pair") + string("Desc")
                    create_payload += b"".join(
                        vint(value) for value in (8, 1, 1, 0)
                    )
                    owner.sendall(packet(14301, create_payload))
                    created = [receive_packet(owner) for _ in range(3)]
                    self.assertEqual(
                        [response[0] for response in created],
                        [24333, 24399, 24311],
                    )
                    self.assertEqual(
                        [response[1] for response in created],
                        [11, 11, 11],
                    )
                    create_reader = BSMessageReader(created[0][2])
                    self.assertEqual(create_reader.read_Vint(), 20)
                    self.assertEqual(create_reader.read(), b"")

                    member.sendall(packet(14305, int32(0) + int32(620000)))
                    joined = [receive_packet(member) for _ in range(4)]
                    self.assertEqual(
                        [response[0] for response in joined],
                        [24333, 24399, 24311, 24312],
                    )
                    self.assertEqual(
                        [response[1] for response in joined],
                        [11, 11, 11, 11],
                    )
                    owner_join = receive_packet(owner)
                    self.assertEqual((owner_join[0], owner_join[1]), (24312, 11))

                    owner.sendall(packet(14315, string("Two clients")))
                    owner_chat = receive_packet(owner)
                    member_chat = receive_packet(member)
                    self.assertEqual((owner_chat[0], owner_chat[1]), (24312, 11))
                    self.assertEqual(member_chat, owner_chat)

                    member.sendall(
                        packet(14113, int32(0) + int32(6101) + vint(0))
                    )
                    profile = receive_packet(member)
                    self.assertEqual((profile[0], profile[1]), (24113, 9))
                    profile_reader = BSMessageReader(profile[2])
                    self.assertEqual(
                        [profile_reader.read_Vint() for _ in range(2)],
                        [0, 6101],
                    )
                    self.assertEqual(profile_reader.read_string(), "Owner TCP")
                finally:
                    for connection in connections:
                        connection.close()
                    for thread in threads:
                        thread.join(2)
                    self.assertFalse(any(thread.is_alive() for thread in threads))

    def test_tcp_flow_and_second_login_use_real_sqlite(self):
        from main import ClientThread, Server

        server = Server("127.0.0.1", 0)
        server.crypto_settings = {"Enabled": False}
        server.Clients = {"ClientCounts": 0, "Clients": {}}
        self.addCleanup(server.server.close)

        with tempfile.TemporaryDirectory() as directory:
            database_path = str(Path(directory) / "players.db")
            server_side, client_side = socket.socketpair()
            client_side.settimeout(2)
            self.addCleanup(client_side.close)

            with patch.object(DataBase, "_database_path", lambda: database_path), \
                 patch.object(Helpers, "randomID", lambda self: 4242), \
                 patch.object(Helpers, "randomStringDigits", lambda self: "tcp-token"), \
                 patch.object(Helpers, "randomClubID", lambda self: 555555), \
                 patch.object(EventSlots, "Timer", lambda self: 49020), \
                 patch("Logic.NotificationFactory.time.time", return_value=1000):
                thread = ClientThread(server_side, ("local", 0), server)
                thread.start()

                                                                               
                hello = packet(10100)
                for byte in hello:
                    client_side.sendall(bytes([byte]))
                self.assertEqual(receive_packet(client_side)[0], 20100)

                login = packet(10101, login_payload())
                cut_points = [1, 2, 5, 9, 17, 31, len(login)]
                previous = 0
                for cut in cut_points:
                    client_side.sendall(login[previous:cut])
                    previous = cut

                login_ok = receive_packet(client_side)
                own_home = receive_packet(client_side)
                self.assertEqual((login_ok[0], login_ok[1]), (20104, 1))
                self.assertEqual(own_home[0], 24101)
                self.assertGreater(len(own_home[2]), 100)
                home_reader = BSMessageReader(own_home[2])
                daily_values = [home_reader.read_Vint() for _ in range(7)]
                self.assertEqual(daily_values[-1], 99999)
                star_shelly = bytes.fromhex("019e01b485d41b")
                wizard_barley = bytes.fromhex("019e01bb85d41b")
                login_notifications = star_shelly
                self.assertIn(
                    int32(0) + int32(4242) + login_notifications,
                    own_home[2],
                )
                self.assertNotIn(wizard_barley, own_home[2])

                for native_status in (-1, 8, 10, 11):
                    with self.subTest(login_presence=native_status):
                        client_side.sendall(
                            packet(14366, native_status_payload(native_status))
                        )
                        client_side.sendall(packet(10108))
                        keepalive_ok = receive_packet(client_side)
                        self.assertEqual(
                            (keepalive_ok[0], keepalive_ok[2]), (20108, b"")
                        )
                        self.assertTrue(thread.is_alive())

                event_turn = Writer(None)
                for value in (0, 1, 0, 1, 503, 0, 0, 0, 0, 1, 3):
                    event_turn.writeVint(value)
                client_side.sendall(packet(14366, native_status_payload(7)))
                client_side.sendall(packet(14102, event_turn.buffer))
                client_side.sendall(packet(10108))
                keepalive_ok = receive_packet(client_side)
                self.assertEqual((keepalive_ok[0], keepalive_ok[2]), (20108, b""))
                self.assertTrue(thread.is_alive())
                self.assertEqual(EventRotation.snapshot(thread.player)[0]["status"], 3)

                client_side.sendall(packet(10108))
                keepalive_ok = receive_packet(client_side)
                self.assertEqual((keepalive_ok[0], keepalive_ok[2]), (20108, b""))

                client_side.sendall(packet(10212, string("Ok") + vint(1)))
                renamed = receive_packet(client_side)
                self.assertEqual(renamed[0], 24111)
                self.assertEqual(renamed[2], vint(201) + string("Ok") + vint(1))
                client_side.sendall(packet(14109, b"\x01"))
                returned_home = receive_packet(client_side)
                self.assertEqual(returned_home[0], 24101)
                self.assertEqual(len(returned_home[2]), len(own_home[2]) - 3)
                self.assertIn(string("Ok"), returned_home[2])
                self.assertNotIn(string("Guest"), returned_home[2])

                create_payload = string("TCP Club") + string("Desc")
                create_payload += b"".join(vint(value) for value in (8, 1, 1, 0))
                client_side.sendall(packet(14301, create_payload))
                created_packets = [receive_packet(client_side) for _ in range(3)]
                self.assertEqual(
                    [created[0] for created in created_packets],
                    [24333, 24399, 24311],
                )
                create_ok_reader = BSMessageReader(created_packets[0][2])
                self.assertEqual(create_ok_reader.read_Vint(), 20)
                self.assertEqual(create_ok_reader.read(), b"")
                edit_payload = string("TCP Edited")
                edit_payload += b"".join(vint(value) for value in (8, 1, 1, 0))
                client_side.sendall(packet(14316, edit_payload))
                self.assertEqual(
                    [receive_packet(client_side)[0] for _ in range(2)],
                    [24333, 24399],
                )
                client_side.sendall(packet(10108))
                self.assertEqual(receive_packet(client_side)[0], 20108)

                with patch("builtins.print") as printed:
                    client_side.close()
                    thread.join(2)
                self.assertFalse(thread.is_alive())
                self.assertTrue(
                    any("client EOF" in str(call) for call in printed.call_args_list)
                )

                with closing(sqlite3.connect(database_path)) as connection:
                    saved = connection.execute(
                        "SELECT token, online, name, playerExp, clubID, clubRole "
                        "FROM players WHERE lowID = 4242"
                    ).fetchone()
                    membership = connection.execute(
                        "SELECT role FROM club_members "
                        "WHERE club_id = 555555 AND player_id = 4242"
                    ).fetchone()
                    club_description = connection.execute(
                        "SELECT description FROM clubs WHERE id = 555555"
                    ).fetchone()
                self.assertEqual(saved, ("tcp-token", 0, "Ok", 99999, 555555, 2))
                self.assertEqual(membership, (2,))
                self.assertEqual(club_description, ("TCP Edited",))

                                                                             
                                                                           
                second_server, second_client = socket.socketpair()
                second_client.settimeout(2)
                self.addCleanup(second_client.close)
                second_thread = ClientThread(second_server, ("local", 0), server)
                second_thread.start()
                second_client.sendall(packet(10100))
                self.assertEqual(receive_packet(second_client)[0], 20100)
                second_client.sendall(
                    packet(
                        10101,
                        login_payload(low_id=4242, token="tcp-token"),
                    )
                )
                self.assertEqual(receive_packet(second_client)[0], 20104)
                second_home = receive_packet(second_client)
                self.assertEqual(second_home[0], 24101)
                self.assertEqual(second_home[2], returned_home[2])
                my_alliance = receive_packet(second_client)
                self.assertEqual((my_alliance[0], my_alliance[1]), (24399, 11))
                alliance_reader = BSMessageReader(my_alliance[2])
                self.assertEqual(
                    [alliance_reader.read_Vint() for _ in range(4)],
                    [1, 1, 25, 2],
                )
                self.assertEqual(
                    (alliance_reader.read_int(), alliance_reader.read_int()),
                    (0, 555555),
                )
                self.assertEqual(alliance_reader.read_string(), "TCP Club")
                self.assertEqual(
                    [alliance_reader.read_Vint() for _ in range(7)],
                    [8, 1, 1, 1, 999, 0, 0],
                )
                self.assertEqual(alliance_reader.read_Vint(), 1)
                self.assertEqual(alliance_reader.read(), b"")
                alliance_stream = receive_packet(second_client)
                self.assertEqual(alliance_stream[0], 24311)
                self.assertEqual(BSMessageReader(alliance_stream[2]).read_Vint(), 0)
                second_client.sendall(
                    packet(14403, vint(1) + vint(1) + vint(0))
                )
                leaderboard = receive_packet(second_client)
                self.assertEqual((leaderboard[0], leaderboard[1]), (24403, 13))
                leaderboard_reader = BSMessageReader(leaderboard[2])
                self.assertEqual(
                    [leaderboard_reader.read_Vint(), leaderboard_reader.read_Vint()],
                    [1, 0],
                )
                self.assertEqual(leaderboard_reader.read_string(), "BR")
                self.assertEqual(leaderboard_reader.read_Vint(), 1)
                second_client.sendall(packet(14366, native_status_payload(10)))
                second_client.sendall(packet(10108))
                self.assertEqual(receive_packet(second_client)[0], 20108)
                self.assertTrue(second_thread.is_alive())
                second_client.sendall(packet(14110, battle_end_payload()))
                battle_result = receive_packet(second_client)
                self.assertEqual(battle_result[0], 23456)
                second_client.sendall(packet(14102, notification_claim_payload()))
                skin_reward = receive_packet(second_client)
                self.assertEqual(skin_reward[0], 24111)
                reward_reader = BSMessageReader(skin_reward[2])
                self.assertEqual(
                    [reward_reader.read_Vint() for _ in range(17)],
                    [203, 0, 1, 100, 1, 1, 0, 9, 29, 52, 0, 0, 0, 1, 0, 0, 0],
                )
                self.assertEqual(reward_reader.read(), b"")
                second_client.sendall(packet(14109, b"\x01"))
                claimed_home = receive_packet(second_client)
                self.assertEqual(claimed_home[0], 24101)
                self.assertNotIn(star_shelly, claimed_home[2])
                self.assertNotIn(wizard_barley, claimed_home[2])
                self.assertIn(
                    int32(0) + int32(4242) + vint(0), claimed_home[2]
                )
                second_client.sendall(packet(10108))
                self.assertEqual(receive_packet(second_client)[0], 20108)
                second_client.close()
                second_thread.join(2)
                self.assertFalse(second_thread.is_alive())

                with closing(sqlite3.connect(database_path)) as connection:
                    count = connection.execute(
                        "SELECT COUNT(*) FROM players WHERE lowID = 4242"
                    ).fetchone()[0]
                    unlocked_skins = DataBase._read_state(
                        connection, 4242, "UnlockedSkins"
                    )["Skins"]
                    notifications = DataBase._read_state(
                        connection, 4242, "Notifications"
                    )
                self.assertEqual(count, 1)
                self.assertEqual(unlocked_skins.count(52), 1)
                self.assertEqual(unlocked_skins.count(59), 0)
                self.assertEqual(len(notifications), 1)
                self.assertEqual(notifications["0"]["Type"], 94)
                self.assertEqual(notifications["0"]["SkinID"], 52)
                self.assertTrue(notifications["0"]["Read"])


class GemPersistenceTcpTests(unittest.TestCase):
    def test_spent_gems_survive_full_reconnect_and_second_home(self):
        from main import ClientThread, Server

        server = Server("127.0.0.1", 0)
        server.crypto_settings = {"Enabled": False}
        server.Clients = {"ClientCounts": 0, "Clients": {}}
        self.addCleanup(server.server.close)

        with tempfile.TemporaryDirectory() as directory:
            database_path = str(Path(directory) / "players.db")
            server_side, client_side = socket.socketpair()
            client_side.settimeout(3)
            self.addCleanup(client_side.close)

            with patch.object(DataBase, "_database_path", lambda: database_path), \
                 patch.object(Helpers, "randomID", lambda self: 4244), \
                 patch.object(Helpers, "randomStringDigits", lambda self: "persistent-token"):
                thread = ClientThread(server_side, ("local", 0), server)
                thread.start()
                client_side.sendall(packet(10100))
                self.assertEqual(receive_packet(client_side)[0], 20100)
                client_side.sendall(packet(10101, login_payload()))
                login_ok = receive_packet(client_side)
                self.assertEqual(receive_packet(client_side)[0], 24101)

                identity = BSMessageReader(login_ok[2])
                self.assertEqual(identity.read_int(), 0)
                low_id = identity.read_int()
                self.assertEqual(identity.read_int(), 0)
                self.assertEqual(identity.read_int(), low_id)
                token = identity.read_string()
                self.assertEqual((low_id, token), (4244, "persistent-token"))

                turn_payload = (
                    vint(0) + vint(1) + vint(0) + vint(1) + vint(521)
                    + vint(1) + vint(1) + vint(-1) + vint(-1) + vint(2)
                    + b"\xff" * 4
                )
                client_side.sendall(packet(14102, turn_payload))
                client_side.sendall(packet(10108))
                self.assertEqual(receive_packet(client_side)[0], 20108)

                with closing(sqlite3.connect(database_path)) as connection:
                    saved = connection.execute(
                        "SELECT gems, gold FROM players WHERE lowID = 4244"
                    ).fetchone()
                self.assertEqual(saved, (859, 1300))

                client_side.close()
                thread.join(3)
                self.assertFalse(thread.is_alive())

                second_server, second_client = socket.socketpair()
                second_client.settimeout(3)
                self.addCleanup(second_client.close)
                second_thread = ClientThread(second_server, ("local", 0), server)
                second_thread.start()
                second_client.sendall(packet(10100))
                self.assertEqual(receive_packet(second_client)[0], 20100)

                observed = []
                original_send = OwnHomeDataMessage.send

                def capture_home(message):
                    observed.append({
                        "low_id": message.player.low_id,
                        "gems": message.player.gems,
                        "gold": message.player.gold,
                    })
                    return original_send(message)

                with patch.object(OwnHomeDataMessage, "send", capture_home):
                    second_client.sendall(
                        packet(10101, login_payload(low_id=low_id, token=token))
                    )
                    self.assertEqual(receive_packet(second_client)[0], 20104)
                    self.assertEqual(receive_packet(second_client)[0], 24101)

                self.assertEqual(observed, [{
                    "low_id": 4244, "gems": 859, "gold": 1300,
                }])
                second_client.close()
                second_thread.join(3)
                self.assertFalse(second_thread.is_alive())

                with closing(sqlite3.connect(database_path)) as connection:
                    account_count = connection.execute(
                        "SELECT COUNT(*) FROM players WHERE lowID = 4244"
                    ).fetchone()[0]
                self.assertEqual(account_count, 1)


class EncryptedTcpFlowTests(unittest.TestCase):
    def test_real_login_home_and_keepalive_over_v13_crypto(self):
        from main import ClientThread, Server

        server = Server("127.0.0.1", 0)
        server.Clients = {"ClientCounts": 0, "Clients": {}}
        self.addCleanup(server.server.close)

        with tempfile.TemporaryDirectory() as directory:
            database_path = str(Path(directory) / "players.db")
            server_side, client_side = socket.socketpair()
            client_side.settimeout(2)
            self.addCleanup(client_side.close)

            with patch.object(DataBase, "_database_path", lambda: database_path), \
                 patch.object(Helpers, "randomID", lambda self: 4243), \
                 patch.object(Helpers, "randomStringDigits", lambda self: "crypto-token"):
                thread = ClientThread(server_side, ("local", 0), server)
                thread.start()

                connection = client_side
                connection.sendall(packet(10100))
                self.assertEqual(receive_packet(connection)[:2], (20100, 0))

                client = Crypto({"Enabled": True})
                session_key = bytes(range(24))
                client_nonce = bytes(range(24, 48))
                nonce = Nonce(
                    clientKey=client.client_pk,
                    serverKey=client.server_key,
                )
                encrypted_login = client.client_pk + NaCl19.secretbox(
                    session_key + client_nonce + login_payload(),
                    bytes(nonce),
                    client.shared_key,
                )
                login_packet = packet(10101, encrypted_login)
                connection.sendall(login_packet[:13])
                connection.sendall(login_packet[13:67])
                connection.sendall(login_packet[67:])

                login_ok_id, _, login_ok = receive_packet(connection)
                home_id, _, home = receive_packet(connection)
                self.assertEqual(login_ok_id, 20104)
                self.assertEqual(home_id, 24101)

                login_nonce = Nonce(
                    client_nonce,
                    clientKey=client.client_pk,
                    serverKey=client.server_key,
                )
                session = NaCl19.secretbox_open(
                    login_ok, bytes(login_nonce), client.shared_key
                )
                server_nonce = session[:24]
                shared_en = session[24:56]
                self.assertGreater(len(session[56:]), 100)

                home_nonce = Nonce(server_nonce)
                home_nonce.increment()
                raw_home = NaCl19.secretbox_open(
                    home, bytes(home_nonce), shared_en
                )
                self.assertGreater(len(raw_home), 100)

                next_client_nonce = Nonce(client_nonce)
                next_client_nonce.increment()
                analytics_payload = string("Economy") + string('{"test":true}')
                analytics = NaCl19.secretbox(
                    analytics_payload, bytes(next_client_nonce), shared_en
                )
                connection.sendall(packet(10110, analytics))

                                                                          
                                                                            
                                                                     
                next_client_nonce.increment()
                short_turn_payload = (
                    vint(0) + vint(1) + vint(0) + vint(1) + vint(506)
                    + b"\x00\x00\x00"
                )
                self.assertEqual(len(short_turn_payload), 9)
                short_turn = NaCl19.secretbox(
                    short_turn_payload, bytes(next_client_nonce), shared_en
                )
                self.assertEqual(len(short_turn), 25)
                connection.sendall(packet(14102, short_turn))

                next_client_nonce.increment()
                keepalive = NaCl19.secretbox(
                    b"", bytes(next_client_nonce), shared_en
                )
                connection.sendall(packet(10108, keepalive))
                keepalive_ok_id, _, keepalive_ok = receive_packet(connection)
                self.assertEqual(keepalive_ok_id, 20108)
                self.assertEqual(len(keepalive_ok), 16)
                home_nonce.increment()
                self.assertEqual(
                    NaCl19.secretbox_open(
                        keepalive_ok, bytes(home_nonce), shared_en
                    ),
                    b"",
                )

                next_client_nonce.increment()
                joinable_request = NaCl19.secretbox(
                    b"", bytes(next_client_nonce), shared_en
                )
                self.assertEqual(len(joinable_request), 16)
                connection.sendall(packet(14303, joinable_request))
                joinable_id, joinable_version, joinable_response = receive_packet(
                    connection
                )
                self.assertEqual((joinable_id, joinable_version), (24304, 11))
                self.assertEqual(len(joinable_response), 17)
                home_nonce.increment()
                self.assertEqual(
                    NaCl19.secretbox_open(
                        joinable_response, bytes(home_nonce), shared_en
                    ),
                    vint(0),
                )

                connection.close()
                thread.join(2)
                self.assertFalse(thread.is_alive())
                self.assertEqual(server.Clients["ClientCounts"], 0)

                with closing(sqlite3.connect(database_path)) as check:
                    saved = check.execute(
                        "SELECT token, online FROM players WHERE lowID = 4243"
                    ).fetchone()
                    progression = DataBase._read_state(
                        check, 4243, "progression"
                    )
                self.assertEqual(saved[:2], ("crypto-token", 0))
                self.assertNotIn("shopOffers", progression)
                offers = progression["shop"]["offers"]
                self.assertEqual(len(offers), 4)
                self.assertEqual([offer["key"] for offer in offers].count("free_box"), 1)
                self.assertEqual([offer["key"] for offer in offers].count("power_points"), 1)
                self.assertEqual([offer["key"] for offer in offers].count("the_big_three"), 1)
                self.assertEqual([offer["key"] for offer in offers].count("gems_big_mega"), 1)
                big_three = next(offer for offer in offers if offer["key"] == "the_big_three")
                bundle = next(offer for offer in offers if offer["key"] == "gems_big_mega")
                self.assertEqual(
                    (big_three["title"], big_three["price"]),
                    ("The big Three", 0),
                )
                self.assertEqual(
                    [item["target"] for item in big_three["items"]],
                    [[16, 12], [16, 23], [16, 5]],
                )
                self.assertEqual(
                    (bundle["title"], bundle["price"]),
                    ("50 Gemas + 3 BIGBOX + 2 MEGABOX", 0),
                )
                self.assertTrue(big_three["oneTime"])
                self.assertTrue(bundle["oneTime"])
                self.assertEqual(
                    [(item["offerId"], item["amount"]) for item in bundle["items"]],
                    [(16, 50), (14, 3), (10, 2)],
                )
                self.assertEqual(progression["shop"]["claimed"], {})
                self.assertEqual(len({
                    offer["items"][0]["target"][1]
                    for offer in offers if offer["key"] == "power_points"
                }), 1)
                self.assertEqual(progression["shop"]["billing"], {
                    "transactions": {}, "bundles": {},
                })


if __name__ == "__main__":
    unittest.main(verbosity=2)
