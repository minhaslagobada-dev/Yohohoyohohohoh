import copy
import os
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

PROJECT_ROOT = Path(__file__).resolve().parents[1]
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from Database.DatabaseManager import DataBase
from Logic.EventSlots import EventSlots
from Logic.NotificationFactory import NotificationFactory
from Logic.Player import Players
from Logic.Rewards import RewardError
from Packets.Commands.Client.LogicDeleteNotificationCommand import LogicDeleteNotificationCommand
from Packets.Commands.Client.LogicViewNotificationCommand import LogicViewNotificationCommand
from Packets.LogicCommandManager import EndClientTurn
from Packets.Messages.Server.Home.OwnHomeDataMessage import OwnHomeDataMessage
from Utils.Reader import BSMessageReader
from Utils.Writer import Writer


class CaptureClient:
    def __init__(self):
        self.packets = []

    def sendall(self, data):
        self.packets.append(bytes(data))


def vint(value):
    writer = Writer(None)
    writer.writeVint(value)
    return writer.buffer


def string(value):
    encoded = value.encode("utf-8")
    return len(encoded).to_bytes(4, "big") + encoded


def claim_payload(notification_index, short=False):
    writer = Writer(None)
    for value in (0, 0, 0, 1, 528):
        writer.writeVint(value)
    values = (
        (notification_index, 0)
        if short
        else (0, 0, 0, 0, notification_index)
    )
    for value in values:
        writer.writeVint(value)
    return writer.buffer


def delete_payload(action=8):
    writer = Writer(None)
    for value in (0, 137, 0, 1, 514, 136, 136, -64, -64, action):
        writer.writeVint(value)
    return writer.buffer + b"\xff" * 4


class NotificationFactoryTests(unittest.TestCase):
    def setUp(self):
        self.temp_directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp_directory.cleanup)
        self.database_path = str(Path(self.temp_directory.name) / "players.db")
        path_patch = patch.object(
            DataBase, "_database_path", lambda: self.database_path
        )
        path_patch.start()
        self.addCleanup(path_patch.stop)
        shop_patch = patch(
            "Packets.Messages.Server.Home.OwnHomeDataMessage.ShopService.encode_home",
            lambda writer, player: writer.writeVint(0),
        )
        shop_patch.start()
        self.addCleanup(shop_patch.stop)
        self.player = Players(SimpleNamespace())
        self.player.low_id = 42
        self.player.high_id = 0
        self.player.scid_account = SimpleNamespace(game_low_id=42)
        self.player.token = "notification-token"
        self.player.name = "Notify"
        DataBase.createAccount(SimpleNamespace(player=self.player))

    @staticmethod
    def encode_home(player, now):
        message = OwnHomeDataMessage(None, player)
        with patch.object(EventSlots, "Timer", lambda self: 49020), \
             patch(
                 "Packets.Messages.Server.Home.OwnHomeDataMessage.SeasonService.sync",
                 return_value={"remaining": 0},
             ), patch("Logic.NotificationFactory.time.time", return_value=now), \
             patch("Packets.Messages.Server.Home.OwnHomeDataMessage.time.time", return_value=1000):
            message.encode()
        return message.buffer

    def test_skin_notification_persists_and_extends_only_home_factory(self):
        self.player.high_id = 0x01020304
        empty = self.encode_home(self.player, 1000)
        self.assertTrue(empty.endswith(Writer._native_vint_bytes(1000)))
        with patch("Logic.NotificationFactory.time.time", return_value=1000):
            notification = NotificationFactory.add_skin(
                self.player, 2, "Skin especial"
            )
        self.assertEqual(
            notification,
            {
                "Type": 94,
                "Index": 1,
                "Read": False,
                "Time": 1000,
                "Text": "Skin especial",
                "SkinID": 2,
            },
        )
        self.assertEqual(self.player.UnlockedSkins, {"Skins": []})

        loaded = Players(SimpleNamespace())
        loaded.token = self.player.token
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=loaded)))
        self.assertEqual(loaded.Notifications, self.player.Notifications)

        full = self.encode_home(self.player, 1025)
        block = vint(1) + vint(94) + vint(29000002)
        self.assertEqual(block, bytes.fromhex("019e018285d41b"))
        account_id = (0x01020304).to_bytes(4, "big") + (42).to_bytes(4, "big")
        self.assertIn(account_id + block, full)
        self.assertEqual(full.replace(block, b"\x00", 1), empty)
        reader = BSMessageReader(block)
        self.assertEqual(
            [reader.read_Vint() for _ in range(3)],
            [1, 94, 29000002],
        )
        self.assertEqual(reader.read(), b"")

        with patch("Logic.NotificationFactory.time.time", return_value=1030):
            second = NotificationFactory.add_skin(self.player, 5)
        self.assertEqual(second["Index"], 2)
        self.assertEqual(len(self.player.Notifications), 2)

    def test_factory_uses_v13_body_and_ignores_read_or_other_types(self):
        self.player.Notifications = {
            "0": {
                "Type": 94,
                "Index": 15,
                "Read": True,
                "Time": 900,
                "Text": "Voucher: redeemed",
                "SkinID": 2,
            },
            "1": {
                "ID": 94,
                "Index": 16,
                "Read": False,
                "Time": 1000,
                "SkinID": 5,
            },
            "2": {
                "ID": 81,
                "Index": 17,
                "Text": "Legacy",
            },
        }
        writer = OwnHomeDataMessage(None, self.player)
        NotificationFactory.encode(writer, self.player.Notifications, now=1100)
        reader = BSMessageReader(writer.buffer)
        self.assertEqual(
            [reader.read_Vint() for _ in range(3)],
            [1, 94, 29000005],
        )
        self.assertEqual(reader.read(), b"")

    def test_star_shelly_is_unique_and_claim_persists_without_duplicates(self):
        with patch("Logic.NotificationFactory.time.time", return_value=1000):
            self.assertTrue(NotificationFactory.ensure_star_shelly(self.player))
            self.assertFalse(NotificationFactory.ensure_star_shelly(self.player))
        self.assertEqual(len(self.player.Notifications), 1)
        notification = self.player.Notifications["0"]
        self.assertEqual(
            (notification["Type"], notification["SkinID"], notification["Index"]),
            (94, 52, 1),
        )
        self.assertFalse(notification["Read"])
        self.assertEqual(
            notification["Text"], NotificationFactory.STAR_SHELLY_TEXT
        )
        home = OwnHomeDataMessage(None, self.player)
        NotificationFactory.encode(home, self.player.Notifications)
        self.assertEqual(home.buffer, bytes.fromhex("019e01b485d41b"))

        client = CaptureClient()
        turn = EndClientTurn(client, self.player, claim_payload(1))
        turn.decode()
        turn.process()
        self.assertEqual(turn.notification_index, 1)
        self.assertEqual(turn.read(), b"")
        self.assertEqual(len(client.packets), 1)
        packet = client.packets[0]
        self.assertEqual(int.from_bytes(packet[:2], "big"), 24111)
        response = BSMessageReader(packet[7:])
        self.assertEqual(
            [response.read_Vint() for _ in range(17)],
            [203, 0, 1, 100, 1, 1, 0, 9, 29, 52, 0, 0, 0, 1, 0, 0, 0],
        )
        self.assertEqual(response.read(), b"")
        self.assertIn(52, self.player.UnlockedSkins["Skins"])
        self.assertEqual(self.player.brawlers_skins["0"], 52)
        self.assertTrue(self.player.Notifications["0"]["Read"])

        loaded = Players(SimpleNamespace())
        loaded.token = self.player.token
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=loaded)))
        self.assertEqual(loaded.UnlockedSkins["Skins"].count(52), 1)
        self.assertTrue(loaded.Notifications["0"]["Read"])
        self.assertFalse(NotificationFactory.ensure_star_shelly(loaded))

        replay_client = CaptureClient()
        replay = EndClientTurn(replay_client, self.player, claim_payload(1))
        replay.decode()
        replay.process()
        self.assertEqual(replay_client.packets, [])
        self.assertEqual(self.player.UnlockedSkins["Skins"].count(52), 1)

    def test_wizard_barley_is_unique_and_follows_star_shelly_in_home(self):
        with patch("Logic.NotificationFactory.time.time", return_value=1000):
            self.assertTrue(NotificationFactory.ensure_star_shelly(self.player))
            self.assertTrue(NotificationFactory.ensure_wizard_barley(self.player))
            self.assertFalse(NotificationFactory.ensure_wizard_barley(self.player))
        self.assertEqual(len(self.player.Notifications), 2)
        self.assertEqual(self.player.BrawlersUnlockedState["6"], 1)
        self.assertNotIn(59, self.player.UnlockedSkins["Skins"])
        notification = self.player.Notifications["1"]
        self.assertEqual(
            (notification["Type"], notification["SkinID"], notification["Index"]),
            (94, 59, 2),
        )
        self.assertFalse(notification["Read"])
        self.assertEqual(
            notification["Text"], NotificationFactory.WIZARD_BARLEY_TEXT
        )
        home = OwnHomeDataMessage(None, self.player)
        NotificationFactory.encode(home, self.player.Notifications)
        self.assertEqual(
            home.buffer, bytes.fromhex("029e01b485d41b9e01bb85d41b")
        )

        loaded = Players(SimpleNamespace())
        loaded.token = self.player.token
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=loaded)))
        self.assertFalse(NotificationFactory.ensure_star_shelly(loaded))
        self.assertFalse(NotificationFactory.ensure_wizard_barley(loaded))
        self.assertEqual(loaded.Notifications, self.player.Notifications)
        self.assertEqual(loaded.BrawlersUnlockedState["6"], 1)

    def test_wizard_barley_requires_scid_for_home_and_claim(self):
        with patch("Logic.NotificationFactory.time.time", return_value=1000):
            NotificationFactory.ensure_wizard_barley(self.player)
        notification = self.player.Notifications["0"]
        self.player.scid_account = None

        self.assertEqual(NotificationFactory.home_notifications(self.player), {})
        self.assertIsNone(NotificationFactory.next_pending_type(self.player))
        hidden_home = self.encode_home(self.player, 1000)
        self.assertNotIn(bytes.fromhex("019e01bb85d41b"), hidden_home)
        with self.assertRaises(ValueError):
            NotificationFactory.notification_type_at_index(self.player, 1)
        with self.assertRaises(ValueError):
            NotificationFactory.claim_skin(self.player, 1)
        self.assertFalse(notification["Read"])
        self.assertNotIn(59, self.player.UnlockedSkins["Skins"])
        self.assertIn("0", self.player.Notifications)

        self.player.scid_account = SimpleNamespace(game_low_id=42)
        self.assertTrue(NotificationFactory.has_scid_connection(self.player))
        self.assertEqual(NotificationFactory.next_pending_type(self.player), 94)
        visible_home = self.encode_home(self.player, 1000)
        self.assertIn(bytes.fromhex("019e01bb85d41b"), visible_home)
        result = NotificationFactory.claim_next_skin(self.player)
        self.assertEqual(result["skin"], 59)
        self.assertTrue(self.player.Notifications["0"]["Read"])
        self.assertEqual(self.player.UnlockedSkins["Skins"].count(59), 1)

    def test_config_flags_hide_skin_notifications_independently(self):
        with patch("Logic.NotificationFactory.time.time", return_value=1000):
            NotificationFactory.ensure_star_shelly(self.player)
            NotificationFactory.ensure_wizard_barley(self.player)
        cases = (
            (False, False, [52, 59]),
            (True, False, [59]),
            (False, True, [52]),
            (True, True, []),
        )
        for star_hidden, wizard_hidden, expected in cases:
            with self.subTest(
                StarShelly=star_hidden, WizardBarley=wizard_hidden
            ), patch(
                "Logic.NotificationFactory.Config.GetValue",
                return_value={
                    "StarShelly": star_hidden,
                    "WizardBarley": wizard_hidden,
                },
            ):
                writer = OwnHomeDataMessage(None, self.player)
                NotificationFactory.encode(writer, self.player.Notifications)
                reader = BSMessageReader(writer.buffer)
                self.assertEqual(reader.read_Vint(), len(expected))
                for skin_id in expected:
                    self.assertEqual(
                        (reader.read_Vint(), reader.read_Vint()),
                        (94, 29000000 + skin_id),
                    )
                self.assertEqual(reader.read(), b"")
        self.assertEqual(len(self.player.Notifications), 2)
        self.assertEqual(self.player.BrawlersUnlockedState["6"], 1)
        loaded = Players(SimpleNamespace())
        loaded.token = self.player.token
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=loaded)))
        self.assertEqual(loaded.Notifications, self.player.Notifications)
        self.assertEqual(loaded.BrawlersUnlockedState["6"], 1)

    def test_legacy_wizard_notification_unlocks_barley_without_duplication(self):
        NotificationFactory.ensure_star_shelly(self.player)
        NotificationFactory.add_skin(
            self.player, 59, NotificationFactory.WIZARD_BARLEY_TEXT
        )
        self.assertEqual(self.player.BrawlersUnlockedState["6"], 0)
        before = copy.deepcopy(self.player.Notifications)
        self.assertTrue(NotificationFactory.ensure_wizard_barley(self.player))
        self.assertEqual(self.player.BrawlersUnlockedState["6"], 1)
        self.assertEqual(self.player.Notifications, before)
        self.assertFalse(NotificationFactory.ensure_wizard_barley(self.player))
        loaded = Players(SimpleNamespace())
        loaded.token = self.player.token
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=loaded)))
        self.assertEqual(loaded.BrawlersUnlockedState["6"], 1)
        self.assertEqual(loaded.Notifications, before)

    def test_legacy_wizard_claim_delivers_barley_and_skin_in_one_command(self):
        NotificationFactory.add_skin(
            self.player, 59, NotificationFactory.WIZARD_BARLEY_TEXT
        )
        self.assertEqual(self.player.BrawlersUnlockedState["6"], 0)
        self.assertNotIn(59, self.player.UnlockedSkins["Skins"])

        client = CaptureClient()
        turn = EndClientTurn(client, self.player, claim_payload(1))
        turn.decode()
        turn.process()
        self.assertEqual(turn.commandID, 528)
        self.assertEqual(len(client.packets), 1)
        response = BSMessageReader(client.packets[0][7:])
        self.assertEqual(
            [response.read_Vint() for _ in range(23)],
            [
                203, 0, 1, 100, 2,
                1, 16, 6, 1, 0, 0,
                1, 0, 9, 29, 59, 0,
                0, 0, 1, 0, 0, 0,
            ],
        )
        self.assertEqual(response.read(), b"")
        self.assertEqual(self.player.BrawlersUnlockedState["6"], 1)
        self.assertEqual(self.player.UnlockedSkins["Skins"].count(59), 1)
        self.assertEqual(self.player.brawlers_skins["6"], 59)
        self.assertTrue(self.player.Notifications["0"]["Read"])

        loaded = Players(SimpleNamespace())
        loaded.token = self.player.token
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=loaded)))
        self.assertEqual(loaded.BrawlersUnlockedState["6"], 1)
        self.assertEqual(loaded.UnlockedSkins["Skins"].count(59), 1)
        self.assertEqual(loaded.brawlers_skins["6"], 59)
        self.assertTrue(loaded.Notifications["0"]["Read"])

        replay_client = CaptureClient()
        replay = EndClientTurn(replay_client, loaded, claim_payload(1))
        replay.decode()
        replay.process()
        self.assertEqual(replay_client.packets, [])
        self.assertEqual(loaded.UnlockedSkins["Skins"].count(59), 1)
        self.assertFalse(NotificationFactory.ensure_wizard_barley(loaded))

    def test_wizard_combined_claim_rolls_back_every_change_on_failure(self):
        NotificationFactory.add_skin(
            self.player, 59, NotificationFactory.WIZARD_BARLEY_TEXT
        )
        with patch.object(DataBase, "replaceValues", return_value=False):
            with self.assertRaises(RewardError):
                NotificationFactory.claim_skin(self.player, 1)
        self.assertEqual(self.player.BrawlersUnlockedState["6"], 0)
        self.assertNotIn(59, self.player.UnlockedSkins["Skins"])
        self.assertFalse(self.player.Notifications["0"]["Read"])

        loaded = Players(SimpleNamespace())
        loaded.token = self.player.token
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=loaded)))
        self.assertEqual(loaded.BrawlersUnlockedState["6"], 0)
        self.assertNotIn(59, loaded.UnlockedSkins["Skins"])
        self.assertFalse(loaded.Notifications["0"]["Read"])

    def test_view_notification_decoder_accepts_short_layout(self):
        turn = EndClientTurn(None, self.player, claim_payload(7, short=True))
        turn.decode()
        self.assertEqual(turn.read_Vint(), 528)
        LogicViewNotificationCommand.decode(turn)
        self.assertEqual(turn.notification_index, 7)
        self.assertEqual(turn.read(), b"")

    def test_v13_delete_notification_claims_real_skin_action(self):
        NotificationFactory.ensure_star_shelly(self.player)
        client = CaptureClient()
        real_payload = bytes.fromhex("00890200018208880288027f7f08ffffffff")
        self.assertEqual(delete_payload(), real_payload)
        turn = EndClientTurn(
            client,
            self.player,
            real_payload,
        )
        turn.decode()
        turn.process()
        self.assertEqual(turn.command_count, 1)
        self.assertEqual(turn.commandID, 514)
        self.assertEqual(turn.notification_action, 8)
        self.assertEqual(turn.read(), b"\xff\xff\xff\xff")
        self.assertEqual(len(client.packets), 1)
        packet = client.packets[0]
        self.assertEqual(int.from_bytes(packet[:2], "big"), 24111)
        response = BSMessageReader(packet[7:])
        self.assertEqual(
            [response.read_Vint() for _ in range(17)],
            [203, 0, 1, 100, 1, 1, 0, 9, 29, 52, 0, 0, 0, 1, 0, 0, 0],
        )
        self.assertEqual(response.read(), b"")
        self.assertTrue(self.player.Notifications["0"]["Read"])
        self.assertIn(52, self.player.UnlockedSkins["Skins"])

        loaded = Players(SimpleNamespace())
        loaded.token = self.player.token
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=loaded)))
        self.assertTrue(loaded.Notifications["0"]["Read"])
        self.assertEqual(loaded.UnlockedSkins["Skins"].count(52), 1)
        self.assertFalse(NotificationFactory.ensure_star_shelly(loaded))

        replay_client = CaptureClient()
        replay = EndClientTurn(
            replay_client,
            self.player,
            bytes.fromhex("00890200018208880288027f7f08ffffffff"),
        )
        replay.decode()
        replay.process()
        self.assertEqual(replay_client.packets, [])
        self.assertEqual(self.player.UnlockedSkins["Skins"].count(52), 1)

    def test_v13_skin_action_claims_multiple_rewards_in_home_order(self):
        NotificationFactory.ensure_star_shelly(self.player)
        NotificationFactory.ensure_wizard_barley(self.player)

        def claim(player):
            client = CaptureClient()
            turn = EndClientTurn(client, player, delete_payload())
            turn.decode()
            turn.process()
            self.assertEqual(turn.commandID, 514)
            self.assertEqual(turn.notification_action, 8)
            self.assertEqual(turn.read(), b"\xff" * 4)
            return client

        first_client = claim(self.player)
        self.assertEqual(len(first_client.packets), 1)
        first_response = BSMessageReader(first_client.packets[0][7:])
        self.assertEqual(
            [first_response.read_Vint() for _ in range(17)],
            [203, 0, 1, 100, 1, 1, 0, 9, 29, 52, 0, 0, 0, 1, 0, 0, 0],
        )
        self.assertEqual(first_response.read(), b"")
        self.assertTrue(self.player.Notifications["0"]["Read"])
        self.assertFalse(self.player.Notifications["1"]["Read"])
        self.assertIn(52, self.player.UnlockedSkins["Skins"])
        self.assertNotIn(59, self.player.UnlockedSkins["Skins"])

        second_client = claim(self.player)
        self.assertEqual(len(second_client.packets), 1)
        second_response = BSMessageReader(second_client.packets[0][7:])
        self.assertEqual(
            [second_response.read_Vint() for _ in range(23)],
            [
                203, 0, 1, 100, 2,
                1, 16, 6, 1, 0, 0,
                1, 0, 9, 29, 59, 0,
                0, 0, 1, 0, 0, 0,
            ],
        )
        self.assertEqual(second_response.read(), b"")
        self.assertTrue(self.player.Notifications["0"]["Read"])
        self.assertTrue(self.player.Notifications["1"]["Read"])
        self.assertEqual(self.player.UnlockedSkins["Skins"].count(52), 1)
        self.assertEqual(self.player.UnlockedSkins["Skins"].count(59), 1)
        self.assertEqual(self.player.brawlers_skins["0"], 52)
        self.assertEqual(self.player.brawlers_skins["6"], 59)
        self.assertEqual(self.player.BrawlersUnlockedState["6"], 1)

        loaded = Players(SimpleNamespace())
        loaded.token = self.player.token
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=loaded)))
        self.assertTrue(loaded.Notifications["0"]["Read"])
        self.assertTrue(loaded.Notifications["1"]["Read"])
        self.assertEqual(loaded.UnlockedSkins["Skins"].count(52), 1)
        self.assertEqual(loaded.UnlockedSkins["Skins"].count(59), 1)
        self.assertFalse(NotificationFactory.ensure_star_shelly(loaded))
        self.assertFalse(NotificationFactory.ensure_wizard_barley(loaded))
        replay_client = claim(loaded)
        self.assertEqual(replay_client.packets, [])
        self.assertEqual(loaded.UnlockedSkins["Skins"].count(52), 1)
        self.assertEqual(loaded.UnlockedSkins["Skins"].count(59), 1)

    def test_v13_action_does_not_block_skin_claim_and_empty_queue_is_noop(self):
        NotificationFactory.ensure_star_shelly(self.player)
        client = CaptureClient()
        turn = EndClientTurn(client, self.player, delete_payload(1))
        turn.decode()
        turn.process()
        self.assertEqual(turn.commandID, 514)
        self.assertEqual(turn.notification_action, 1)
        self.assertEqual(len(client.packets), 1)
        self.assertTrue(self.player.Notifications["0"]["Read"])
        self.assertEqual(self.player.UnlockedSkins["Skins"].count(52), 1)

        replay_client = CaptureClient()
        replay = EndClientTurn(replay_client, self.player, delete_payload(1))
        replay.decode()
        replay.process()
        self.assertEqual(replay_client.packets, [])
        self.assertEqual(self.player.UnlockedSkins["Skins"].count(52), 1)
        empty = SimpleNamespace(
            player=self.player,
            client=replay_client,
            notification_action=1,
        )
        self.assertIsNone(LogicDeleteNotificationCommand.process(empty))

    def test_notification_queue_uses_numeric_home_order(self):
        notifications = {
            key: {"Type": 94, "SkinID": 52, "Read": False}
            for key in ("10", "2", "1", "legacy")
        }
        ordered = NotificationFactory._ordered(notifications)
        self.assertEqual(
            [notifications[key] for key in ("1", "2", "10", "legacy")],
            ordered,
        )

    def test_indexed_claim_does_not_guess_between_multiple_rewards(self):
        NotificationFactory.ensure_star_shelly(self.player)
        NotificationFactory.ensure_wizard_barley(self.player)
        with self.assertRaisesRegex(ValueError, "Notificação não encontrada"):
            NotificationFactory.claim_skin(self.player, 8)
        self.assertFalse(self.player.Notifications["0"]["Read"])
        self.assertFalse(self.player.Notifications["1"]["Read"])
        self.assertNotIn(52, self.player.UnlockedSkins["Skins"])
        self.assertNotIn(59, self.player.UnlockedSkins["Skins"])

    def test_invalid_skin_does_not_create_or_persist_notification(self):
        before = dict(self.player.Notifications)
        with self.assertRaises(ValueError):
            NotificationFactory.add_skin(self.player, 999999)
        self.assertEqual(self.player.Notifications, before)
        row = DataBase.loadMembersById(self.player, self.player.low_id)
        self.assertEqual(row[37], before)

    def test_notification_helper_persists_typed_relational_values(self):
        owner = SimpleNamespace(player=self.player)
        self.assertTrue(
            DataBase.sendNotifData(owner, self.player.low_id, 81, "Aviso", 7)
        )
        stored = DataBase.loadMembersById(owner, self.player.low_id)[37]
        notification = stored[str(len(stored) - 1)]
        self.assertEqual(notification["ID"], 81)
        self.assertEqual(notification["Type"], 7)
        self.assertEqual(notification["Text"], "Aviso")
        self.assertFalse(notification["Read"])
        self.assertIsInstance(notification["Time"], float)


if __name__ == "__main__":
    unittest.main()
