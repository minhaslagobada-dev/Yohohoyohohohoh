import copy
import sqlite3
from contextlib import closing
from types import SimpleNamespace
from unittest.mock import patch

from Database.DatabaseManager import DataBase
from Logic.BattleInstances import BattleInstanceService
from Logic.DailyRewards import DailyRewards
from Packets.Messages.Client.Home.GoHomeFromOfflinePractiseMessage import (
    GoHomeFromOfflinePractiseMessage,
)
from Packets.Messages.Server.Home.OwnHomeDataMessage import OwnHomeDataMessage
from tests.test_battle_end import BattleAccountTestCase, CaptureClient, make_battle
from tests.test_own_home_data_wire import OwnHomeDataReader


class FailingClient:
    def sendall(self, data):
        raise ConnectionResetError("closed before home delivery")


def animation_values(payload):
    reader = OwnHomeDataReader(payload)
    for _ in range(2):
        reader.v()
    for _ in range(5):
        reader.v()
    for _ in range(3):
        reader.v()
    reader.references()
    reader.references()
    reader.b()
    values = [reader.v() for _ in range(6)]
    return values[1:4]


class HomeRewardPresentationTests(BattleAccountTestCase):
    def setUp(self):
        super().setUp()
        DailyRewards.sync_player(self.player)

    def set_animations(self, values):
        progression = copy.deepcopy(self.player.progression)
        for key, value in zip(
            ("keyReward", "trophyReward", "starKeyReward"), values
        ):
            progression[key] = value
        self.assertTrue(DataBase.replaceValues(
            SimpleNamespace(player=self.player), {"progression": progression}
        ))
        self.player.progression = progression
        for name, value in zip(
            ("tokensAnim", "trophiesAnim", "bigTokensAnim"), values
        ):
            setattr(self.player, name, value)

    def stored_animations(self):
        loaded = self.reload()
        return [
            loaded.tokensAnim,
            loaded.trophiesAnim,
            loaded.bigTokensAnim,
        ], loaded

    def send_home(self, player=None):
        player = player or self.player
        client = CaptureClient()
        message = GoHomeFromOfflinePractiseMessage(client, player, b"\x00")
        message.decode()
        message.process()
        return client.packets[0][7:]

    def resource_balances(self):
        with closing(sqlite3.connect(self.database_path)) as connection:
            return connection.execute(
                "SELECT battleTokens, brawlBoxes, bigBoxes, gems, gold, "
                "playerExp, trophies FROM players WHERE lowID = ?",
                (self.player.low_id,),
            ).fetchone()

    def test_successful_home_consumes_once_without_changing_resources(self):
        self.player.progression["eventStates"] = {"preserved": {"state": 3}}
        self.set_animations((20, 6, 1))
        before = self.resource_balances()
        first = self.send_home()
        self.assertEqual(animation_values(first), [20, 6, 1])
        self.assertEqual(
            (self.player.tokensAnim, self.player.trophiesAnim, self.player.bigTokensAnim),
            (0, 0, 0),
        )
        self.assertEqual(self.resource_balances(), before)
        self.assertEqual(animation_values(self.send_home()), [0, 0, 0])
        stored, loaded = self.stored_animations()
        self.assertEqual(stored, [0, 0, 0])
        self.assertEqual(
            loaded.progression["eventStates"], {"preserved": {"state": 3}}
        )
        self.assertEqual(animation_values(self.send_home(loaded)), [0, 0, 0])

    def test_encode_and_failed_delivery_do_not_consume_presentation(self):
        self.set_animations((20, 6, 1))
        message = OwnHomeDataMessage(None, self.player)
        message.encode()
        self.assertEqual(animation_values(message.buffer), [20, 6, 1])
        self.assertEqual(self.stored_animations()[0], [20, 6, 1])

        with self.assertRaises(ConnectionResetError):
            OwnHomeDataMessage(FailingClient(), self.player).send()
        self.assertEqual(self.stored_animations()[0], [20, 6, 1])
        self.assertEqual(
            (self.player.tokensAnim, self.player.trophiesAnim, self.player.bigTokensAnim),
            (20, 6, 1),
        )
        self.assertEqual(animation_values(self.send_home()), [20, 6, 1])
        self.assertEqual(self.stored_animations()[0], [0, 0, 0])

    def test_stale_home_cannot_clear_a_newer_battle_presentation(self):
        self.set_animations((20, 6, 1))
        stale = OwnHomeDataMessage(None, self.player)
        stale.encode()
        self.set_animations((40, 12, 0))
        client = CaptureClient()
        stale._send_payload(client, None, stale.buffer)
        self.assertEqual(self.stored_animations()[0], [40, 12, 0])
        self.assertEqual(
            (self.player.tokensAnim, self.player.trophiesAnim, self.player.bigTokensAnim),
            (40, 12, 0),
        )
        self.assertEqual(animation_values(self.send_home()), [40, 12, 0])
        self.assertEqual(self.stored_animations()[0], [0, 0, 0])

    def test_stale_session_adopts_the_persistent_presentation_state(self):
        self.set_animations((20, 6, 1))
        stale = self.reload()
        self.send_home()
        self.assertEqual(animation_values(self.send_home(stale)), [20, 6, 1])
        self.assertEqual(
            (stale.tokensAnim, stale.trophiesAnim, stale.bigTokensAnim),
            (0, 0, 0),
        )
        self.assertEqual(animation_values(self.send_home(stale)), [0, 0, 0])

        self.set_animations((20, 6, 1))
        stale = self.reload()
        self.set_animations((40, 12, 0))
        self.assertEqual(animation_values(self.send_home(stale)), [20, 6, 1])
        self.assertEqual(
            (stale.tokensAnim, stale.trophiesAnim, stale.bigTokensAnim),
            (40, 12, 0),
        )
        self.assertEqual(self.stored_animations()[0], [40, 12, 0])
        self.assertEqual(animation_values(self.send_home(stale)), [40, 12, 0])
        self.assertEqual(self.stored_animations()[0], [0, 0, 0])

    def test_failed_presentation_write_is_rolled_back_and_can_be_retried(self):
        self.set_animations((20, 6, 1))
        message = OwnHomeDataMessage(None, self.player)
        message.encode()
        client = CaptureClient()
        with patch.object(
            DataBase, "_write_state", side_effect=sqlite3.OperationalError("forced")
        ):
            with self.assertRaises(sqlite3.OperationalError):
                message._send_payload(client, None, message.buffer)
        self.assertEqual(self.stored_animations()[0], [20, 6, 1])
        self.assertEqual(
            (self.player.tokensAnim, self.player.trophiesAnim, self.player.bigTokensAnim),
            (20, 6, 1),
        )
        self.assertEqual(animation_values(self.send_home()), [20, 6, 1])
        self.assertEqual(self.stored_animations()[0], [0, 0, 0])

    def test_negative_trophy_presentation_is_consumed_with_existing_wire_rule(self):
        self.set_animations((15, -2, 0))
        payload = self.send_home()
        self.assertEqual(animation_values(payload), [15, 0, 0])
        self.assertEqual(self.stored_animations()[0], [0, 0, 0])

    def test_replay_does_not_restore_a_consumed_presentation(self):
        payload = make_battle(map_id=0)
        _, first_client, _ = self.process(payload)
        self.assertEqual(
            (self.player.tokensAnim, self.player.trophiesAnim, self.player.bigTokensAnim),
            (20, 6, 1),
        )
        self.assertEqual(animation_values(self.send_home()), [20, 6, 1])
        self.assertEqual(self.stored_animations()[0], [0, 0, 0])

        _, replay_client, _ = self.process(payload)
        self.assertEqual(replay_client.packets[0], first_client.packets[0])
        self.assertEqual(
            (self.player.tokensAnim, self.player.trophiesAnim, self.player.bigTokensAnim),
            (0, 0, 0),
        )
        self.assertEqual(animation_values(self.send_home()), [0, 0, 0])

        BattleInstanceService.begin(self.player)
        _, new_client, _ = self.process(payload)
        self.assertNotEqual(new_client.packets[0], first_client.packets[0])
        self.assertEqual(animation_values(self.send_home()), [20, 6, 0])
        self.assertEqual(self.stored_animations()[0], [0, 0, 0])
        self.assertEqual(self.player.big_boxes, 1)
