import os
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

PROJECT_ROOT = Path(__file__).resolve().parents[1]
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from Packets.LogicMessageFactory import packets
from Packets.Messages.Client.Home.PlayerStatusMessage import PlayerStatusMessage


NATIVE_STATUS_PAYLOADS = {
    -1: b"\x7f",
    1: b"\x01",
    2: b"\x02",
    3: b"\x03",
    4: b"\x04",
    5: b"\x05",
    7: b"\x07",
    8: b"\x08",
    10: b"\x0a",
    11: b"\x0b",
}


class PlayerStatusTests(unittest.TestCase):
    def decode(self, payload):
        message = PlayerStatusMessage(None, SimpleNamespace(), payload)
        message.decode()
        return message

    def test_factory_uses_player_status_for_14366(self):
        self.assertIs(packets[14366], PlayerStatusMessage)

    def test_r101_native_v13_statuses_decode_exactly(self):
        for expected, payload in NATIVE_STATUS_PAYLOADS.items():
            with self.subTest(status=expected, payload=payload.hex()):
                message = self.decode(payload)
                self.assertEqual(message.status, expected)
                self.assertEqual(message.read(), b"")

    def test_states_not_emitted_by_r101_are_rejected(self):
        payloads = {
            0: b"\x00",
            6: b"\x06",
            9: b"\x09",
            12: b"\x0c",
            -2: b"\x7e",
        }
        for status, payload in payloads.items():
            with self.subTest(status=status, payload=payload.hex()):
                with self.assertRaisesRegex(ValueError, "Estado de presença inválido"):
                    self.decode(payload)

    def test_truncated_native_vint_is_rejected(self):
        for payload in (b"", b"\x81"):
            with self.subTest(payload=payload.hex()):
                with self.assertRaises(ValueError):
                    self.decode(payload)

    def test_residual_data_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "dados residuais"):
            self.decode(b"\x01\x00")


if __name__ == "__main__":
    unittest.main()
