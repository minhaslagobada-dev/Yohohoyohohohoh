import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from Database.DatabaseManager import DataBase
from Logic.BattleEnd import BattleEndError, BattleEndService
from Logic.BattleResultAdapter import apply_battle_result_rewards
from Logic.Player import Players
from Files.CsvLogic.Skins import Skins
from Packets.Messages.Client.Battle.AskForBattleEndMessage import AskForBattleEndMessage
from Utils.Reader import BSMessageReader
from Utils.Writer import Writer


class CaptureClient:
    def __init__(self):
        self.packets = []

    def sendall(self, data):
        self.packets.append(bytes(data))

    def payload(self, index=-1):
        packet = self.packets[index]
        self.message_id = int.from_bytes(packet[:2], "big")
        self.message_length = int.from_bytes(packet[2:5], "big")
        if self.message_length != len(packet) - 7:
            raise AssertionError("Invalid captured packet length")
        return packet[7:]


class NativeResponseReader:
    def __init__(self, payload):
        self.payload = payload
        self.offset = 0
        self.bit_index = 0
        self.bit_buffer = 0

    def byte(self):
        if self.offset >= len(self.payload):
            raise AssertionError("Unexpected end of native response")
        value = self.payload[self.offset]
        self.offset += 1
        return value

    def vint(self):
        self.bit_index = 0
        first = self.byte()
        negative = bool(first & 0x40)
        result = first & 0x3F
        if not first & 0x80:
            if negative:
                result |= -1 << 6
            return self.signed32(result)
        for group in range(1, 4):
            byte = self.byte()
            result |= (byte & 0x7F) << (6 + (group - 1) * 7)
            if not byte & 0x80:
                if negative:
                    result |= -1 << (6 + group * 7)
                return self.signed32(result)
        result |= self.byte() << 27
        if negative:
            result |= 0x80000000
        return self.signed32(result)

    @staticmethod
    def signed32(value):
        value &= 0xFFFFFFFF
        return value - 0x100000000 if value & 0x80000000 else value

    def boolean(self):
        if self.bit_index == 0:
            self.bit_buffer = self.byte()
        value = bool(self.bit_buffer & (1 << self.bit_index))
        self.bit_index = (self.bit_index + 1) & 7
        return value

    def int32(self):
        self.bit_index = 0
        return int.from_bytes(self.take(4), "big")

    def string(self):
        self.bit_index = 0
        length = self.int32()
        if length == 0xFFFFFFFF:
            return ""
        return self.take(length).decode("utf-8")

    def dataref(self):
        class_id = self.vint()
        return class_id, self.vint() if class_id else 0

    def take(self, length):
        end = self.offset + length
        if end > len(self.payload):
            raise AssertionError("Unexpected end of native response")
        value = self.payload[self.offset:end]
        self.offset = end
        return value

    def ensure_end(self):
        if self.offset != len(self.payload):
            raise AssertionError(f"Native response has {len(self.payload) - self.offset} trailing bytes")


def read_native_result(payload):
    reader = NativeResponseReader(payload)
    result = {
        "header": [reader.vint() for _ in range(7)],
        "flags": [reader.boolean() for _ in range(6)],
    }
    participants = []
    for _ in range(reader.vint()):
        participant = {
            "name": reader.string(),
            "flags": [reader.boolean() for _ in range(3)],
            "brawler": reader.dataref(),
            "skin": reader.dataref(),
            "trophies": reader.vint(),
            "power": reader.vint(),
            "hasAccount": reader.boolean(),
        }
        participant["account"] = (reader.int32(), reader.int32()) if participant["hasAccount"] else None
        participants.append(participant)
    result["participants"] = participants
    result["experience"] = [(reader.vint(), reader.vint()) for _ in range(reader.vint())]
    result["references"] = [reader.dataref() for _ in range(reader.vint())]
    result["rewardData"] = [
        (reader.vint(), reader.vint(), reader.vint())
        for _ in range(reader.vint())
    ]
    result["profileIcon"] = reader.dataref()
    result["optional"] = reader.boolean()
    result["remaining"] = len(payload) - reader.offset
    reader.ensure_end()
    return result


def make_battle(map_id=0, count=6, rank=0, result=0, submitted=None, names=None, first_brawler=None, first_skin=None, map_slot=0, local_count=1, local_index=0):
    if submitted is None:
        submitted = local_index % 2 if local_count == 1 else 0
    writer = Writer(None).enable_native_v13()
    for value in (result, submitted, rank, map_id, map_slot, count):
        writer.writeVint(value)
    for index in range(count):
        brawler = first_brawler if index == 0 and first_brawler is not None else index % 20
        skin = first_skin if index == 0 and first_skin is not None else (29 if index == 1 else 0)
        writer.writeScId(16, brawler)
        if index == 0 or skin:
            writer.writeScId(29, skin)
        else:
            writer.writeVint(0)
        writer.writeVint(index % 2)
        is_local = index == local_index if local_count == 1 else index < local_count
        writer.writeBoolean(is_local)
        writer.writeString(names[index] if names else ("Local" if index == 0 else f"Bot {index}"))
    return writer.buffer


NATIVE_SOLO_VICTORY = bytes.fromhex(
    "0100010d000a10001d000001000000054c6f63616c10011d1d01000000000542"
    "6f742031100200020000000005426f742032100300030000000005426f742033"
    "100400040000000005426f742034100500050000000005426f74203510060006"
    "0000000005426f742036100700070000000005426f7420371008000800000000"
    "05426f742038100900090000000005426f742039"
)
NATIVE_SOLO_DEFEAT = bytes.fromhex(
    "0700070d000a10001d000001000000054c6f63616c10011d1d01000000000542"
    "6f742031100200020000000005426f742032100300030000000005426f742033"
    "100400040000000005426f742034100500050000000005426f74203510060006"
    "0000000005426f742036100700070000000005426f7420371008000800000000"
    "05426f742038100900090000000005426f742039"
)
NATIVE_DUO_VICTORY = bytes.fromhex(
    "0100011c000a10001d000001000000054c6f63616c10011d1d00000000000542"
    "6f742031100200010000000005426f742032100300010000000005426f742033"
    "100400020000000005426f742034100500020000000005426f74203510060003"
    "0000000005426f742036100700030000000005426f7420371008000400000000"
    "05426f742038100900040000000005426f742039"
)

NATIVE_SOLO_126 = bytes.fromhex(
    "0100010d000a10001d000001000000054c6f63616c10011d1d01000000000010"
    "0200020000000000100300030000000001421004000400000000014210050005"
    "000000000142100600060000000005426f742036100700070000000005426f74"
    "2037100800080000000005426f742038100900090000000005426f742039"
)


class BattleAccountTestCase(unittest.TestCase):
    def setUp(self):
        self.temp_directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp_directory.cleanup)
        self.database_path = str(Path(self.temp_directory.name) / "players.db")
        path_patch = patch.object(DataBase, "_database_path", lambda: self.database_path)
        path_patch.start()
        self.addCleanup(path_patch.stop)
        self.player = self.make_account(1, "battle-token")

    def make_account(self, low_id, token):
        player = Players(SimpleNamespace())
        player.low_id = low_id
        player.high_id = 0
        player.token = token
        player.name = "Local"
        player.tutorial = 2
        player.player_experience = 0
        player.battle_tokens = 200
        player.tokensdoubler = 0
        player.brawl_boxes = 0
        player.big_boxes = 0
        player.trophies = 0
        player.highest_trophies = 0
        player.brawlers_trophies = {"0": 0}
        player.brawlers_trophies_in_rank = {"0": 0}
        owner = SimpleNamespace(player=player)
        DataBase.createAccount(owner)
        DataBase.replaceValues(owner, {
            "playerExp": 0,
            "battleTokens": 200,
            "tokensdoubler": 0,
            "brawlBoxes": 0,
            "bigBoxes": 0,
            "trophies": 0,
            "highest_trophies": 0,
            "brawlersTrophies": {"0": 0},
            "brawlersTrophiesForRank": {"0": 0},
        })
        return player

    def reload(self, player=None):
        source = player or self.player
        loaded = Players(SimpleNamespace())
        loaded.token = source.token
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=loaded)))
        return loaded

    def process(self, payload, player=None):
        player = player or self.player
        client = CaptureClient()
        message = AskForBattleEndMessage(client, player, payload)
        message.decode()
        result = message.process()
        return result, client, message


class BattleEndProtocolTests(BattleAccountTestCase):
    def test_v13_header_reads_map_id_before_map_slot(self):
        message = AskForBattleEndMessage(
            None, self.player, make_battle(map_id=7, map_slot=3)
        )
        message.decode()
        self.assertEqual(message.battle.map_slot, 3)
        self.assertEqual(message.battle.map_id, 7)
        self.assertEqual(message.read(), b"")

    def test_home_slot_two_showdown_rank_nine_reaches_battle_result(self):
        from datetime import datetime

        from Logic.EventRotation import EventRotation
        from Logic.EventSlots import EventSlots
        from Packets.Messages.Server.Home.OwnHomeDataMessage import OwnHomeDataMessage
        from tests.test_own_home_data_wire import read_home_commodities

        events = EventRotation.events(datetime(2026, 11, 5, 12, 0, 0))
        self.assertEqual(
            (events[1]["slot"], events[1]["map_id"], events[1]["game_mode"]),
            (2, 13, "BattleRoyale"),
        )
        home = OwnHomeDataMessage(None, self.player)
        with patch.object(EventRotation, "snapshot", return_value=events), \
             patch.object(EventSlots, "Timer", lambda self: 49020):
            home.encode()
        home_reader, _ = read_home_commodities(home.buffer)
        event = next(values for values in home_reader.events if values[1] == 2)
        client_map_id = event[0]
        self.assertEqual((client_map_id, event[6]), (13, 13))

        result, client, message = self.process(make_battle(
            map_id=client_map_id,
            map_slot=2,
            count=10,
            result=9,
            rank=9,
            submitted=0,
        ))
        self.assertEqual(result, {
            "gameMode": 2,
            "mapID": 13,
            "participants": 10,
            "battleID": result["battleID"],
        })
        self.assertEqual(message.battle.location_game_mode, "BattleRoyale")
        self.assertEqual((message.battle.battle_result, message.battle.rank), (9, 9))
        response = BSMessageReader(client.payload()).enable_native_v13()
        self.assertEqual(client.message_id, 23456)
        self.assertEqual([response.read_Vint() for _ in range(2)], [2, 9])

    def test_native_solo_rank_seven_packet_is_accepted_once(self):
        self.assertEqual(len(NATIVE_SOLO_DEFEAT), 148)
        result, client, message = self.process(NATIVE_SOLO_DEFEAT)
        self.assertEqual(result["gameMode"], 2)
        self.assertEqual(result["participants"], 10)
        self.assertEqual(message.battle.battle_result, 7)
        self.assertEqual(message.battle.rank, 7)
        response = BSMessageReader(client.payload()).enable_native_v13()
        self.assertEqual(client.message_id, 23456)
        self.assertEqual([response.read_Vint() for _ in range(2)], [2, 7])
        self.assertEqual(
            (self.player.trophies, self.player.brawl_boxes, self.player.big_boxes),
            (3, 16, 0),
        )
        self.assertEqual(self.player.solo_wins, 0)

        replay_result, replay_client, _ = self.process(NATIVE_SOLO_DEFEAT)
        self.assertEqual(replay_result["battleID"], result["battleID"])
        self.assertEqual(replay_client.packets[0], client.packets[0])
        self.assertEqual(
            (self.player.trophies, self.player.brawl_boxes, self.player.big_boxes),
            (3, 16, 0),
        )

    def test_apk_length_126_solo_packet_decodes_and_returns_native_result(self):
        self.assertEqual(len(NATIVE_SOLO_126), 126)
        result, client, message = self.process(NATIVE_SOLO_126)
        self.assertEqual(result["gameMode"], 2)
        self.assertEqual(result["mapID"], 13)
        self.assertEqual(message.battle.map_slot, 0)
        self.assertEqual(message.battle.submitted_result, 0)
        self.assertEqual(self.player.result, 0)
        response = read_native_result(client.payload())
        self.assertEqual(client.message_id, 23456)
        self.assertEqual(response["header"][:4], [2, 1, 0, 8])
        self.assertEqual(len(response["participants"]), 10)
        self.assertEqual(response["remaining"], 0)
        self.assertEqual(
            (self.player.trophies, self.player.brawl_boxes, self.player.big_boxes),
            (8, 0, 1),
        )

    def test_native_solo_and_duo_victories_use_rank_not_result_as_position(self):
        cases = (
            (NATIVE_SOLO_VICTORY, 2, 8, 10),
            (NATIVE_DUO_VICTORY, 5, 7, 20),
        )
        for payload, mode, trophies, low_id in cases:
            with self.subTest(mode=mode):
                player = self.make_account(low_id, f"native-victory-{mode}")
                result, client, message = self.process(payload, player)
                self.assertEqual(result["gameMode"], mode)
                self.assertEqual(message.battle.battle_result, 1)
                self.assertEqual(message.battle.rank, 1)
                response = BSMessageReader(client.payload()).enable_native_v13()
                self.assertEqual(client.message_id, 23456)
                self.assertEqual([response.read_Vint() for _ in range(2)], [mode, 1])
                self.assertEqual(
                    (player.trophies, player.brawl_boxes, player.big_boxes),
                    (trophies, 0, 1),
                )
                self.assertEqual(player.solo_wins if mode == 2 else player.duo_wins, 1)

    def test_every_result_variant_consumes_the_extracted_native_layout(self):
        cases = (
            (0, 6, 0), (1, 6, 0), (2, 10, 1), (3, 6, 0),
            (4, 6, 0), (5, 10, 1), (6, 3, 0),
        )
        for mode, count, rank in cases:
            with self.subTest(mode=mode):
                player = self.make_account(100 + mode, f"native-result-{mode}")
                player.players = count
                player.rank = rank
                player.battle_result = 0
                player.result = 16
                player.battle_end = None
                player.battle_end_id = None
                client = CaptureClient()
                message = AskForBattleEndMessage.RESULT_MESSAGES[mode](client, player)
                message.send()
                result = read_native_result(client.payload())
                self.assertEqual(client.message_id, 23456)
                self.assertEqual(result["header"][0], mode)
                self.assertEqual(result["header"][1], rank)
                self.assertEqual(len(result["participants"]), count)
                self.assertEqual(result["participants"][0]["account"], (0, 100 + mode))
                self.assertEqual(result["references"], [])
                self.assertEqual(len(result["rewardData"]), 2)
                self.assertEqual(result["profileIcon"], (28, 0))
                self.assertFalse(result["optional"])
                self.assertEqual(result["remaining"], 0)

    def test_decoder_preserves_participants_and_routes_all_v13_modes(self):
        cases = (
            (0, 6, 0, "BountyHunter"),
            (13, 10, 2, "BattleRoyale"),
            (28, 10, 5, "BattleRoyaleTeam"),
            (27, 6, 3, "Survival"),
            (21, 6, 4, "BossFight"),
            (57, 3, 6, "Raid"),
        )
        for map_id, count, mode, location_mode in cases:
            with self.subTest(mode=mode):
                payload = make_battle(
                    map_id, count, result=1 if mode in (2, 5) else 0,
                    rank=1 if mode in (2, 5) else 0,
                )
                message = AskForBattleEndMessage(None, self.player, payload)
                message.decode()
                battle = message.battle
                self.assertEqual(battle.game_mode, mode)
                self.assertEqual(battle.location_game_mode, location_mode)
                self.assertEqual(len(battle.participants), count)
                self.assertEqual(battle.participants[1].name, "Bot 1")
                self.assertEqual(battle.participants[1].skin_id, 29)
                self.assertEqual(message.read(), b"")

    def test_truncated_trailing_and_wrong_count_payloads_are_rejected(self):
        payload = make_battle()
        for invalid in (
            payload[:-1],
            payload + b"\x00",
            make_battle(count=3),
            make_battle(map_id=27, count=3),
            make_battle(result=3),
            make_battle(map_id=13, count=10, rank=7, result=11),
            make_battle(map_id=13, count=10, rank=7, result=0),
            make_battle(map_id=28, count=10, rank=4, result=6),
            make_battle(map_id=28, count=10, rank=4, result=0),
        ):
            with self.subTest(size=len(invalid)):
                message = AskForBattleEndMessage(None, self.player, invalid)
                with self.assertRaises(BattleEndError):
                    message.decode()
        for payload in (
            make_battle(first_brawler=999),
            make_battle(first_skin=99999),
        ):
            with self.subTest(size=len(payload)):
                with self.assertRaises(BattleEndError):
                    AskForBattleEndMessage(None, self.player, payload).decode()
        with self.assertRaises(BattleEndError):
            AskForBattleEndMessage(None, self.player, make_battle(map_id=999)).decode()
        with self.assertRaises(BattleEndError):
            AskForBattleEndMessage(None, self.player, make_battle(map_id=13, count=10, rank=11)).decode()

    def test_local_participant_is_not_fabricated(self):
        for local_count in (0, 2):
            with self.subTest(local_count=local_count):
                with self.assertRaisesRegex(BattleEndError, "participante local"):
                    AskForBattleEndMessage(
                        None,
                        self.player,
                        make_battle(local_count=local_count),
                    ).decode()

    def test_invalid_result_error_contains_the_decoded_header(self):
        with self.assertRaises(BattleEndError) as caught:
            AskForBattleEndMessage(
                None, self.player, make_battle(map_id=7, map_slot=1, result=7)
            ).decode()
        detail = str(caught.exception)
        for value in ("mapa=7", "slot=1", "modo=CoinRush", "resultado=7"):
            self.assertIn(value, detail)

    def test_header_fields_match_native_battle_state(self):
        valid = AskForBattleEndMessage(
            None, self.player, make_battle(local_index=1)
        )
        valid.decode()
        self.assertEqual(valid.battle.local_index, 1)
        self.assertEqual(valid.battle.local.team, 1)
        self.assertEqual(valid.battle.submitted_result, 1)

        cases = (
            (make_battle(map_id=31), "desabilitado"),
            (make_battle(rank=1), "fora de Showdown"),
            (make_battle(submitted=1), "Equipe enviada"),
            (make_battle(map_id=13, count=10, result=1, rank=7), "Ranks solo"),
            (make_battle(map_id=28, count=10, result=1, rank=4), "Ranks duo"),
            (make_battle(map_id=13, count=10, result=1, rank=1, submitted=1), "Equipe enviada"),
        )
        for payload, detail in cases:
            with self.subTest(detail=detail):
                with self.assertRaisesRegex(BattleEndError, detail):
                    AskForBattleEndMessage(None, self.player, payload).decode()

    def test_process_replay_and_reload_do_not_duplicate_rewards(self):
        payload = make_battle()
        result, client, _ = self.process(payload)
        self.assertEqual(result["gameMode"], 0)
        client.payload()
        self.assertEqual(client.message_id, 23456)
        first_packet = client.packets[0]
        self.assertEqual((self.player.trophies, self.player.brawl_boxes, self.player.big_boxes), (6, 20, 1))
        self.assertEqual(self.player.battle_tokens, 180)
        second_result, second_client, _ = self.process(payload)
        self.assertEqual(second_result["battleID"], result["battleID"])
        self.assertEqual(second_client.packets[0], first_packet)
        self.assertEqual((self.player.trophies, self.player.brawl_boxes, self.player.big_boxes), (6, 20, 1))

        loaded = self.reload()
        self.assertEqual((loaded.trophies, loaded.brawl_boxes, loaded.big_boxes), (6, 20, 1))
        _, reload_client, _ = self.process(payload, loaded)
        self.assertEqual(reload_client.packets[0], first_packet)
        self.assertEqual((loaded.trophies, loaded.brawl_boxes, loaded.big_boxes), (6, 20, 1))
        reloaded_again = self.reload(loaded)
        self.assertEqual((reloaded_again.trophies, reloaded_again.brawl_boxes, reloaded_again.big_boxes), (6, 20, 1))

    def test_different_battle_inside_interval_is_answered_without_duplicate_replay(self):
        first_result, _, _ = self.process(make_battle(map_id=0))
        second_result, client, _ = self.process(make_battle(map_id=1))
        self.assertNotEqual(second_result["battleID"], first_result["battleID"])
        client.payload()
        self.assertEqual(client.message_id, 23456)
        self.assertEqual(len(client.packets), 1)
        self.assertEqual(
            (self.player.trophies, self.player.brawl_boxes, self.player.big_boxes),
            (12, 40, 2),
        )
        second_packet = client.packets[0]
        replay_result, replay_client, _ = self.process(make_battle(map_id=1))
        self.assertEqual(replay_result["battleID"], second_result["battleID"])
        self.assertEqual(replay_client.packets, [second_packet])
        self.assertEqual(
            (self.player.trophies, self.player.brawl_boxes, self.player.big_boxes),
            (12, 40, 2),
        )

    def test_result_payload_resolves_dynamic_brawler_skins_and_has_no_trailing_bytes(self):
        payload = make_battle(first_brawler=23, first_skin=0)
        _, client, _ = self.process(payload)
        reader = BSMessageReader(client.payload()).enable_native_v13()
        self.assertEqual([reader.read_Vint() for _ in range(7)], [0, 0, 20, 6, 0, 0, 0])
        self.assertEqual(
            [reader.read_boolean() for _ in range(6)],
            [True, False, False, False, True, False],
        )
        self.assertEqual(reader.read_Vint(), 6)
        names = []
        for index in range(6):
            names.append(reader.read_string())
            is_player = reader.read_boolean()
            self.assertEqual(is_player, index == 0)
            self.assertEqual(reader.read_boolean(), bool(index % 2))
            self.assertEqual(reader.read_boolean(), index == 0)
            brawler_id = 23 if index == 0 else index % 20
            self.assertEqual(
                (reader.read_Vint(), reader.read_Vint()), (16, brawler_id)
            )
            self.assertEqual(
                (reader.read_Vint(), reader.read_Vint()),
                (29, Skins.get_default_skin(brawler_id)),
            )
            self.assertEqual(reader.read_Vint(), 0)
            self.assertEqual(reader.read_Vint(), 10 if index else 1)
            self.assertEqual(reader.read_boolean(), is_player)
            if is_player:
                self.assertEqual(reader.read_int(), 0)
                self.assertEqual(reader.read_int(), 1)
        self.assertEqual(names, ["Local"] + [f"Bot {index}" for index in range(1, 6)])
        self.assertEqual(reader.read_Vint(), 2)
        self.assertEqual([reader.read_Vint() for _ in range(4)], [0, 18, 8, 10])
        self.assertEqual(reader.read_Vint(), 0)
        self.assertEqual(reader.read_Vint(), 2)
        self.assertEqual([reader.read_Vint() for _ in range(6)], [1, 0, 0, 5, 0, 0])
        self.assertEqual((reader.read_Vint(), reader.read_Vint()), (28, 0))
        self.assertFalse(reader.read_boolean())
        self.assertEqual(reader.read(), b"")

    def test_real_game_and_tutorial_flags_follow_the_tutorial_state(self):
        for state in (0, 1, 2):
            with self.subTest(tutorial=state):
                player = self.make_account(100 + state, f"tutorial-{state}")
                player.tutorial = state
                _, client, _ = self.process(make_battle(), player)
                response = read_native_result(client.payload())
                self.assertEqual(response["flags"][3], state == 1)
                self.assertEqual(response["flags"][4], state == 2)
                self.assertEqual(response["flags"][5], state == 1)

    def test_solo_duo_and_special_modes_use_their_own_reward_rules(self):
        cases = (
            (13, 10, 2, 8, 0),
            (28, 10, 5, 7, 0),
            (27, 6, 3, 0, 0),
            (21, 6, 4, 0, 0),
            (57, 3, 6, 0, 0),
        )
        for index, (map_id, count, mode, trophies, tokens) in enumerate(cases, 10):
            with self.subTest(mode=mode):
                player = self.make_account(index, f"mode-{mode}")
                result, client, _ = self.process(
                    make_battle(
                        map_id, count, result=1 if mode in (2, 5) else 0,
                        rank=1 if mode in (2, 5) else 0,
                    ),
                    player,
                )
                self.assertEqual(result["gameMode"], mode)
                reader = BSMessageReader(client.payload()).enable_native_v13()
                self.assertEqual(reader.read_Vint(), mode)
                self.assertEqual(reader.read_Vint(), 1 if mode in (2, 5) else 0)
                self.assertEqual(reader.read_Vint(), tokens)
                self.assertEqual(reader.read_Vint(), trophies)
                self.assertEqual((player.trophies, player.brawl_boxes), (trophies, tokens))
                self.assertEqual(player.big_boxes, 1)
                loaded = self.reload(player)
                self.assertEqual((loaded.trophies, loaded.brawl_boxes, loaded.big_boxes), (trophies, tokens, 1))

    def test_token_cap_and_signed_trophy_loss_are_applied_correctly(self):
        self.player.battle_tokens = 5
        self.player.tokensdoubler = 100
        DataBase.replaceValues(SimpleNamespace(player=self.player), {
            "battleTokens": 5,
            "tokensdoubler": 100,
        })
        rewards = apply_battle_result_rewards(self.player, 0, "token-cap")
        self.assertEqual((rewards.token, rewards.doubledtokens, rewards.totaltokens), (5, 0, 5))
        self.assertEqual((self.player.battle_tokens, self.player.tokensdoubler, self.player.brawl_boxes), (0, 100, 5))

        player = self.make_account(30, "loss-token")
        player.battle_result = 1
        player.brawlers_trophies = {"0": 100}
        player.brawlers_trophies_in_rank = {"0": 100}
        player.trophies = 100
        player.highest_trophies = 100
        DataBase.replaceValues(SimpleNamespace(player=player), {
            "brawlersTrophies": {"0": 100},
            "brawlersTrophiesForRank": {"0": 100},
            "trophies": 100,
            "highest_trophies": 100,
        })
        _, client, _ = self.process(make_battle(result=1), player)
        reader = BSMessageReader(client.payload()).enable_native_v13()
        reader.read_Vint()
        self.assertEqual(reader.read_Vint(), 1)
        reader.read_Vint()
        self.assertEqual(reader.read_Vint(), -2)
        self.assertEqual(player.brawlers_trophies["0"], 98)
        self.assertEqual(player.trophies, 98)


if __name__ == "__main__":
    unittest.main()
