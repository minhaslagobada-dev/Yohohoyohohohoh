import http.client
import json
import logging
import time
import urllib.error
import urllib.request
from urllib.parse import urlsplit

from SCIDClient.GameSessions import GAME_SESSIONS
from SCIDClient.Integration import (
    API_PREFIX,
    account_from_data,
    key_bytes,
    new_nonce,
    request_signature,
    response_signature,
    signatures_match,
)
from SCIDClient.Models import LocalGameAccounts, SCIDError


LOGGER = logging.getLogger(__name__)
MAX_RESPONSE_SIZE = 1024 * 1024


class RemoteStore:
    def __init__(self, service, settings):
        self.service = service
        database_path = settings.get("Database", {}).get(
            "Path", "Database/players.sqlite"
        )
        self.local_games = LocalGameAccounts(database_path)

    @staticmethod
    def _account(result):
        try:
            return account_from_data(result.get("account"))
        except (KeyError, TypeError, ValueError) as error:
            raise SCIDError("scid_invalid_response") from error

    def by_id(self, account_id):
        result = self.service._request(
            "account-by-id", {"account_id": int(account_id)}
        )
        return self._account(result)

    def by_game(self, low_id):
        result = self.service._request(
            "account-by-game", {"low_id": int(low_id)}
        )
        return self._account(result)

    def game_account(self, low_id):
        return self.local_games.game_account(low_id)

    def game_by_token(self, token, low_id=None):
        return self.local_games.game_by_token(token, low_id=low_id)


class RemoteTokenManager:
    def __init__(self, service):
        self.service = service

    def issue(self, account):
        result = self.service._request("issue", {"account_id": int(account.id)})
        token = result.get("token")
        if not isinstance(token, str) or not token:
            raise SCIDError("scid_invalid_response")
        return token


class RemoteSCIDClient:
    is_remote = True

    def __init__(self, settings, game_sessions=GAME_SESSIONS, clock=time.time):
        self.settings = settings
        self.scid_settings = settings.get("SCID", {})
        self.clock = clock
        self.game_sessions = game_sessions
        self.base_url = self._base_url(self.scid_settings.get("RemoteUrl"))
        self.api_key = str(self.scid_settings.get("RemoteApiKey", "") or "")
        key_bytes(self.api_key)
        self.timeout = float(self.scid_settings.get("RemoteTimeoutSeconds", 10))
        if not 1 <= self.timeout <= 60:
            raise ValueError("SCID.RemoteTimeoutSeconds deve estar entre 1 e 60")
        self.store = RemoteStore(self, settings)
        self.tokens = RemoteTokenManager(self)

    @staticmethod
    def _base_url(value):
        base = str(value or "").strip().rstrip("/")
        parsed = urlsplit(base)
        if (parsed.scheme not in {"http", "https"} or not parsed.hostname
                or parsed.username or parsed.password or parsed.query or parsed.fragment):
            raise ValueError("SCID.RemoteUrl deve ser uma URL HTTP ou HTTPS válida")
        return base

    def _request(self, action, payload):
        path = f"{API_PREFIX}/{action}"
        body = json.dumps(
            payload, separators=(",", ":"), ensure_ascii=False
        ).encode("utf-8")
        timestamp = int(self.clock())
        nonce = new_nonce()
        signature = request_signature(
            self.api_key, "POST", path, timestamp, nonce, body
        )
        request = urllib.request.Request(
            self.base_url + path,
            data=body,
            headers={
                "Content-Type": "application/json",
                "X-SCID-Timestamp": str(timestamp),
                "X-SCID-Nonce": nonce,
                "X-SCID-Signature": signature,
                "User-Agent": "NostBrawl-R120-SCID-Integration",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                raw = response.read(MAX_RESPONSE_SIZE + 1)
                response_nonce = response.headers.get("X-SCID-Nonce", "")
                response_signature_value = response.headers.get(
                    "X-SCID-Signature", ""
                )
        except urllib.error.HTTPError as error:
            LOGGER.warning(
                "Remote SCID request %s rejected with HTTP %s", action, error.code
            )
            raise SCIDError("scid_integration_rejected") from error
        except (urllib.error.URLError, TimeoutError, OSError,
                http.client.HTTPException) as error:
            LOGGER.warning(
                "Remote SCID request %s failed: %s", action, type(error).__name__
            )
            raise SCIDError("scid_unavailable") from error

        if len(raw) > MAX_RESPONSE_SIZE:
            raise SCIDError("scid_invalid_response")
        expected_response = response_signature(self.api_key, nonce, raw)
        if (not signatures_match(nonce, response_nonce)
                or not signatures_match(expected_response, response_signature_value)):
            LOGGER.warning("Remote SCID response %s has invalid authentication", action)
            raise SCIDError("scid_integration_rejected")
        try:
            result = json.loads(raw.decode("utf-8"))
        except (UnicodeError, ValueError) as error:
            raise SCIDError("scid_invalid_response") from error
        if not isinstance(result, dict) or not isinstance(result.get("ok"), bool):
            raise SCIDError("scid_invalid_response")
        if not result["ok"]:
            error_code = result.get("error")
            if not isinstance(error_code, str) or not error_code:
                raise SCIDError("scid_invalid_response")
            raise SCIDError(error_code)
        return result

    def authenticate(self, token):
        try:
            result = self._request("authenticate", {"token": token or ""})
        except SCIDError as error:
            if error.code == "invalid_token":
                return None
            raise
        return RemoteStore._account(result)

    def link_game(self, account, low_id):
        result = self._request(
            "link", {"account_id": int(account.id), "low_id": int(low_id)}
        )
        changed = result.get("changed")
        if not isinstance(changed, bool):
            raise SCIDError("scid_invalid_response")
        RemoteStore._account(result)
        if changed:
            self.game_sessions.notify_registration(low_id)
        return changed

    def token_for_game(self, low_id):
        result = self._request("token-for-game", {"low_id": int(low_id)})
        account = RemoteStore._account(result)
        token = result.get("token")
        if account is None:
            if token is not None:
                raise SCIDError("scid_invalid_response")
            return None, None
        if not isinstance(token, str) or not token:
            raise SCIDError("scid_invalid_response")
        return account, token
