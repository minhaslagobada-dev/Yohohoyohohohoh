import threading


_lock = threading.Lock()
_service = None


def get_service():
    with _lock:
        return _service


def set_service(service):
    global _service
    with _lock:
        _service = service
