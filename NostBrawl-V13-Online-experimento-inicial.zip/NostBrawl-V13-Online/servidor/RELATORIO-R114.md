# NostBrawl R114 — auditoria e correções

## Escopo e resultado

Esta revisão parte da R113 e preserva os pacotes e as funcionalidades anteriores. Foram corrigidos a economia diária de tokens, a concessão persistente de fichas estrelas e inconsistências de apresentação da home. O fluxo BattleEnd → 23456 → 14109/24101 → 14366 foi exercitado em partidas consecutivas, relogin e reinício de processo.

**Resultado automatizado:** 380/380 testes aprovados, 66/66 fluxos integrados aprovados, bateria adversarial sem falhas e testes de processo/TCP aprovados.

**Aceite visual pendente:** não houve ADB, emulador ou execução do APK neste ambiente. Portanto, este relatório não declara o crash visual como comprovadamente resolvido. A correção de protocolo/estado foi validada no servidor e nos bytes das mensagens; o aceite final no dispositivo continua necessário.

## Defeitos, causas e correções

### 1. Limite diário inexistente e saldo divergente

**Causa:** o servidor utilizava apenas `players.battleTokens`; BattleEnd e a coleta 503 não compartilhavam um consumo diário transacional. O dobrador podia elevar o total além do saldo apresentado.

**Correção:**

- nova rotina `Logic/DailyRewards.py`;
- tabela `daily_token_limits`, com chave `(player_id, day)` e restrição `used BETWEEN 0 AND 700`;
- base e bônus do dobrador consomem o mesmo saldo, nunca ultrapassando 700 no dia;
- com saldo zero, a partida pode continuar, mas não concede fichas de batalha;
- coletas 503 usam o mesmo saldo diário e permanecem em `brawlBoxes`;
- o reset ocorre somente quando muda a data no horário local do servidor;
- novas contas começam com 700;
- na primeira passagem de uma conta antiga, o saldo remanescente é conservado; na data seguinte, inicia em 700.

### 2. Ficha estrela repetida e ausência de identidade persistente do evento

**Causa:** a estrela era concedida novamente em vitórias repetidas, sem registro diário por evento.

**Correção:**

- tabela `daily_star_rewards`, com chave `(player_id, day, map_id)` e `amount = 1`;
- no máximo uma estrela por jogador, dia e mapa/evento;
- mapas diferentes possuem concessões independentes;
- replay não cria outra concessão, inclusive após reinício ou na data seguinte;
- o `MapID` e o `map_slot` decodificados no BattleEnd alimentam a recompensa;
- quando há slot, o servidor exige que ele corresponda ao mapa ativo da `EventRotation`;
- no fluxo solo com slot zero, o mapa precisa existir e estar habilitado nos dados V13, preservando o Play solo fora da sala;
- slot divergente não impede a partida nem suas demais recompensas, mas não gera estrela.

### 3. Replay e concorrência

**Causa:** o limite diário precisava participar da mesma operação das recompensas; controle somente em memória não sobreviveria a relogin ou reinício.

**Correção:**

- `BattleRewardsManager` executa consumo diário, estrela, recursos e conclusão do ledger em uma transação `BEGIN IMMEDIATE`;
- o resultado persistido continua sendo a resposta autoritativa de um replay;
- uma falha de gravação desfaz consumo diário, estrela e recursos juntos;
- a chave primária impede duas estrelas concorrentes para o mesmo mapa/dia;
- dez partidas concorrentes na mesma conta/evento resultaram em apenas uma estrela e nenhum estouro do limite.

### 4. Home com valores diários e timestamps inconsistentes

**Causa comprovada no serializador:** a home apresentava o campo diário a partir de estado não sincronizado, mantinha o indicador de limite fixo e gravava três valores temporais inconsistentes (`0`, `2019049`, `0`).

**Correção:**

- `OwnHomeDataMessage` sincroniza o estado diário persistido antes de serializar;
- o saldo exibido é o remanescente real;
- o indicador de limite corresponde a saldo zero;
- o timestamp diário, o timestamp da loja e o timestamp final usam o mesmo instante atual do servidor;
- a ordem e a quantidade dos campos V13/R101 foram preservadas.

Essa inconsistência foi corrigida, mas **não há evidência suficiente para afirmar que ela era a única causa do crash visual**.

### 5. Sequência após BattleEnd

Foram rastreados 14110, resolução da instância, recompensas, 23456/27, 14109, 24101/9, 14366 e KeepAlive. Em processo real, duas partidas consecutivas produziram consumo 20 → 40, saldo 680 → 660 e uma única estrela para o mesmo mapa. O replay imediato e o replay após reinício foram byte a byte idênticos. Home, PlayerStatus e KeepAlive mantiveram a sessão, sem `malformed packet` ou traceback nos logs desses processos.

## Arquivos alterados

- `Logic/DailyRewards.py`: saldo diário, virada do dia e estrela persistente.
- `Logic/BattleRewardsManager.py`: integração transacional com recompensas e ledger.
- `Logic/BattleResultAdapter.py`: propagação de mapa, slot e instante da partida.
- `Logic/EventRotation.py`: vínculo mapa/slot e consumo diário da coleta 503.
- `Database/DatabaseManager.py`: schema relacional v5 e tabelas diárias.
- `Logic/Player.py`: saldo inicial de novas contas em 700.
- `Packets/Messages/Server/Home/OwnHomeDataMessage.py`: apresentação diária e timestamps.
- `tests/test_daily_rewards.py`: doze cenários novos.
- Testes e fixture da home atualizados para as novas regras e para tempo controlado.

Não foram adotados layouts V12/V45. A ordem R101 de BattleEnd, os headers 23456/27 e 24101/9 e a implementação 14362 da R113 foram preservados. A referência V12 foi usada somente para confirmar o princípio de resolver eventos no servidor, sem copiar seu payload.

## Resultados individuais dos novos testes diários

1. Saldo inicial, consumo, reload e reinicialização do schema: **aprovado**.
2. Conservação do saldo legado e reset apenas na data seguinte: **aprovado**.
3. Dobrador limitado pelo saldo e bloqueio com saldo zero: **aprovado**.
4. Trinta e cinco partidas consecutivas interrompem a concessão exatamente em 700: **aprovado**.
5. Dez partidas concorrentes não ultrapassam o limite nem duplicam estrela: **aprovado**.
6. Uma estrela por mapa/dia, independência entre mapas e nova concessão na data seguinte: **aprovado**.
7. Slot validado pela rotação e solo com slot zero preservado: **aprovado**.
8. Replay sem novo consumo, inclusive na data seguinte: **aprovado**.
9. Coleta 503 com o mesmo limite e nova coleta somente na data seguinte: **aprovado**.
10. Falha de gravação com rollback de tokens, estrela e recursos: **aprovado**.
11. Home com saldo persistente, indicador correto e timestamps reais/consistentes: **aprovado**.
12. Seis ciclos BattleEnd/home com nova partida após cada retorno: **aprovado**.

## Matriz integrada e adversarial

- Regressão completa: **380 testes, 0 falhas, 0 erros**.
- Fluxos integrados: **66/66**, cobrindo 61 localizações habilitadas e cinco eventos; replay e retorno à home verificados.
- Processo real: **aprovado** em dois processos, com relogin, replay após reinício, nova partida e persistência conferida no SQLite.
- Ranked/localização: cinco eventos responderam 24124; relogin e KeepAlive aprovados; zero pacotes malformados.
- Adversarial: 6 casos válidos, 622 truncamentos, 24 entradas com dados residuais, 1.200 mutações, 1.000 entradas aleatórias, 8 mapas desabilitados, 6 headers inválidos e 1 entrada acima do limite; `failures=[]` e `unexpectedExceptions=[]`.
- Compilação dos módulos Python: **aprovada**.

Os processos de teste usam banco temporário e transporte bruto controlado. O `config.json` entregue permanece idêntico ao da R113; criptografia, SCID, endereço e credenciais de produção não foram enfraquecidos nem reproduzidos neste relatório.

## Persistência e preservação

- Recompensas, progresso, troféus, personagens, compras e ledger continuam nas estruturas relacionais existentes.
- As tabelas diárias usam a mesma conexão e as mesmas transações das operações correspondentes.
- Não houve alteração de matchmaking, criação de batalha online, handlers de log, respostas falsas ou desativação de “NOVO EVENTO”.
- O estado de evento visualizado permanece persistido entre sessões.
- O banco real enviado para análise não foi modificado.

## Limitações do aceite

- Testes de socket e decodificação não renderizam a interface do APK.
- O banco fornecido não contém a conta do log original; não foi alegada reprodução exata daquela conta.
- A ausência de traceback e de `malformed packet` não prova ausência de crash visual.
- O aceite de partidas consecutivas, retorno ao menu e apresentação dos contadores deve ser concluído no APK pelo usuário.
