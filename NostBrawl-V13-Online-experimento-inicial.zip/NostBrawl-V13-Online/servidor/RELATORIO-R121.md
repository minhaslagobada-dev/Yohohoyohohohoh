# NostBrawl R121 — revisão social

Data: 2026-11-05

## Referência nativa

A revisão usou o tutorial do Jordi e a LIB R101 ARM64 com SHA-256 `ccba455df76597e1d0ff081a07bf5e0537ad555229ad1166588d66d75ebff4ae`. Nenhum layout de V45 ou de outro jogo foi adotado.

No `FriendEntry`, a ordem dos seis inteiros foi confirmada nos destinos `+0x30`, `+0x34`, `+0x38`, `+0x3c`, `+0x40` e `+0x44`. O terceiro inteiro é a relação consumida pelos filtros nativos; o primeiro carrega a presença e o quarto recebe a origem de `AddFriend`. O tipo de `FriendListMessage` é um campo separado da quantidade e o tipo `0` direciona a lista principal de amigos.

O handler nativo de `FriendListUpdateMessage` insere ou atualiza uma entrada, mas não remove. Por isso, atualizações e presença usam `20106`; remoções reenviam a lista completa `20105`, tipo `0`, para os dois lados.

## Alterações

- Removida somente a mensagem automática `Club Created!` da criação de clubes. Mensagens antigas e os demais eventos de clube foram preservados.
- Membros e contadores de clubes usam a presença das conexões registradas; um registro de banco antigo não mantém uma conta desconectada online.
- O próprio jogador usa o estado da sessão autenticada na primeira resposta do clube, antes do registro final do socket.
- `24308` atualiza os demais membros do clube quando a presença muda, sem eco redundante para o próprio jogador.
- `AddFriend` valida e persiste a origem nativa `0–4`; aceitar uma relação preserva essa origem.
- Relações recíprocas são reparadas nas transições de adicionar/aceitar e continuam únicas pela chave do banco.
- Sugestões permanecem somente no fluxo de sugestões. Perfis sem relação não recebem mais estado de sugestão por fallback.
- Remover uma relação inexistente não fabrica sucesso nem envia uma atualização social.
- Remoções sincronizam as listas completas e específicas de cada conta, sem reutilizar a lista do remetente para o destinatário.
- Amigos recebem `20106` com presença real; a entrada usada por convites e telas de equipe contém o mesmo estado.
- `Server.Clients` continua sendo o registro de conexões. Uma sessão antiga não pode substituir a presença de uma conexão mais recente da mesma conta.
- `PlayerStatusMessage` valida o estado e o payload completo. O fluxo próprio de `TeamMemberStatusMessage` não foi substituído nem acoplado à presença social.
- O schema antigo de `friend_relations` recebe `origin` por migração aditiva, preservando relações e timestamps.

## Verificação

- 345 testes automatizados aprovados na staging.
- Testes específicos de adicionar, aceitar, remover, origem, sugestões, presença, clubes e serialização de equipes.
- Teste de duas conexões da mesma conta: a sessão substituída não altera a presença atual.
- Migração de schema antigo validada com `integrity_check=ok` e preservação da relação.
- O pacote não contém banco de dados gerado, caches, `scid-token.key` nem o serviço SCID standalone.
- APK, LIB, SCID remoto, autenticação, criptografia e batalhas não foram alterados.

O aceite visual e de gameplay no APK permanece com o usuário.
