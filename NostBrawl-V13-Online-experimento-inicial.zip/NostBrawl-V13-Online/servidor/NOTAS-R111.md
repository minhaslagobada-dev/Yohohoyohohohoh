# NostBrawl R111

Servidor completo V13 **13.283.1**, derivado da R110. A entrega contém somente o servidor; não inclui APK, patch nativo, dependências ou caches. R109 e R110 permanecem preservadas.

## Causas corrigidas

### Partida normal identificada como amistosa

`Logic/BattleResultPayload.py` lia `player.is_in_real_game`, mas nenhum fluxo inicializava esse atributo. O quinto booleano do cabeçalho de `23456` ficava sempre falso.

A resposta agora segue a referência Pro compatível: `isInRealGame = (tutorialState == 2)`, usando o estado `tutorial` da conta V13. Os dois booleanos de tutorial continuam ligados ao estado `1`; não foi colocada uma constante verdadeira para todos os estados.

### Brawler/skin incompatíveis no BattleResult

Os DataReferences de Brawler já eram copiados dinamicamente do 14110 e a ordem foi confirmada na LIB R101. O problema adicional estava nas skins emitidas com eles:

- `29:0` é `BanditGirlDefault`, da Shelly; a skin padrão de Leon é `29:62` (`NinjaDefault`).
- O encoder podia emitir `29:0` junto de outro Brawler no participante local e emitia skin nula para diversos bots.
- Testes antigos chegavam a aceitar pares incompatíveis, sem validar a relação entre os dois DataReferences.

`23456` agora reutiliza `Files/CsvLogic/Skins.py::Skins.resolve_skin`, o mesmo resolvedor usado pela sala e pelo StartLoading. Cada participante recebe uma DataReference de skin válida para o seu próprio `participant.brawler_id`. Uma skin não padrão válida é preservada; o valor `0` ou uma referência nula é resolvido para a padrão daquele Brawler. Não existe condicional para Leon, ID fixo de personagem ou troca manual de Brawler.

## Troféus e recompensas

As tabelas não foram substituídas por valores fixos. Elas já correspondiam à referência Pro e continuam dependentes do modo, rank/resultado e troféus anteriores do Brawler local.

Casos exercitados na sequência real de mensagens:

| Fluxo | Estado anterior | Resultado esperado |
| --- | --- | ---: |
| Vitória 3v3 | 0 troféu | +6 |
| Derrota 3v3 | 100 troféus | -2 |
| Solo, 1º lugar | 0 troféu | +8 |
| Solo, 8º lugar | 0 troféu | +2 |
| Solo, 10º lugar | 100 troféus | -4 |

Assim, `+6` numa vitória 3v3 da faixa inicial e `+2` no 8º lugar Solo da faixa inicial são valores da referência, não evidência de tabela quebrada. Os testes verificam também o total da conta, os troféus do Brawler e sua persistência após reload.

## Retorno à home

Não foi inventado um campo novo para 14109 ou 24101 e não foi aplicada uma correção de thread sem reprodução. Na LIB R101, o decode de 14109 contém um booleano; 24101 contém `LogicClientHome`, `LogicClientAvatar` e timestamp. A ordem existente foi mantida.

Os testes novos percorrem `ClientThread` e a fábrica real de mensagens por socket: `14350 → 14355 → 14110/23456 → 14109/24101 → 10108/20108`. A mesma conexão precisa responder KeepAlive depois da home. O 24101 é consumido até o fim com loja, eventos, avatar, recompensas e notificações; o decoder de teste agora aceita as ofertas reais em vez de substituir a loja por uma lista vazia.

## Evidências R101 e referência

Foram mantidos o dump Ghidra e o tutorial do Jordi. As vtables da LIB ARM64 R101 foram seguidas pelos getters dos IDs, sem usar layouts V45:

- 14354: getter `0x14339c`, decode `0x3d9448`; um VInt e uma DataReference.
- 14109: getter `0x1f0fb8`, decode `0x41d8a4`; um booleano.
- 24101: getter `0xf3f98`, encode `0x4c6f84`.
- 23456: getter `0x2399f4`, encode `0x2fdf0c`, decode `0x2395f4`; participantes na ordem já documentada.

A LIB analisada permanece `sources/R101-lib/libg.so`, SHA-256 `ccba455df76597e1d0ff081a07bf5e0537ad555229ad1166588d66d75ebff4ae`. O Pro V12 foi usado somente nas regras compatíveis de partida real e troféus; seu código comentado de BattleEnd e seus layouts V12 não foram copiados.

## Escopo preservado

- Início offline, OnPlay fora da sala e o fluxo legado de ready da Gameroom.
- Perfil, Leaderboard, LIB R101, criptografia/autenticação, poder, skins, loja, recompensas e demais fluxos.
- Nenhum matchmaking, batalha online, handler de log, resposta falsa ou patch nativo foi adicionado.
- Nenhuma validação de entrada foi removida e nenhuma funcionalidade não relacionada foi alterada.

## Verificação

- Suíte integral na árvore: **348/348 testes aprovados**.
- Matriz integrada dos **22 Brawlers** disponíveis: sala, StartLoading, 14110, 23456, reload e 24101; os DataReferences de todos os participantes são verificados.
- Cinco sequências por `ClientThread`: vitória/derrota 3v3, Solo em 1º, 8º e 10º, com home e KeepAlive na mesma conexão.
- Verificador de locations/eventos: **66/66 fluxos**, incluindo 61 locations habilitadas e cinco eventos; flag de partida real e pares Brawler/skin de todos os participantes são obrigatórios.
- Fuzz adversarial: seis casos válidos, 622 truncamentos, 24 sufixos residuais, 1.200 mutations, 1.000 entradas aleatórias, oito mapas desabilitados, seis cabeçalhos inválidos e um oversize.
- Resultado do fuzz: `unexpectedExceptions=[]` e `failures=[]`; 257 mutations permaneceram estruturalmente válidas e passaram pelas validações.

Os relatórios R111 ficam separados em `sources/R109-verification/r111-end-to-end-report.json` e `r111-adversarial-report.json`. A suíte também é executada novamente na extração do ZIP antes da entrega.

## Aceite real pendente

**A R111 não foi executada no APK neste ambiente.** Não há emulador/ADB nem captura bruta do 14110 da partida relatada. Os testes comprovam o protocolo e o comportamento do servidor, mas não demonstram a renderização nem descartam um crash interno do APK. O aceite no dispositivo continua obrigatório para confirmar visualmente o fim de “AMISTOSA”, os Brawlers/skins, os troféus e o retorno sem crash.
