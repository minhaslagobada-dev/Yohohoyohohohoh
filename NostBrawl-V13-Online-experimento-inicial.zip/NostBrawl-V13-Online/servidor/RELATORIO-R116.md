# NostBrawl R116 — relatório de correção

## Estado da entrega

A R116 contém uma correção semântica focada no evento enviado pelo `OwnHomeDataMessage` (24101). A validação de protocolo, persistência e fluxos server-side está verde. **O aceite visual do crash após partidas continua pendente no APK/dispositivo do usuário**; os testes automatizados não são apresentados como prova de renderização.

A R115 operacional foi preservada e não é sobrescrita por esta entrega.

## Causa corrigida

O bloco `LogicConfData` da home possui, para cada evento ativo, dois VInts iniciais com funções distintas: tipo/índice do evento e slot. O mapa é informado posteriormente por `DataRef(15, mapID)`.

Na R109, o primeiro valor foi alterado de `slot` para `map_id`, e essa alteração permaneceu até a R115. Assim, a conta real recebia:

| Slot | R115: tipo, slot, mapa | R116: tipo, slot, mapa |
|---:|---|---|
| 1 | 12, 1, 12 | 1, 1, 12 |
| 2 | 13, 2, 13 | 2, 2, 13 |
| 3 | 4, 3, 4 | 3, 3, 4 |
| 4 | 50, 4, 50 | 4, 4, 50 |
| 5 | 37, 5, 37 | 5, 5, 37 |

Evidências usadas:

- encoder nativo R101 `LogicConfData` em `0x249f90` e entrada de evento em `0x3605a0`;
- decoder nativo da home em `0x3f9a4c` para conferir a posição dos blocos;
- histórico preservado: R90–R108 usavam `slot, slot`; a R109 alterou somente o primeiro VInt desse bloco;
- referências compatíveis Pro V12 e Obiad, que separam índice/slot do DataRef de localização;
- conta 414488 carregada de uma cópia do banco real, sem modificar a fonte.

A correção restaura somente `self.v(slot)` no primeiro campo. O segundo slot, o DataRef do mapa, status, timers, tokens, modificadores, rotação e BattleEnd permanecem inalterados.

## Hipóteses verificadas e descartadas

### Arrays diários da home

Uma hipótese de array ausente foi testada e **rejeitada**. Na home analítica R115 de 850 bytes, o `VInt(0)` após o DataRef de perfil é o contador do primeiro array vazio; os dois arrays DataRef seguintes já estão alinhados com o decoder R101. A decodificação na ordem nativa termina com zero bytes restantes.

Todas as alterações temporárias de modos jogados/skins e seus resultados foram revertidas ou isoladas. Elas **não fazem parte da R116**.

### Loja

Os helpers nativos R101 `0x46bedc` e `0xbb5e8` confirmam a ordem atual dos itens e das ofertas: `offerId`, quantidade, DataRef de destino e valor; depois moeda, custo, timer, tag, porcentagem, compra, campo auxiliar, flag diária, custo original e título. Nenhuma divergência justificou alterar `ShopService.py`.

### Notificações e star powers da conta

A notificação de skin existente já está lida e não é enviada na home. Não há star power desbloqueada na conta analisada. Esses dados não sustentam uma correção adicional.

## Arquivos alterados em relação à R115

- `Packets/Messages/Server/Home/OwnHomeDataMessage.py`: uma linha de produção, restaurando o tipo/índice do evento.
- `tests/test_own_home_data_wire.py`: exige `slot, slot` e preserva o mapa no DataRef; o reader de evidência passa a expor os eventos lidos.
- `tests/fixtures/own_home_data.bin`: fixture determinístico regenerado pelo encoder; 341 bytes, SHA-256 `fd51f839eb60b31bcdd89d74578f0b0c0be50dc3cb3502944b09a95a03f617a5`.
- `RELATORIO-R116.md`: este relatório.

Não houve mudança em `config.json`, LIB R101, criptografia, SCID, endereço/porta, banco, recompensas, economia, loja, Gameroom, jogabilidade offline ou fluxos de login.

## Resultados de validação

| Verificação | Resultado |
|---|---|
| Testes focados de home, recompensas, eventos, temporada e loja | **82/82 OK** |
| Suíte completa oficial | **387/387 OK**, 14,194 s |
| Conta real em cópia | `status=ok`; fonte aberta somente para leitura e hash inalterado |
| Eventos da conta real | cinco pares `tipo=slot`; mapas 12, 13, 4, 50 e 37 preservados |
| Home da conta real após BattleEnd | 850 bytes; leitura completa; 26 commodities; timestamps de home/loja coerentes |
| BattleEnd da conta real | seis participantes; residual zero; recompensas `[(1,6,6),(5,100027,100027)]` |
| Apresentação de recompensas | `(40,6,1)` uma vez; `(0,0,0)` na home seguinte e após reload; sem repetição |
| Fluxos integrados | **66/66 OK**; 61 localizações habilitadas, 8 desabilitadas, cinco slots; replay e retorno à home verificados |
| Bateria adversarial | 6 casos válidos, 622 truncamentos, 24 sufixos, 1200 mutações, 1000 entradas aleatórias, 8 mapas desabilitados, 6 cabeçalhos inválidos e 1 oversize; nenhuma falha ou exceção inesperada |
| Processo real | partidas consecutivas, replay imediato e após reinício idempotentes; nova instância legítima concedida uma vez; apresentação não restaurada; KeepAlive OK |
| Eventos ranqueados | mapas/slots 12/1, 13/2, 4/3, 50/4 e 37/5; todos responderam 24124; relogin retomou o último evento; zero pacotes malformados |
| Configuração de produção | inalterada pelos harnesses |

Os testes também reexecutaram as proteções das revisões anteriores: limite diário de 700 tokens, dobrador limitado pelo saldo remanescente, uma ficha estrela por jogador/dia/evento, idempotência persistente de BattleEnd, concorrência, falhas de gravação, reinício, virada do dia, compras e persistência de recursos/progresso.

## Evidências e limites

- A conta real foi testada exclusivamente em uma cópia SQLite. O banco fornecido permaneceu com SHA-256 `5729c0764bae116f0e8f8c0d180c7e67060ffb81a4b85a46d5098a38d73d3577`.
- A home analítica antiga não é apresentada como frame capturado do dispositivo. Os tamanhos dos logs de transporte incluem 16 bytes de criptografia e não foram comparados diretamente com payloads brutos.
- Os harnesses de transporte usam canal bruto de teste; a criptografia/autenticação e o SCID entregues não foram desativados.
- Não houve acesso a ADB/logcat nem renderização do APK. Portanto, não se declara aqui que o crash visual está comprovadamente resolvido.
- O aceite restante deve ocorrer no dispositivo com partidas Solo/3v3 consecutivas, retorno ao menu e nova partida sem desconexão. Se o crash persistir, a próxima evidência necessária é o logcat do instante da falha.

## Preservação

- R115: `NostBrawl-R115-servidor.zip`, SHA-256 `9708fce57312de7cd0ee1fe6b31db6aa9803262eaece42d259181930f6b0c14c`.
- Nenhuma revisão anterior nem dados existentes foram sobrescritos.
- A R116 é fornecida como servidor completo e utiliza o mesmo procedimento operacional das revisões anteriores.
