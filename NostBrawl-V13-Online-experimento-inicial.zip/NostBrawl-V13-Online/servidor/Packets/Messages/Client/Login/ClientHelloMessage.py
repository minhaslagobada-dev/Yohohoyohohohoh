from Utils.Reader import BSMessageReader
from Packets.Messages.Server.Login.ServerHelloMessage import ServerHelloMessage


class ClientHelloMessage(BSMessageReader):
    """Reads the optional V13 ClientHello payload and starts the login flow."""

    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.client = client
        self.player = player
        self.initial_bytes = initial_bytes
        self.major = None
        self.minor = None
        self.build = None
        self.fingerprint_sha = None

    def decode(self):
                                                                           
                                                                             
        if not self.initial_bytes:
            return

        self.read_int()
        self.read_int()

        self.major = self.read_int()
        self.minor = self.read_int()
        self.build = self.read_int()
        self.fingerprint_sha = self.read_string()

        self.read_int()
        self.read_int()

        self.player.client_major = self.major
        self.player.client_minor = self.minor
        self.player.client_build = self.build

    def process(self):
                                                                           
        ServerHelloMessage(self.client, self.player).send()
