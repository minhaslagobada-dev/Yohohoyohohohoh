from Logic.BattleInstances import BattleInstanceService
from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Packets.Messages.Server.Battle.MatchMakingCancelledMessage import (
    MatchMakingCancelledMessage,
)
from Utils.Reader import BSMessageReader


class OnPlay(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self._payload_length = len(initial_bytes)
        self.v17_layout = False
        self.mapSlot = 0
        self.map_id = 0
        self.roomType = 0
        self.CardID = 0
        self.MapIndex = 0

    def decode(self):
        self.mapSlot = self.read_Vint()
        self.CardID = self.read_Vint()
        self.map_id = self.CardID
        self.roomType = self.read_Vint()
        self.v17_layout = self.tell() >= self._payload_length
        if not self.v17_layout:
            self.MapIndex = self.read_Vint()
        else:
            self.MapIndex = self.roomType

    def process(self):
        BattleInstanceService.begin(self.player)
        if self.v17_layout:
            room = GameRoomService.create(
                self.player, self.mapSlot, self.map_id, self.roomType
            )
            GameRoomGateway.deliver_data(self.client, self.player, room)
            MatchMakingCancelledMessage(self.client, self.player).send()
            return room
        self.player.map_id = 15
        self.player.mmplayers = 1
        MatchMakingCancelledMessage(self.client, self.player).send()
        return None
