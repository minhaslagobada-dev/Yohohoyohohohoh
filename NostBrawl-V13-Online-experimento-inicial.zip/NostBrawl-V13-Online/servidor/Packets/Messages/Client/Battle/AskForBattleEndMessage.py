import time

from Logic.BattleEnd import BattleEndError, BattleEndService
from Logic.BattleInstances import BattleInstanceService
from Packets.Messages.Server.Battle.BattleResultBigGameMessage import BattleResultBigGameMessage
from Packets.Messages.Server.Battle.BattleResultBossFightMessage import BattleResultBossFightMessage
from Packets.Messages.Server.Battle.BattleResultDuoShowdownMessage import BattleResultDuoShowdownMessage
from Packets.Messages.Server.Battle.BattleResultMessage import BattleResultMessage
from Packets.Messages.Server.Battle.BattleResultRoboRumbleMessage import BattleResultRoboRumbleMessage
from Packets.Messages.Server.Battle.BattleResultRoboWarsMessage import BattleResultRoboWarsMessage
from Packets.Messages.Server.Battle.BattleResultShowdownMessage import BattleResultShowdownMessage
from Utils.Reader import BSMessageReader


class AskForBattleEndMessage(BSMessageReader):
    RESULT_MESSAGES = {
        0: BattleResultMessage,
        1: BattleResultRoboWarsMessage,
        2: BattleResultShowdownMessage,
        3: BattleResultRoboRumbleMessage,
        4: BattleResultBigGameMessage,
        5: BattleResultDuoShowdownMessage,
        6: BattleResultBossFightMessage,
    }

    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.initial_bytes = initial_bytes
        self.battle = None

    def decode(self):
        self.battle = BattleEndService.decode(self, self.initial_bytes)

    def process(self):
        if self.battle is None:
            raise BattleEndError("BattleEnd não foi decodificado")
        current_time = time.monotonic()
        payload_hash = self.battle.battle_id
        battle_id = BattleInstanceService.resolve_result(
            self.player, payload_hash, self.battle.game_mode
        )
        BattleEndService.apply_to_player(self.player, self.battle)
        self.player.battle_end_id = battle_id
        message_class = self.RESULT_MESSAGES[self.battle.game_mode]
        message = message_class(self.client, self.player)
        message.send()
        self.player.last_battle_end_hash = payload_hash
        self.player.last_battle_instance_id = battle_id
        self.player.last_battle_end_time = current_time
        return {
            "gameMode": self.battle.game_mode,
            "mapID": self.battle.map_id,
            "participants": len(self.battle.participants),
            "battleID": battle_id,
        }
