import hmac
import logging

from Packets.Messages.Server.SCID.SCIDAccountBoundMessage import SCIDAccountBoundMessage
from SCIDClient.Protocol import decode_compressed_string
from SCIDClient.Runtime import get_service
from SCIDClient.Models import SCIDError
from Utils.Reader import BSMessageReader


LOGGER = logging.getLogger(__name__)


class SCIDBindAccountMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.client = client
        self.player = player
        self.initial_bytes = initial_bytes
        self.bind_token = ""
        self.scid_token = ""

    def decode(self):
        self.enable_native_v13()
        self.bind_token, end = decode_compressed_string(self.initial_bytes, 0)
        self.scid_token, end = decode_compressed_string(self.initial_bytes, end)
        if end != len(self.initial_bytes):
            raise ValueError("Dados residuais após SCIDBindAccountMessage")
        self.seek(end)

    def process(self):
        low_id = int(getattr(self.player, "low_id", 0) or 0)
        try:
            if low_id <= 0:
                raise SCIDError("invalid_game_credentials")
            service = get_service()
            if service is None:
                raise SCIDError("scid_disabled")
            account = service.authenticate(self.scid_token)
            if account is None or not hmac.compare_digest(
                account.bind_token, self.bind_token
            ):
                raise SCIDError("invalid_token")
            changed = service.link_game(account, low_id)
            account = service.store.by_id(account.id)
            if account is None or account.game_low_id != low_id:
                raise SCIDError("game_account_bound")
            bound_token = service.tokens.issue(account)
        except SCIDError as error:
            LOGGER.warning("SCID bind rejected for game %s: %s", low_id, error.code)
            SCIDAccountBoundMessage(self.client, self.player, 1, "").send()
            return {"linked": False, "error": error.code}

        self.player.scid_account = account
        self.player.scid_token = bound_token
        SCIDAccountBoundMessage(self.client, self.player, 0, bound_token).send()
        LOGGER.info("SCID bind completed for game %s", low_id)
        return {"linked": True, "changed": changed}
