from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Logic.TeamCode import TeamCode
from Utils.Reader import BSMessageReader


class TeamJoinOrCreateRoomMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.enable_native_v13()
        self.player = player
        self.client = client
        self.code = ""

    def decode(self):
        self.code = self.read_string()
        self.ensure_end()

    def process(self):
        try:
            high_id, room_id = TeamCode.to_id(self.code)
        except ValueError:
            return None
        if high_id != 0:
            return None
        previous = None
        departed = False
        if room_id == 0:
            previous, departed = GameRoomService.leave(self.player)
            room = GameRoomService.create(self.player, 0, -64, 0, False)
        else:
            room, previous, departed = GameRoomService.request_join_transition(
                self.player, room_id
            )
        if room is None:
            return None
        if departed:
            GameRoomGateway.send_left(
                self.player, self.player.low_id, client=self.client
            )
        if previous is not None:
            GameRoomGateway.broadcast_data_and_stream(self.player, previous)
        GameRoomGateway.broadcast_data_and_stream(
            self.player, room, self.client
        )
        return room
