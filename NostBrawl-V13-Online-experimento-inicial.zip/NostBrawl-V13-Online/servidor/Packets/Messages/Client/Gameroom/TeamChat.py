from Packets.Messages.Client.Gameroom.TeamChatMessage import TeamChatMessage


class TeamChat(TeamChatMessage):
    pass
