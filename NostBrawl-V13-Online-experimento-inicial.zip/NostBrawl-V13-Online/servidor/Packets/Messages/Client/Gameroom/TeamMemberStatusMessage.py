from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Utils.Reader import BSMessageReader


class TeamMemberStatusMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.enable_native_v13()
        self.player = player
        self.client = client
        self.status = 0

    def decode(self):
        self.status = self.read_Vint()
        self.ensure_end()

    def process(self):
        room = GameRoomService.set_status(self.player, self.status)
        if room is not None:
            GameRoomGateway.broadcast_data(self.player, room, self.client)
        return room
