from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Utils.Reader import BSMessageReader


class TeamClearInviteMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.enable_native_v13()
        self.player = player
        self.client = client
        self.high_id = 0
        self.room_id = 0

    def decode(self):
        self.high_id = self.read_int()
        self.room_id = self.read_int()
        self.ensure_end()

    def process(self):
        room, invite = GameRoomService.clear_invite(self.player, self.room_id)
        if room is not None:
            GameRoomGateway.broadcast_data(self.player, room)
        return {"room": room, "invite": invite} if room is not None else None
