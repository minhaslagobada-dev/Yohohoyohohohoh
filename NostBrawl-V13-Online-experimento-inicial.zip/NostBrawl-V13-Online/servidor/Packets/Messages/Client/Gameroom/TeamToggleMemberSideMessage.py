from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Utils.Reader import BSMessageReader


class TeamToggleMemberSideMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.enable_native_v13()
        self.player = player
        self.client = client
        self.targets = []
        self.team = 0

    def decode(self):
        count = self.read_Vint()
        if not 0 <= count <= 10:
            raise ValueError("Quantidade de membros inválida")
        self.targets = [self.readLogicLong() for _ in range(count)]
        self.team = self.read_Vint()
        self.ensure_end()

    def process(self):
        room = GameRoomService.set_teams(self.player, self.targets, self.team)
        if room is not None:
            GameRoomGateway.broadcast_data(self.player, room, self.client)
        return room
