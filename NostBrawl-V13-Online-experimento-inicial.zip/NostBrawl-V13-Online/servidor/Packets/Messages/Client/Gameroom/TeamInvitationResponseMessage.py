from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Utils.Reader import BSMessageReader


class TeamInvitationResponseMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.enable_native_v13()
        self.player = player
        self.client = client
        self.invite_type = 0
        self.high_id = 0
        self.room_id = 0
        self.accepted = False

    def decode(self):
        self.invite_type = self.read_Vint()
        self.high_id = self.read_int()
        self.room_id = self.read_int()
        self.accepted = self.read_boolean()
        self.ensure_end()

    def process(self):
        previous = (
            GameRoomService.for_player(self.player) if self.accepted else None
        )
        operation = (
            GameRoomService.accept_invite if self.accepted
            else GameRoomService.clear_invite
        )
        room, invite = operation(self.player, self.room_id, self.invite_type)
        if room is None:
            return None
        if self.accepted:
            if previous is not None and previous["id"] != room["id"]:
                GameRoomGateway.send_left(
                    self.player, self.player.low_id, client=self.client
                )
                previous = GameRoomService.get(previous["id"])
                if previous is not None:
                    GameRoomGateway.broadcast_data_and_stream(
                        self.player, previous
                    )
            GameRoomGateway.broadcast_data_and_stream(
                self.player, room, self.client
            )
        else:
            GameRoomGateway.broadcast_data(self.player, room)
        return {"room": room, "invite": invite, "accepted": self.accepted}
