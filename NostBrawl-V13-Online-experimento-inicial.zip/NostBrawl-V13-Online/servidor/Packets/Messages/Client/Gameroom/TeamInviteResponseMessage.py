from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Utils.Reader import BSMessageReader


class TeamInviteResponseMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.enable_native_v13()
        self.player = player
        self.client = client
        self.room_id = 0
        self.accepted = 0

    def decode(self):
        self.room_id = self.read_Vint()
        self.accepted = self.read_Vint()
        self.ensure_end()

    def process(self):
        accepted = self.accepted == 1
        previous = GameRoomService.for_player(self.player) if accepted else None
        operation = (
            GameRoomService.accept_invite if accepted
            else GameRoomService.clear_invite
        )
        room, invite = operation(self.player, self.room_id)
        if room is None:
            return None
        if accepted:
            if previous is not None and previous["id"] != room["id"]:
                GameRoomGateway.send_left(
                    self.player, self.player.low_id, client=self.client
                )
                previous = GameRoomService.get(previous["id"])
                if previous is not None:
                    GameRoomGateway.broadcast_data_and_stream(
                        self.player, previous
                    )
            GameRoomGateway.broadcast_data_and_stream(
                self.player, room, self.client
            )
        else:
            GameRoomGateway.broadcast_data(self.player, room)
        return {"room": room, "invite": invite, "accepted": accepted}
