from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Packets.Messages.Server.Gameroom.TeamLeftMessage import TeamLeftMessage
from Utils.Reader import BSMessageReader


class TeamLeaveMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.enable_native_v13()
        self.player = player
        self.client = client

    def decode(self):
        self.ensure_end()

    def process(self):
        room, departed = GameRoomService.leave(self.player)
        if room is not None:
            GameRoomGateway.broadcast_data_and_stream(self.player, room)
        if departed:
            TeamLeftMessage(self.client, self.player).send()
        return room
