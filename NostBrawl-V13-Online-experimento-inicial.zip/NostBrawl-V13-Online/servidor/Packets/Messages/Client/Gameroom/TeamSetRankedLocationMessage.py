from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Utils.Reader import BSMessageReader


class TeamSetRankedLocationMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.enable_native_v13()
        self.player = player
        self.client = client
        self.map_id = 0
        self.slot = 0

    def decode(self):
        self.map_id = self.read_Vint()
        self.slot = self.read_Vint()
        self.ensure_end()

    def process(self):
        room = GameRoomService.set_ranked_location(
            self.player, self.map_id, self.slot
        )
        if room is not None:
            GameRoomGateway.broadcast_data(self.player, room, self.client)
        return room
