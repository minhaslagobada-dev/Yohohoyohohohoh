from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Utils.Reader import BSMessageReader


class TeamRequestJoinMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.enable_native_v13()
        self.player = player
        self.client = client
        self.room_high_id = 0
        self.room_id = 0
        self.owner_high_id = 0
        self.owner_id = 0

    def decode(self):
        self.room_high_id = self.read_int()
        self.room_id = self.read_int()
        self.owner_high_id = self.read_int()
        self.owner_id = self.read_int()
        self.ensure_end()

    def process(self):
        room, previous, departed = GameRoomService.request_join_transition(
            self.player, self.room_id
        )
        if room is None:
            return None
        if departed:
            GameRoomGateway.send_left(
                self.player, self.player.low_id, client=self.client
            )
        if previous is not None:
            GameRoomGateway.broadcast_data_and_stream(self.player, previous)
        GameRoomGateway.broadcast_data_and_stream(
            self.player, room, self.client
        )
        return room
