from Packets.Messages.Client.Gameroom.TeamKickMessage import TeamKickMessage


class TeamKick(TeamKickMessage):
    pass
