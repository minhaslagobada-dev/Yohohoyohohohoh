from Packets.Messages.Client.Gameroom.TeamJoinMessage import TeamJoinMessage


class TeamJoin(TeamJoinMessage):
    pass
