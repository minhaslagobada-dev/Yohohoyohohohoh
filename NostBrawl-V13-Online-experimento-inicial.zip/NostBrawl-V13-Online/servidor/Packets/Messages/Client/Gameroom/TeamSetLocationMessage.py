from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Utils.Reader import BSMessageReader


class TeamSetLocationMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.enable_native_v13()
        self.player = player
        self.client = client
        self.location = (0, -1)
        self.slot = 0

    def decode(self):
        self.location = self.readScId()
        self.ensure_end()

    def process(self):
        _, map_id = self.location
        room = GameRoomService.set_location(self.player, map_id)
        if room is not None:
            GameRoomGateway.broadcast_data(self.player, room, self.client)
        return room
