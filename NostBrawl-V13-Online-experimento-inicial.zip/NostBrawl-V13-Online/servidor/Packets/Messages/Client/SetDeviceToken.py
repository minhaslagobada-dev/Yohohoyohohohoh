from Utils.Reader import BSMessageReader


class SetDeviceToken(BSMessageReader):
    """Pro V12 SetDeviceToken (10113); notification tokens need no response."""

    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.client = client
        self.player = player
        self.device_token = b""
        self.value = 0

    def decode(self):
        length = self.read_int()
        if length > 4096:
            raise ValueError(f"Invalid device-token length: {length}")
        self.device_token = self._read_exact(length)
        self.value = self.read_int()

    def process(self):
        return None
