from Packets.Messages.Server.KeepAliveOkMessage import KeepAliveOkMessage
from Utils.Reader import BSMessageReader


class KeepAliveMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.client = client
        self.player = player

    def decode(self):
        return

    def process(self):
        KeepAliveOkMessage(self.client, self.player).send()
