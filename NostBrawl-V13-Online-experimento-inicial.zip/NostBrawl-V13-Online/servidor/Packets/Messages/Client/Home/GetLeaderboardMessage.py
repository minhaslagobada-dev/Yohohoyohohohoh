from Logic.LeaderboardService import LeaderboardService
from Packets.Messages.Server.Leaderboard.LeaderboardMessage import LeaderboardMessage
from Packets.Messages.Server.Leaderboard.TopGlobalClubsDataMessage import GetLeaderboardClubGlobalOkMessage
from Packets.Messages.Server.Leaderboard.TopGlobalPlayersDataMessage import GetLeaderboardGlobalOkMessage
from Packets.Messages.Server.Leaderboard.TopLocalClubsDataMessage import GetLeaderboardClubLocalOkMessage
from Packets.Messages.Server.Leaderboard.TopLocalPlayersDataMessage import GetLeaderboardLocalOkMessage
from Utils.Reader import BSMessageReader


class GetLeaderboardMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.is_local = self.read_boolean()
        self.type = self.read_Vint()
        self.target_brawler = 0
        reference = self.readScId()
        if reference[0] == 16:
            self.target_brawler = reference[1]

    def process(self):
        if self.type in (0, 1):
            brawler = self.target_brawler if self.type == 0 else None
            players = LeaderboardService.players(brawler)
            if self.type == 0:
                LeaderboardMessage(
                    self.client,
                    self.player,
                    0,
                    self.is_local,
                    players,
                    self.target_brawler,
                ).send()
            elif self.is_local:
                GetLeaderboardLocalOkMessage(
                    self.client, self.player, players
                ).send()
            else:
                GetLeaderboardGlobalOkMessage(
                    self.client, self.player, players
                ).send()
        elif self.type == 2:
            if self.is_local:
                GetLeaderboardClubLocalOkMessage(
                    self.client, self.player, self.type
                ).send()
            else:
                GetLeaderboardClubGlobalOkMessage(
                    self.client, self.player, self.type
                ).send()
