from Logic.BattleInstances import BattleInstanceService
from Packets.Messages.Server.Home.OwnHomeDataMessage import OwnHomeDataMessage
from Utils.Reader import BSMessageReader


class GoHomeFromOfflinePractiseMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.unknown = self.read_boolean()
        self.ensure_end()

    def process(self):
        battle = getattr(self.player, "battle_thread", None)
        if battle is not None:
            battle.started = 0
        BattleInstanceService.mark_home(self.player)
        OwnHomeDataMessage(self.client, self.player).send()
        return None
