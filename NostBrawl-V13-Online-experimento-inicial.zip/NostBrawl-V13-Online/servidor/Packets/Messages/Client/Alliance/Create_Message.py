from Logic.ClubService import ClubError, ClubService
from Packets.Messages.Server.Alliance.AllianceStreamMessage import AllianceStreamMessage
from Packets.Messages.Server.Alliance.Events.AllianceCreateOkMessage import AllianceCreateOkMessage
from Packets.Messages.Server.Alliance.Events.JoinFail import AllianceJoinFail
from Packets.Messages.Server.Alliance.My_Alliance_Message import MyAllianceMessage
from Utils.Helpers import Helpers
from Utils.Reader import BSMessageReader


class Create_Message(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.clubHighID = 0
        self.clubLowID = Helpers.randomClubID(self)
        self.RegionIdentifier = 0
        self.clubregionID = 0
        self.clubfriendlyfamily = 0
        self.clubName = self.read_string()
        self.clubdescription = self.read_string()
        self.BadgeIdentifier = self.read_Vint()
        self.clubbadgeID = self.read_Vint()
        self.clubtype = self.read_Vint()
        self.clubtrophiesneeded = self.read_Vint()

    def process(self):
        try:
            club, _ = ClubService.create(
                self.player,
                self.clubLowID,
                self.clubName,
                self.clubdescription,
                self.clubbadgeID,
                self.clubtype,
                self.clubtrophiesneeded,
                self.clubfriendlyfamily,
            )
        except ClubError as error:
            AllianceJoinFail(self.client, self.player).send()
            return str(error)
        AllianceCreateOkMessage(self.client, self.player).send()
        MyAllianceMessage(self.client, self.player, club["id"]).send()
        AllianceStreamMessage(self.client, self.player, club["id"], 0).send()
        return club
