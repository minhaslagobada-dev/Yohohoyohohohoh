from Logic.ClubService import ClubError, ClubService
from Packets.Messages.Server.Alliance.AllianceStreamMessage import AllianceStreamMessage
from Packets.Messages.Server.Alliance.Alliance_Chat_Server_Message import AllianceChatServerMessage
from Packets.Messages.Server.Alliance.Events.AllianceJoinOkMessage import AllianceJoinOkMessage
from Packets.Messages.Server.Alliance.Events.JoinFail import AllianceJoinFail
from Packets.Messages.Server.Alliance.My_Alliance_Message import MyAllianceMessage
from Utils.Reader import BSMessageReader


class Join_Message(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.player.club_high_id = self.read_int()
        self.clubID = self.read_int()

    def process(self):
        try:
            club, entry = ClubService.join(self.player, self.clubID)
        except ClubError as error:
            AllianceJoinFail(self.client, self.player).send()
            return str(error)
        AllianceJoinOkMessage(self.client, self.player).send()
        MyAllianceMessage(self.client, self.player, club["id"]).send()
        AllianceStreamMessage(self.client, self.player, club["id"], 0).send()
        for member_id in club["member_ids"]:
            AllianceChatServerMessage(
                self.client, self.player, 3, club["id"], entry=entry
            ).sendWithLowID(member_id)
        return club
