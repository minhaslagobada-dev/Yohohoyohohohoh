from Logic.FriendService import FriendService
from Packets.Messages.Server.Friend.FriendSuggestionsMessage import FriendSuggestionsMessage
from Utils.Reader import BSMessageReader


class AskForFriendSuggestionsMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.ensure_end()

    def process(self):
        entries = FriendService.suggestions(self.player)
        FriendSuggestionsMessage(self.client, self.player, entries).send()
        return entries
