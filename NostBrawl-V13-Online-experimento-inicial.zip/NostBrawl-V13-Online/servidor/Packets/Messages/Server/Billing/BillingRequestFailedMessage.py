from Utils.Writer import Writer


class BillingRequestFailedMessage(Writer):
    def __init__(self, client, player, reason, error_code=1):
        super().__init__(client)
        self.id = 20121
        self.player = player
        self.reason = reason
        self.error_code = error_code

    def encode(self):
        self.writeInt(self.error_code)
        self.writeString(self.reason)
        self.writeInt(0)
