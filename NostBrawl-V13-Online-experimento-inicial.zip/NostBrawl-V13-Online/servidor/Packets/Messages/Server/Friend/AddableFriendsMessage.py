from Logic.FriendPayload import encode_addable_friend
from Utils.Writer import Writer


class AddableFriendsMessage(Writer):
    def __init__(self, client, player, entries):
        super().__init__(client)
        self.id = 20107
        self.player = player
        self.entries = list(entries)

    def encode(self):
        self.writeInt(len(self.entries))
        for entry in self.entries:
            encode_addable_friend(self, entry)
