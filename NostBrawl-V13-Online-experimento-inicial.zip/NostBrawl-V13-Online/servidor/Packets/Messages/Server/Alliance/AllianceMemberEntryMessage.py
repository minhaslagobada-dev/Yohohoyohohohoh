from Database.DatabaseManager import DataBase
from Utils.Writer import Writer
import json

class AllianceMemberEntryMessage(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 24308
        self.version = 11
        self.player = player

    def encode(self):
        self.writeInt(int(getattr(self.player, "club_high_id", 0) or 0))
        self.writeInt(int(getattr(self.player, "club_low_id", 0) or 0))
        self.writeInt(int(getattr(self.player, "high_id", 0) or 0))
        self.writeInt(int(getattr(self.player, "low_id", 0) or 0))
        self.writeString(self.player.name)
        self.writeVint(int(getattr(self.player, "club_role", 0) or 0))
        self.writeVint(int(getattr(self.player, "trophies", 0) or 0))
        self.writeVint(int(getattr(self.player, "online", 0) or 0))
        self.writeVint(0)
        self.writeVint(0)
        self.writeScId(28, int(getattr(self.player, "profile_icon", 0) or 0))