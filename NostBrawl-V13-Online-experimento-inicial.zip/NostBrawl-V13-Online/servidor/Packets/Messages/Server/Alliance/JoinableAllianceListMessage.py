from Logic.ClubService import ClubService
from Utils.Writer import Writer, packet_settings


class JoinableAllianceListMessage(Writer):
    def __init__(self, client, player):
        super().__init__(client)
        self.id = 24304
        self.version = 11
        self.player = player

    def _log_sent(self, packet_length):
        super()._log_sent(packet_length)
        if packet_settings["ShowPacketsInLog"]:
            print(
                f"Server | JoinableAllianceListMessage version={self.version}; "
                f"raw payload: {self.buffer.hex()}"
            )

    def encode(self):
        clubs = ClubService.list_clubs(1, 100, 2, 30)
        self.writeVint(len(clubs))
        for club in clubs:
            self.writeInt(0)
            self.writeInt(club["id"])
            self.writeString(club["name"])
            self.writeVint(8)
            self.writeVint(club["badge_id"])
            self.writeVint(club["type"])
            self.writeVint(club["member_count"])
            self.writeVint(club["trophies"])
            self.writeVint(club["required_trophies"])
            self.writeVint(0)
            self.writeVint(club["online_count"])
