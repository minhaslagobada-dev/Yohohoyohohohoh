from Logic.ClubService import ClubService
from Utils.Writer import Writer


class AllianceStreamMessage(Writer):
    def __init__(self, client, player, clubLowID, type):
        super().__init__(client)
        self.id = 24311
        self.version = 11
        self.player = player
        self.eventType = type
        self.clubLowID = clubLowID

    def encode(self):
        if not self.clubLowID:
            self.writeVint(0)
            return
        entries = ClubService.get_messages(self.clubLowID)
        self.writeVint(len(entries))
        for entry in entries:
            self.writeVint(entry["event"])
            self.writeVint(0)
            self.writeVint(entry["tick"])
            self.writeVint(0)
            self.writeVint(entry["player_id"])
            self.writeString(entry["player_name"])
            self.writeVint(entry["player_role"])
            self.writeVint(0)
            self.writeVint(0)
            if entry["event"] == 4:
                self.writeVint(int(entry["message"]))
                self.writeVint(1)
                self.writeVint(0)
                self.writeVint(entry["player_id"])
                self.writeString(entry["player_name"])
            else:
                self.writeString(entry["message"])
