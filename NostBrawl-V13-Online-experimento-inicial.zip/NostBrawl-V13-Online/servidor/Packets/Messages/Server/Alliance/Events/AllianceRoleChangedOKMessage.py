from Utils.Writer import Writer
import json


class AllianceRoleChangedOKMessage(Writer):

    def __init__(self, client, player, type):
        super().__init__(client)
        self.id = 24333
        self.version = 11
        self.player = player
        self.type = type

    def encode(self):
        if self.type == 0:
        	self.writeVint(81)            
        elif self.type == 1:
        	self.writeVint(82)