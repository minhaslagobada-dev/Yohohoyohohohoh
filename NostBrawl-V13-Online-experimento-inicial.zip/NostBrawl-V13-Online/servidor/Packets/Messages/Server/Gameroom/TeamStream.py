from Packets.Messages.Server.Gameroom.TeamStreamMessage import TeamStreamMessage


class TeamStream(TeamStreamMessage):
    pass
