from Utils.Writer import Writer


class SetInvitesBlockedOkMessage(Writer):
    def __init__(self, client, player):
        super().__init__(client)
        self.enable_native_v13()
        self.id = 24111
        self.player = player

    def encode(self):
        self.writeVint(213)
        self.writeBoolean(int(getattr(self.player, "do_not_distrub", 0)) == 1)
