from Utils.Writer import Writer


class TeamGameStartingMessage(Writer):
    def __init__(self, client, player, room):
        super().__init__(client)
        self.enable_native_v13()
        self.id = 24130
        self.player = player
        self.room = room

    def encode(self):
        self.writeVint(0)
        self.writeVint(0)
        self.writeScId(15, self.room["map_id"])
