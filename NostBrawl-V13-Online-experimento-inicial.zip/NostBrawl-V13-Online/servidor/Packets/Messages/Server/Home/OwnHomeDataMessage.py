import time

from Database.DatabaseManager import DataBase
from Logic.BoxInventory import BoxInventory
from Logic.DailyRewards import DailyRewards
from Logic.EventRotation import EventRotation
from Logic.EventSlots import EventSlots
from Logic.NotificationFactory import NotificationFactory
from Logic.SeasonService import SeasonService
from Logic.ShopService import ShopService
from Utils.Writer import Writer


HOME_EVENT_SLOTS = tuple(range(6))


def _integer(value, default=0):
    try:
        return max(0, int(value))
    except (TypeError, ValueError):
        return default


def _mapping_value(mapping, key, default=0):
    if not isinstance(mapping, dict):
        return default
    return _integer(mapping.get(str(key), mapping.get(key, default)), default)


class OwnHomeDataMessage(Writer):
    def __init__(self, client, player):
        super().__init__(client)
        self.id = 24101
        self.version = 9
        self.player = player
        self._bit_index = 0

    def _value(self, name, default=0):
        return _integer(getattr(self.player, name, default), default)

    def _align(self):
        self._bit_index = 0

    def v(self, value=0):
        self._align()
        self.writeVint(_integer(value))

    def i(self, value=0):
        self._align()
        self.writeInt(value)

    def s(self, value=None):
        self._align()
        self.writeString(value)

    def long(self, high, low):
        self._align()
        self.writeLong(high, low)

    def boolean(self, value):
                                                                            
        if self._bit_index == 0:
            self.buffer += b"\x00"
        if value:
            self.buffer = (
                self.buffer[:-1]
                + bytes([self.buffer[-1] | (1 << self._bit_index)])
            )
        self._bit_index = (self._bit_index + 1) & 7

    def list(self, values):
        self.v(len(values))
        for value in values:
            self.v(value)

    def scid(self, csv_id, item_id):
        self.v(csv_id)
        self.v(item_id)

    def _unlocked_brawlers(self):
        states = getattr(self.player, "BrawlersUnlockedState", {})
        if not isinstance(states, dict):
            return []
        result = []
        for brawler in getattr(self.player, "brawlers_id", []):
            brawler = _integer(brawler)
            if states.get(str(brawler), states.get(brawler, 0)) == 1:
                result.append(brawler)
        return result

    def _selected_skins(self):
        selected = getattr(self.player, "brawlers_skins", {})
        if not isinstance(selected, dict):
            return []
                                                                            
        return [_integer(skin) for skin in selected.values()]

    def _unlocked_skins(self):
        skins = getattr(self.player, "UnlockedSkins", {})
        if isinstance(skins, dict):
            skins = skins.get("Skins", [])
        if not isinstance(skins, (list, tuple, set)):
            return []
        return [_integer(skin) for skin in skins if _integer(skin) != 0]

    def _reward_animation_state(self):
        values = []
        for name in ("tokensAnim", "trophiesAnim", "bigTokensAnim"):
            try:
                values.append(int(getattr(self.player, name, 0) or 0))
            except (TypeError, ValueError):
                values.append(0)
        return tuple(values)

    def _consume_reward_animations(self):
        expected = getattr(self, "_presented_rewards", None)
        self._presented_rewards = None
        if expected is None:
            return
        persisted = DataBase.consume_home_reward_animations(self.player, expected)
        if persisted is None:
            return
        progression = getattr(self.player, "progression", {})
        keys = ("keyReward", "trophyReward", "starKeyReward")
        if isinstance(progression, dict):
            for key, value, replacement in zip(keys, expected, persisted):
                if DataBase._number(progression.get(key, 0)) == value:
                    progression[key] = replacement
        for name, value, replacement in zip(
            ("tokensAnim", "trophiesAnim", "bigTokensAnim"), expected, persisted
        ):
            try:
                current = int(getattr(self.player, name, 0) or 0)
            except (TypeError, ValueError):
                current = 0
            if current == value:
                setattr(self.player, name, replacement)

    def _send_payload(self, client, crypter, raw_packet):
        packet_length = super()._send_payload(client, crypter, raw_packet)
        self._consume_reward_animations()
        return packet_length

    def encode(self):
        daily = DailyRewards.sync_player(self.player)
        BoxInventory.migrate(self.player)
        season = SeasonService.sync(self.player)
        timestamp = int(time.time())
        self._presented_rewards = self._reward_animation_state()
        self._bit_index = 0
        high_id = self._value("high_id")
        low_id = self._value("low_id")

                        
        self.v(timestamp)
        self.v(0)
        self.v(self._value("trophies"))
        self.v(self._value("highest_trophies"))
        self.v(0)
        self.v(self._value("trophy_road", 1))
        self.v(self._value("player_experience"))
        self.scid(28, self._value("profile_icon"))
        self.v(0)                     

        selected_skins = self._selected_skins()
        self.v(len(selected_skins))
        for skin in selected_skins:
            self.scid(29, skin)
        unlocked_skins = self._unlocked_skins()
        self.v(len(unlocked_skins))
        for skin in unlocked_skins:
            self.scid(29, skin)

        self.boolean(False)
        self.v(0)                      
        for value in self._presented_rewards:
            self.v(value)
        self.v(0)
        self.v(0)
        self.boolean(daily["remaining"] <= 0)
        self.v(0)
        self.boolean(False)
        self.v(self._value("tokensdoubler"))
        self.v(season["remaining"])
        for _ in range(4):
            self.boolean(False)
        self.v(0)
        self.v(0)
        self.v(0)
        self.boolean(False)
        ShopService.encode_home(self, self.player)
        self.v(0)
        self.v(0)
        self.v(0)
        self.v(0)
        self.v(self._value("tickets"))
        self.v(0)
        self.scid(16, self._value("brawler_id"))

                        
        for value in [timestamp, 100, 10, 30, 3, 80, 10, 50, 1000, 500, 50, 999900]:
            self.v(value)
        self.list([0, 30, 80, 170, 350, 0])
        self.list(HOME_EVENT_SLOTS)
        events = EventRotation.snapshot(self.player)
        self.v(len(events))
        event_timer = EventSlots.Timer(self)
        for index, event in enumerate(events, 1):
            slot = _integer(event.get("slot", index), index)
            map_id = _integer(event.get("map_id", 0))
            tokens = _integer(event.get("tokens", 0))
            configured_modifiers = event.get("modifiers")
            if configured_modifiers is None:
                configured_modifier = _integer(event.get("modifier", 0))
                configured_modifiers = (
                    (configured_modifier,) if 0 < configured_modifier < 6 else ()
                )
            if not isinstance(configured_modifiers, (list, tuple)):
                raise ValueError("Event modifiers must be a list or tuple")
            modifiers = []
            for modifier in configured_modifiers:
                modifier = _integer(modifier)
                if not 0 < modifier < 6:
                    raise ValueError("Invalid V13 event modifier")
                modifiers.append(modifier)

            self.v(map_id)
            self.v(slot)
            self.v(0)
            self.v(_integer(event.get("timer", event_timer), event_timer))
            self.v(tokens)
            self.scid(15, map_id)
            self.v(_integer(event.get("status", 1), 1))
            self.s()
            self.v(0)
            self.list(modifiers)
            self.v(0)
        self.v(0)
        self.list([20, 35, 75, 140, 290, 480, 800, 1250])
        self.list([1, 2, 3, 4, 5, 10, 15, 20])
        self.list([10, 30, 80])
        self.list([6, 20, 60])
        self.list([20, 50, 140])
        self.list([150, 400, 1200])

                                                                           
                                                                          
        self.v(0)
        for value in [daily["remaining"], 20, 8640, 10, 5]:
            self.v(value)
        self.boolean(False)
        self.boolean(False)
        self.boolean(False)
        self.v(0)
        self.v(0)
        self.boolean(True)
        self.v(0)

                          
        self.long(high_id, low_id)
        NotificationFactory.encode(
            self, NotificationFactory.home_notifications(self.player)
        )
        self.v(0)
        self.boolean(False)
        self.v(0)

                            
        for _ in range(3):
            self.v(high_id)
            self.v(low_id)
        name = str(getattr(self.player, "name", "Guest") or "Guest")
        self.s(name)
        self.boolean(name != "Guest")
        self.s()
        self.v(8)

                                                                        
                                                                            
        brawlers = [
            _integer(brawler)
            for brawler in getattr(self.player, "brawlers_id", [])
        ]
        card_ids = list(getattr(self.player, "card_unlock_id", []))
        states = getattr(self.player, "BrawlersUnlockedState", {})
        resources = (
            (23, 0, self._value("star_points")),
            (5, 1, self._value("brawl_boxes")),
            (5, 8, self._value("gold")),
            (5, 9, self._value("big_boxes")),
        )
        self.v(len(card_ids) + len(resources))
        if len(card_ids) != len(brawlers):
            raise ValueError("Brawler and unlock card counts differ")
        for brawler, card in zip(brawlers, card_ids):
            self.v(23)
            self.v(_integer(card))
            default_state = 1 if brawler == 0 else 0
            self.v(_mapping_value(states, brawler, default_state))
        for csv_id, resource_id, amount in resources:
            self.v(csv_id)
            self.v(resource_id)
            self.v(amount)

        trophies = getattr(self.player, "brawlers_trophies", {})
        rank_trophies = getattr(self.player, "brawlers_trophies_in_rank", {})
        upgrade_points = getattr(self.player, "brawlers_upgradium", {})
        power_levels = getattr(self.player, "Brawler_level", {})

        for mapping in (trophies, rank_trophies):
            self.v(len(brawlers))
            for brawler in brawlers:
                self.scid(16, brawler)
                self.v(_mapping_value(mapping, brawler))
        self.v(0)

        self.v(len(brawlers))
        for brawler in brawlers:
            self.scid(16, brawler)
            self.v(_mapping_value(upgrade_points, brawler))
        self.v(len(brawlers))
        for brawler in brawlers:
            self.scid(16, brawler)
            self.v(_mapping_value(power_levels, brawler, 1))

                                                                             
        self.v(0)
        self.v(0)

        self.v(self._value("gems"))
        self.v(self._value("gems"))
        self.v(self._value("player_experience"))
        for _ in range(7):
            self.v(0)
        self.v(self._value("tutorial", 2))

                                 
        self.v(timestamp)
