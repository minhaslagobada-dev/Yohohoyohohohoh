from Logic.BattleResultAdapter import apply_battle_result_rewards
from Packets.Messages.Server.Battle.BattleResultMessage import BattleResultMessage


class BattleResultBigGameMessage(BattleResultMessage):
    GAME_MODE = 4

    def _get_rewards(self, battle_id):
        if battle_id is None:
            return apply_battle_result_rewards(self.player, self.GAME_MODE)
        return apply_battle_result_rewards(self.player, self.GAME_MODE, battle_id)
