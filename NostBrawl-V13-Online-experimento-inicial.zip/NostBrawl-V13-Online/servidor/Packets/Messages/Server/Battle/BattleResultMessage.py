from Logic.BattleResultAdapter import apply_battle_result_rewards
from Logic.BattleResultPayload import encode_battle_result
from Utils.Writer import Writer


class BattleResultMessage(Writer):
    GAME_MODE = 0

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 23456
        self.version = 27
        self.player = player
        self.enable_native_v13()

    def _get_rewards(self, battle_id):
        if battle_id is None:
            return apply_battle_result_rewards(self.player, self.GAME_MODE)
        return apply_battle_result_rewards(self.player, self.GAME_MODE, battle_id)

    def _encode_with_rewards(self, rewards):
        self.rewards = rewards
        encode_battle_result(self, rewards, self.GAME_MODE)

    def encode(self):
        battle_id = getattr(self.player, "battle_end_id", None)
        rewards = self._get_rewards(battle_id)
        self._encode_with_rewards(rewards)
