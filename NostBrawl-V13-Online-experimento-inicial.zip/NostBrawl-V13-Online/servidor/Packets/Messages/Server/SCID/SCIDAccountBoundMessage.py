from Utils.Writer import Writer


class SCIDAccountBoundMessage(Writer):
    def __init__(self, client, player, result, scid_token):
        super().__init__(client)
        self.player = player
        self.id = 25165
        self.result = int(result)
        self.scid_token = scid_token or ""
        self.enable_native_v13()

    def encode(self):
        self.writeInt(self.result)
        self.writeCompressedString(self.scid_token)
