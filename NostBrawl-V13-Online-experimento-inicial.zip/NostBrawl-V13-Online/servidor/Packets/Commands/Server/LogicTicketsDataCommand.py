from Packets.Commands.Server.LogicBuyItem import LogicBuyItem


class LogicTicketsDataCommand(LogicBuyItem):
    def __init__(self, client, player, count):
        super().__init__(
            client,
            player,
            [{"type": 3, "amount": int(count)}],
            trophy_road=player.trophy_road,
        )
