from Utils.Writer import Writer


class LogicChangeResourcesCommand(Writer):
    def __init__(self, client, player, resource_global_id, amount):
        super().__init__(client)
        self.id = 24111
        self.player = player
        self.resource_global_id = int(resource_global_id)
        self.amount = int(amount)
        if self.resource_global_id < 1 or self.amount == 0:
            raise ValueError("Invalid resource change")

    def encode(self):
        self.writeVint(207)
        self.writeVint(self.resource_global_id)
        self.writeVint(self.amount)
        for _ in range(5):
            self.writeVint(0)
