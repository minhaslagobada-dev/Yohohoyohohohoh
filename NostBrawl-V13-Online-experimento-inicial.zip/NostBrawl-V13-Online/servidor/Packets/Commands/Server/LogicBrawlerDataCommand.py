from Packets.Commands.Server.LogicBuyItem import LogicBuyItem


class LogicBrawlerDataCommand(LogicBuyItem):
    def __init__(self, client, player, ID, state):
        trophy_road = player.trophy_road if state == 1 else 0
        super().__init__(
            client,
            player,
            [{"type": 6, "amount": 1, "brawler": int(ID)}],
            trophy_road=trophy_road,
        )
