from Packets.Commands.Server.LogicSkinDataCommand import LogicSkinDataCommand


class LogicUnlockSkinServerCommand(LogicSkinDataCommand):
    """Backwards-compatible Pro name for the dedicated V18 skin response."""
