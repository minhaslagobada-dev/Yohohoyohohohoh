from Packets.Commands.Server.LogicBuyItem import LogicBuyItem


class LogicSkinDataCommand(LogicBuyItem):
    def __init__(self, client, player, ID, brawler=None):
        if isinstance(ID, dict):
            result = ID
            if result.get("rewardNames") != ["Skin"]:
                raise ValueError("LogicSkinDataCommand requires one skin reward")
            skin = int(result.get("skin", result["rewards"][0]))
        else:
            skin = int(ID)
        rewards = []
        if brawler is not None:
            rewards.append({"type": 6, "amount": 1, "brawler": int(brawler)})
        rewards.append({"type": 7, "amount": 1, "skin": skin})
        super().__init__(
            client,
            player,
            rewards,
            command_context=[0, 1, 0, 0, 0],
        )
