from Logic import TrophyRoad
from Logic.RewardDelivery import RewardDelivery
from Logic.Rewards import RewardError
from Utils.Reader import BSMessageReader


class LogicClaimRankUpRewardCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.read_Vint()
        self.read_Vint()
        self.readLogicLong()
        data_reference = self.readScId()
        self.brawlerPowerPointsTarget = data_reference
        self.brawlerID = data_reference[1]

    def process(self):
        try:
            result = TrophyRoad.claim(
                self.player, getattr(self, "brawlerID", 0)
            )
        except RewardError as error:
            return str(error)
        if result["rewardType"] == "box":
            response = {"kind": "box", "result": result}
        elif result["rewardType"] == "event":
            return result
        else:
            response = {
                "kind": "item",
                "rewards": RewardDelivery.displays(result["rewardDetails"]),
                "trophyRoad": result["trophyRoad"],
            }
        RewardDelivery.send(self.client, self.player, response)
        return result
