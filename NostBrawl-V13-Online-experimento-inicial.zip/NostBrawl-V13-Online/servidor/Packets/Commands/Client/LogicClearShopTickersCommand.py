from Logic.Rewards import RewardError
from Logic.ShopService import ShopService
from Utils.Reader import BSMessageReader


class LogicClearShopTickersCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.read_Vint()
        self.read_Vint()
        self.readLogicLong()
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()

    def process(self):
        try:
            return ShopService.clear_tickers(self.player)
        except (RewardError, TypeError, ValueError) as error:
            return str(error)
