from Logic.NotificationFactory import NotificationFactory
from Packets.Commands.Server.LogicChangeResourcesCommand import LogicChangeResourcesCommand
from Packets.Commands.Server.LogicSkinDataCommand import LogicSkinDataCommand


class LogicDeleteNotificationCommand:
    @staticmethod
    def decode(reader):
        for _ in range(4):
            reader.read_Vint()
        reader.notification_action = reader.read_Vint()

    @staticmethod
    def process(reader):
        next_type = NotificationFactory.next_pending_type(reader.player)
        if next_type == NotificationFactory.SKIN_REWARD_TYPE:
            try:
                result = NotificationFactory.claim_next_skin(reader.player)
            except (TypeError, ValueError) as error:
                return str(error)
            LogicSkinDataCommand(
                reader.client,
                reader.player,
                result["skin"],
                brawler=result.get("brawlerReward"),
            ).send()
            return result

        if next_type == NotificationFactory.SEASON_END_TYPE:
            try:
                result = NotificationFactory.claim_next_season(reader.player)
            except (TypeError, ValueError) as error:
                return str(error)
            for resource, amount in sorted(result["resources"].items()):
                if amount:
                    LogicChangeResourcesCommand(
                        reader.client, reader.player, resource, amount
                    ).send()
            return result
        return None
