from Logic.EventRotation import EventRotation
from Utils.Reader import BSMessageReader


class LogicNewEventCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.event_index = 0
        self.event_state = 0

    def decode(self):
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.event_index = self.read_Vint()
        self.event_state = self.read_Vint()

    def process(self):
        return EventRotation.apply_state(
            self.player, self.event_index, self.event_state
        )
