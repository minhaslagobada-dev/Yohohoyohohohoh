from Logic.Rewards import RewardError, RewardTransaction
from Logic.ShopCatalog import ShopCatalog
from Utils.Reader import BSMessageReader


class LogicPurchaseHeroLvlUpMaterialCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.gold = None

    def decode(self):
        self.read_Vint()
        self.read_Vint()
        self.readLogicLong()
        self.gold = self.read_Vint()

    def process(self):
        try:
            if self.gold not in range(len(ShopCatalog.GOLD_OFFERS)):
                raise RewardError("Pacote de gold inválido")
            offer = ShopCatalog.GOLD_OFFERS[self.gold]
            transaction = RewardTransaction(self.player)
            transaction.charge("gems", offer["Cost"])
            transaction.add_reward("Coins", offer["Amount"])
            transaction.commit()
            return {"gold": self.player.gold, "gems": self.player.gems}
        except (RewardError, TypeError, ValueError) as error:
            return str(error)
