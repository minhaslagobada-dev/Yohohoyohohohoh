import copy

from Files.CsvLogic.Characters import Characters
from Logic.Rewards import RewardError, RewardTransaction
from Utils.Reader import BSMessageReader


UPGRADE_GOLD_COSTS = [20, 35, 75, 140, 290, 480, 800, 1250]
MAX_POWER_LEVEL = len(UPGRADE_GOLD_COSTS)


class Upgrade_Brawler(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.BrawlerID = None

    def decode(self):
        self.read_Vint()
        self.read_Vint()
        self.readLogicLong()
        reference = self.readScId()
        if reference[0] != 16 or reference[1] not in Characters.get_brawlers_id():
            raise ValueError(f"Invalid brawler DataReference: {reference}")
        self.BrawlerID = reference[1]

    def process(self):
        try:
            brawler = int(self.BrawlerID)
            if brawler not in Characters.get_brawlers_id():
                raise RewardError("Brawler inválido")
            states = getattr(self.player, "BrawlersUnlockedState", {})
            if states.get(str(brawler), states.get(brawler, 0)) != 1:
                raise RewardError("O brawler precisa estar desbloqueado")
            levels = copy.deepcopy(getattr(self.player, "Brawler_level", {}))
            key = str(brawler)
            current = int(levels.get(key, levels.get(brawler, 0)) or 0)
            if current < 0 or current >= MAX_POWER_LEVEL:
                raise RewardError("Nível de poder inválido ou máximo")
            transaction = RewardTransaction(self.player)
            transaction.charge("gold", UPGRADE_GOLD_COSTS[current])
            levels[key] = current + 1
            transaction.set_value("Brawler_level", "brawlerPowerLevel", levels)
            transaction.commit()
            return {"brawler": brawler, "level": current + 1}
        except (RewardError, TypeError, ValueError) as error:
            return str(error)
