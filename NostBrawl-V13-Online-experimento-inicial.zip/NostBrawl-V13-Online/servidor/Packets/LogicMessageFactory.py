from Packets.Messages.Client.Login.ClientHelloMessage import ClientHelloMessage
from Packets.Messages.Client.Login.LoginMessage import LoginMessage
from Packets.Messages.Client.Login.CryptoErrorMessage import CryptoErrorMessage
from Packets.Messages.Client.KeepAliveMessage import KeepAliveMessage
from Packets.Messages.Client.Home.GoHomeFromOfflinePractiseMessage import GoHomeFromOfflinePractiseMessage
from Packets.Messages.Client.Home.AskProfileMessage import AskProfileMessage
from Packets.Messages.Client.AnalyticsEventMessage import AnalyticsEventMessage
from Packets.Messages.Client.Battle.AskForBattleEndMessage import AskForBattleEndMessage
from Packets.Messages.Client.SetNameMessage import SetNameMessage
from Packets.Messages.Client.Home.GetLeaderboardMessage import GetLeaderboardMessage
from Packets.Messages.Client.Home.AvatarNameCheckRequestMessage import AvatarNameCheckRequestMessage
from Packets.Messages.Client.Home.PlayerStatusMessage import PlayerStatusMessage
from Packets.Messages.Client.ClientCapabilities import ClientCapabilities
from Packets.Messages.Client.SetDeviceToken import SetDeviceToken
from Packets.Messages.Client.Billing.GoogleBillingRequestMessage import GoogleBillingRequestMessage
from Packets.LogicCommandManager import EndClientTurn
from Packets.Messages.Client.Battle.Cancel_Matchmaking import CancelMatchMaking
from Packets.Messages.Client.Battle.OnPlay import OnPlay
from Packets.Messages.Client.Battle.ClientInfoMessage import ClientInfoMessage
from Packets.Messages.Client.Battle.ClientInputMessage import ClientInputMessage
from Packets.Messages.Client.Alliance.Create_Message import Create_Message
from Packets.Messages.Client.Alliance.Ask_For_Alliance_Data_Message import AskForAllianceDataMessage
from Packets.Messages.Client.Alliance.Ask_Joinable_Alliances_Message import Ask_Joinable_Alliances_Message
from Packets.Messages.Client.Alliance.Join_Message import Join_Message
from Packets.Messages.Client.Alliance.Promote_Alliance_Member_Message import Promote_Alliance_Member_Message
from Packets.Messages.Client.Alliance.Leave_Message import Leave_Message
from Packets.Messages.Client.Alliance.Alliance_Chat_Message import AllianceChatMessage
from Packets.Messages.Client.Alliance.Edit_Settings_Message import Edit_Settings_Message
from Packets.Messages.Client.Alliance.Kick_Member_Message import Kick_Member_Message
from Packets.Messages.Client.Alliance.Search_Message import Search_Message
from Packets.Messages.Client.Alliance.Send_Club_Mail_Message import SendClubMail
from Packets.Messages.Client.Friend.AddFriend import AddFriend
from Packets.Messages.Client.Friend.AcceptFriendMessage import AcceptFriendMessage
from Packets.Messages.Client.Friend.RemoveFriendMessage import RemoveFriendMessage
from Packets.Messages.Client.Friend.AskForFriendListMessage import AskForFriendListMessage
from Packets.Messages.Client.Friend.AskForFriendSuggestionsMessage import AskForFriendSuggestionsMessage
from Packets.Messages.Client.Friend.AskForAddableFriendsMessage import AskForAddableFriendsMessage
from Packets.Messages.Client.Friend.FacebookConnect import FacebookConnect
from Packets.Messages.Client.Friend.UnlinkFacebookAcount import UnlinkFacebookAcount
from Packets.Messages.Client.SCID.SCIDBindAccountMessage import SCIDBindAccountMessage
from Packets.Messages.Client.Gameroom.SetInvitesBlockedMessage import SetInvitesBlockedMessage
from Packets.Messages.Client.Gameroom.TeamChangeMemberSettingsMessage import TeamChangeMemberSettingsMessage
from Packets.Messages.Client.Gameroom.TeamChatMessage import TeamChatMessage
from Packets.Messages.Client.Gameroom.TeamClearInviteMessage import TeamClearInviteMessage
from Packets.Messages.Client.Gameroom.TeamCreateMessage import TeamCreateMessage
from Packets.Messages.Client.Gameroom.TeamInvitationResponseMessage import TeamInvitationResponseMessage
from Packets.Messages.Client.Gameroom.TeamInviteMessage import TeamInviteMessage
from Packets.Messages.Client.Gameroom.TeamInviteResponseMessage import TeamInviteResponseMessage
from Packets.Messages.Client.Gameroom.TeamJoinMessage import TeamJoinMessage
from Packets.Messages.Client.Gameroom.TeamJoinOrCreateRoomMessage import TeamJoinOrCreateRoomMessage
from Packets.Messages.Client.Gameroom.TeamKickMessage import TeamKickMessage
from Packets.Messages.Client.Gameroom.TeamLeaveMessage import TeamLeaveMessage
from Packets.Messages.Client.Gameroom.TeamMemberStatusMessage import TeamMemberStatusMessage
from Packets.Messages.Client.Gameroom.TeamPostAdMessage import TeamPostAdMessage
from Packets.Messages.Client.Gameroom.TeamRequestJoinMessage import TeamRequestJoinMessage
from Packets.Messages.Client.Gameroom.TeamSetLocationMessage import TeamSetLocationMessage
from Packets.Messages.Client.Gameroom.TeamSetMemberReadyMessage import TeamSetMemberReadyMessage
from Packets.Messages.Client.Gameroom.TeamSetRankedLocationMessage import TeamSetRankedLocationMessage
from Packets.Messages.Client.Gameroom.TeamSpectateMessage import TeamSpectateMessage
from Packets.Messages.Client.Gameroom.TeamToggleMemberSideMessage import TeamToggleMemberSideMessage
from Packets.Messages.Client.Gameroom.TeamTogglePractiseMessage import TeamTogglePractiseMessage


packets = {
    10100: ClientHelloMessage,
    10101: LoginMessage,
    10107: ClientCapabilities,
    10108: KeepAliveMessage,
    10110: AnalyticsEventMessage,
    10113: SetDeviceToken,
    10151: GoogleBillingRequestMessage,
    10177: ClientInfoMessage,
    10212: SetNameMessage,
    10501: AcceptFriendMessage,
    10502: AddFriend,
    10503: AskForAddableFriendsMessage,
    10504: AskForFriendListMessage,
    10506: RemoveFriendMessage,
    10555: ClientInputMessage,
    10599: AskForFriendSuggestionsMessage,
    10636: SCIDBindAccountMessage,
    14102: EndClientTurn,
    14103: OnPlay,
    14106: CancelMatchMaking,
    14109: GoHomeFromOfflinePractiseMessage,
    14110: AskForBattleEndMessage,
    14113: AskProfileMessage,
    14201: FacebookConnect,
    14211: UnlinkFacebookAcount,
    14301: Create_Message,
    14302: AskForAllianceDataMessage,
    14303: Ask_Joinable_Alliances_Message,
    14305: Join_Message,
    14306: Promote_Alliance_Member_Message,
    14307: Kick_Member_Message,
    14308: Leave_Message,
    14315: AllianceChatMessage,
    14316: Edit_Settings_Message,
    14324: Search_Message,
    14330: SendClubMail,
    14350: TeamCreateMessage,
    14351: TeamJoinMessage,
    14352: TeamKickMessage,
    14353: TeamLeaveMessage,
    14354: TeamChangeMemberSettingsMessage,
    14355: TeamSetMemberReadyMessage,
    14356: TeamTogglePractiseMessage,
    14357: TeamToggleMemberSideMessage,
    14358: TeamSpectateMessage,
    14359: TeamChatMessage,
    14360: TeamPostAdMessage,
    14361: TeamMemberStatusMessage,
    14362: TeamSetRankedLocationMessage,
    14363: TeamSetLocationMessage,
    14365: TeamInviteMessage,
    14366: PlayerStatusMessage,
    14367: TeamClearInviteMessage,
    14368: TeamInviteResponseMessage,
    14370: TeamInviteMessage,
    14371: TeamJoinOrCreateRoomMessage,
    14403: GetLeaderboardMessage,
    14479: TeamInvitationResponseMessage,
    14600: AvatarNameCheckRequestMessage,
    14777: SetInvitesBlockedMessage,
    14881: TeamRequestJoinMessage,
}
