import copy
import datetime
import json
import os
import sqlite3 as sql
import threading
from contextlib import contextmanager
from pathlib import Path

from Logic.Player import Players
from Database.RelationalState import RelationalState
from Utils.Config import Config


class DataBase:
    """SQLite-backed account store plus Nost's existing SQLite club store."""

    MAX_POWER_POINTS = 1410
    TROPHY_ROAD_COMPLETE = 95
    PLAYER_EXPERIENCE = 99999
    EXPERIENCE_MIGRATION_VERSION = 1
    POWER_LEVEL_WIRE_VERSION = 2

    PLAYER_COLUMNS = (
        "id",
        "token",
        "name",
        "leagueReward",
        "lowID",
        "tgid",
        "clubID",
        "clubRole",
        "playerExp",
        "soloWins",
        "duoWins",
        "TvsTWins",
        "gems",
        "gold",
        "tokensdoubler",
        "battleTokens",
        "tickets",
        "brawlerID",
        "skinID",
        "trophies",
        "highest_trophies",
        "profileIcon",
        "namecolor",
        "brawlBoxes",
        "bigBoxes",
        "starpower",
        "DoNotDistrub",
        "brawlersSkins",
        "brawlersTrophies",
        "brawlersTrophiesForRank",
        "brawlersUpgradePoints",
        "brawlerPowerLevel",
        "brawlerStarPower",
        "UnlockedBrawlers",
        "UnlockedSkins",
        "Friends",
        "online",
        "Notifications",
        "progression",
        "roomID",
    )

    STATE_COLUMNS = frozenset({
        "brawlersSkins",
        "brawlersTrophies",
        "brawlersTrophiesForRank",
        "brawlersUpgradePoints",
        "brawlerPowerLevel",
        "brawlerStarPower",
        "UnlockedBrawlers",
        "UnlockedSkins",
        "Friends",
        "Notifications",
        "progression",
    })
    PLAYER_STORAGE_COLUMNS = PLAYER_COLUMNS[:27] + ("online", "roomID")
    RELATIONAL_SCHEMA_VERSION = 5

    PLAYER_TABLE_SCHEMA = """
        CREATE TABLE IF NOT EXISTS players (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            token TEXT NOT NULL UNIQUE,
            name TEXT NOT NULL DEFAULT 'Guest',
            leagueReward INTEGER NOT NULL DEFAULT 0,
            lowID INTEGER NOT NULL UNIQUE,
            tgid INTEGER NOT NULL DEFAULT 0,
            clubID INTEGER NOT NULL DEFAULT 0,
            clubRole INTEGER NOT NULL DEFAULT 0,
            playerExp INTEGER NOT NULL DEFAULT 99999,
            soloWins INTEGER NOT NULL DEFAULT 0,
            duoWins INTEGER NOT NULL DEFAULT 0,
            TvsTWins INTEGER NOT NULL DEFAULT 0,
            gems INTEGER NOT NULL DEFAULT 0,
            gold INTEGER NOT NULL DEFAULT 0,
            tokensdoubler INTEGER NOT NULL DEFAULT 0,
            battleTokens INTEGER NOT NULL DEFAULT 0,
            tickets INTEGER NOT NULL DEFAULT 0,
            brawlerID INTEGER NOT NULL DEFAULT 0,
            skinID INTEGER NOT NULL DEFAULT 0,
            trophies INTEGER NOT NULL DEFAULT 0,
            highest_trophies INTEGER NOT NULL DEFAULT 0,
            profileIcon INTEGER NOT NULL DEFAULT 0,
            namecolor INTEGER NOT NULL DEFAULT 0,
            brawlBoxes INTEGER NOT NULL DEFAULT 0,
            bigBoxes INTEGER NOT NULL DEFAULT 0,
            starpower INTEGER NOT NULL DEFAULT 0,
            DoNotDistrub INTEGER NOT NULL DEFAULT 0,
            online INTEGER NOT NULL DEFAULT 0,
            roomID INTEGER NOT NULL DEFAULT 0
        )
    """

    PLAYER_STATE_TABLE = """
        CREATE TABLE IF NOT EXISTS player_state_entries (
            player_id INTEGER NOT NULL,
            domain TEXT NOT NULL,
            path TEXT NOT NULL,
            parent_path TEXT,
            segment TEXT,
            position INTEGER NOT NULL DEFAULT 0,
            node_type TEXT NOT NULL,
            value_integer INTEGER,
            value_real REAL,
            value_text TEXT,
            PRIMARY KEY (player_id, domain, path),
            FOREIGN KEY (player_id) REFERENCES players(lowID) ON DELETE CASCADE
        )
    """
    PLAYER_STATE_INDEX = """
        CREATE INDEX IF NOT EXISTS player_state_domain
            ON player_state_entries(player_id, domain)
    """
    PLAYER_STATE_SCHEMA = PLAYER_STATE_TABLE + ";" + PLAYER_STATE_INDEX
    PLAYER_SCHEMA = PLAYER_TABLE_SCHEMA + ";" + PLAYER_STATE_SCHEMA

    BATTLE_SCHEMA = """
        CREATE TABLE IF NOT EXISTS battle_reward_ledger (
            player_id INTEGER NOT NULL,
            battle_id TEXT NOT NULL,
            payload_hash TEXT NOT NULL DEFAULT '',
            game_mode INTEGER NOT NULL DEFAULT -1,
            rewards_json TEXT,
            is_current INTEGER NOT NULL DEFAULT 0,
            home_seen INTEGER NOT NULL DEFAULT 0,
            created_at INTEGER NOT NULL,
            updated_at INTEGER NOT NULL,
            completed_at INTEGER,
            PRIMARY KEY (player_id, battle_id),
            FOREIGN KEY (player_id) REFERENCES players(lowID) ON DELETE CASCADE
        );
        CREATE UNIQUE INDEX IF NOT EXISTS battle_reward_current
            ON battle_reward_ledger(player_id)
            WHERE is_current = 1;
        CREATE INDEX IF NOT EXISTS battle_reward_payload
            ON battle_reward_ledger(player_id, payload_hash);
    """

    DAILY_REWARD_SCHEMA = """
        CREATE TABLE IF NOT EXISTS daily_token_limits (
            player_id INTEGER NOT NULL,
            day TEXT NOT NULL,
            used INTEGER NOT NULL DEFAULT 0 CHECK (used BETWEEN 0 AND 700),
            updated_at INTEGER NOT NULL,
            PRIMARY KEY (player_id, day),
            FOREIGN KEY (player_id) REFERENCES players(lowID) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS daily_star_rewards (
            player_id INTEGER NOT NULL,
            day TEXT NOT NULL,
            map_id INTEGER NOT NULL,
            amount INTEGER NOT NULL DEFAULT 1 CHECK (amount = 1),
            battle_id TEXT NOT NULL,
            created_at INTEGER NOT NULL,
            PRIMARY KEY (player_id, day, map_id),
            FOREIGN KEY (player_id) REFERENCES players(lowID) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS daily_star_battle
            ON daily_star_rewards(player_id, battle_id);
    """

    CLUB_SCHEMA = """
        CREATE TABLE IF NOT EXISTS clubs (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT NOT NULL DEFAULT '',
            region TEXT NOT NULL DEFAULT 'RU',
            badge_id INTEGER NOT NULL DEFAULT 0,
            type INTEGER NOT NULL DEFAULT 1,
            required_trophies INTEGER NOT NULL DEFAULT 0,
            family_friendly INTEGER NOT NULL DEFAULT 0,
            created_at INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS club_members (
            club_id INTEGER NOT NULL,
            player_id INTEGER NOT NULL,
            role INTEGER NOT NULL DEFAULT 1,
            joined_at INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY (club_id, player_id),
            FOREIGN KEY (club_id) REFERENCES clubs(id) ON DELETE CASCADE,
            FOREIGN KEY (player_id) REFERENCES players(lowID) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS club_messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            club_id INTEGER NOT NULL,
            event INTEGER NOT NULL,
            tick INTEGER NOT NULL DEFAULT 0,
            player_id INTEGER NOT NULL DEFAULT 0,
            player_name TEXT NOT NULL DEFAULT '',
            player_role INTEGER NOT NULL DEFAULT 0,
            message TEXT NOT NULL DEFAULT '',
            created_at INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY (club_id) REFERENCES clubs(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS club_notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            club_id INTEGER NOT NULL,
            text TEXT NOT NULL,
            sender_id INTEGER NOT NULL,
            created_at INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY (club_id) REFERENCES clubs(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS club_members_player
            ON club_members(player_id);
        CREATE INDEX IF NOT EXISTS club_messages_club
            ON club_messages(club_id, id);
        CREATE INDEX IF NOT EXISTS club_notifications_club
            ON club_notifications(club_id, id);
    """

    SOCIAL_SCHEMA = """
        CREATE TABLE IF NOT EXISTS friend_relations (
            owner_id INTEGER NOT NULL,
            friend_id INTEGER NOT NULL,
            state INTEGER NOT NULL,
            origin INTEGER NOT NULL DEFAULT 0,
            created_at INTEGER NOT NULL DEFAULT 0,
            updated_at INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY (owner_id, friend_id),
            FOREIGN KEY (owner_id) REFERENCES players(lowID) ON DELETE CASCADE,
            FOREIGN KEY (friend_id) REFERENCES players(lowID) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS friend_relations_friend
            ON friend_relations(friend_id, owner_id);
    """

    DATABASE_PATH = "Database/players.sqlite"
    LEGACY_DATABASE_PATH = "Database/players.db"
    _schema_lock = threading.Lock()
    _migration_lock = threading.Lock()
    _initialized_paths = set()

    def _database_path():
        database = Config.GetValue().get("Database", {})
        return str(database.get("Path", DataBase.DATABASE_PATH))

    @classmethod
    def _migrate_legacy_database(cls, database_path):
        canonical = Path(cls.DATABASE_PATH).expanduser().resolve()
        if database_path != canonical:
            return
        legacy = Path(cls.LEGACY_DATABASE_PATH).expanduser().resolve()
        if legacy == canonical or canonical.exists() or not legacy.is_file():
            return
        with cls._migration_lock:
            if canonical.exists() or not legacy.is_file():
                return
            temporary = canonical.with_name(
                f".{canonical.name}.migration-{os.getpid()}-{threading.get_ident()}"
            )
            try:
                if temporary.exists():
                    temporary.unlink()
                source = sql.connect(str(legacy), timeout=10)
                try:
                    source.execute("PRAGMA busy_timeout = 10000")
                    destination = sql.connect(str(temporary), timeout=10)
                    try:
                        source.backup(destination)
                        integrity = destination.execute(
                            "PRAGMA integrity_check"
                        ).fetchone()
                        if not integrity or integrity[0] != "ok":
                            raise RuntimeError("Falha de integridade na migração SQLite")
                    finally:
                        destination.close()
                finally:
                    source.close()
                os.replace(temporary, canonical)
            finally:
                if temporary.exists():
                    temporary.unlink()

    def _state_default(column):
        if column == "UnlockedSkins":
            return {"Skins": []}
        return {}

    def _decode_legacy_json(value, column):
        default = DataBase._state_default(column)
        if value is None:
            return copy.deepcopy(default)
        if isinstance(value, (dict, list)):
            return value
        try:
            decoded = json.loads(value)
        except (TypeError, ValueError):
            return copy.deepcopy(default)
        return copy.deepcopy(default) if decoded is None else decoded

    def _state_value(value, column):
        if value is None:
            return copy.deepcopy(DataBase._state_default(column))
        if isinstance(value, str):
            try:
                return json.loads(value)
            except ValueError:
                pass
        return value

    def _read_state(connection, low_id, column):
        if column not in DataBase.STATE_COLUMNS:
            raise ValueError(f"Unsupported relational state: {column}")
        return RelationalState.read(
            connection, low_id, column, DataBase._state_default(column)
        )

    def _write_state(connection, low_id, column, value):
        if column not in DataBase.STATE_COLUMNS:
            raise ValueError(f"Unsupported relational state: {column}")
        RelationalState.write(
            connection,
            low_id,
            column,
            DataBase._state_value(value, column),
        )

    def _select_player(connection, where_column, where_value):
        if where_column not in {"token", "lowID"}:
            raise ValueError(f"Unsupported lookup column: {where_column}")
        columns = DataBase.PLAYER_STORAGE_COLUMNS
        quoted = ", ".join(f'"{column}"' for column in columns)
        raw = connection.execute(
            f'SELECT {quoted} FROM players WHERE "{where_column}" = ?',
            (where_value,),
        ).fetchone()
        if raw is None:
            return None
        record = dict(zip(columns, raw))
        for column in DataBase.STATE_COLUMNS:
            record[column] = DataBase._read_state(
                connection, record["lowID"], column
            )
        return tuple(record[column] for column in DataBase.PLAYER_COLUMNS)

    @classmethod
    def _migrate_json_columns(cls, connection, existing_columns):
        connection.execute("PRAGMA foreign_keys = OFF")
        try:
            connection.execute("BEGIN IMMEDIATE")
            new_table = cls.PLAYER_TABLE_SCHEMA.replace(
                "CREATE TABLE IF NOT EXISTS players (",
                "CREATE TABLE players_new (",
                1,
            )
            connection.execute(new_table)
            available = [
                column for column in cls.PLAYER_STORAGE_COLUMNS
                if column in existing_columns
            ]
            quoted = ", ".join(f'"{column}"' for column in available)
            connection.execute(
                f"INSERT INTO players_new ({quoted}) SELECT {quoted} FROM players"
            )
            connection.execute("""
                CREATE TEMP TABLE player_state_migration (
                    player_id INTEGER NOT NULL,
                    domain TEXT NOT NULL,
                    path TEXT NOT NULL,
                    parent_path TEXT,
                    segment TEXT,
                    position INTEGER NOT NULL,
                    node_type TEXT NOT NULL,
                    value_integer INTEGER,
                    value_real REAL,
                    value_text TEXT,
                    PRIMARY KEY (player_id, domain, path)
                )
            """)
            rows = connection.execute("SELECT * FROM players").fetchall()
            temporary_insert = RelationalState.INSERT.replace(
                "player_state_entries", "temp.player_state_migration", 1
            )
            for row in rows:
                record = dict(zip(existing_columns, row))
                low_id = int(record["lowID"])
                for column in cls.STATE_COLUMNS:
                    if column not in record:
                        continue
                    value = cls._decode_legacy_json(record[column], column)
                    connection.executemany(
                        temporary_insert,
                        RelationalState.rows(low_id, column, value),
                    )
            connection.execute("DROP TABLE players")
            connection.execute("ALTER TABLE players_new RENAME TO players")
            connection.execute(cls.PLAYER_STATE_TABLE)
            connection.execute(cls.PLAYER_STATE_INDEX)
            state_columns = (
                "player_id, domain, path, parent_path, segment, position, "
                "node_type, value_integer, value_real, value_text"
            )
            connection.execute(
                f"INSERT INTO player_state_entries ({state_columns}) "
                f"SELECT {state_columns} FROM temp.player_state_migration"
            )
            connection.execute("DROP TABLE temp.player_state_migration")
            violations = connection.execute("PRAGMA foreign_key_check").fetchall()
            if violations:
                raise RuntimeError("Falha de chave estrangeira na migração relacional")
            integrity = connection.execute("PRAGMA integrity_check").fetchone()
            if not integrity or integrity[0] != "ok":
                raise RuntimeError("Falha de integridade na migração relacional")
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.execute("PRAGMA foreign_keys = ON")

    @classmethod
    def _initialize_schema(cls, connection, database_path):
        if database_path != ":memory:":
            connection.execute("PRAGMA journal_mode = WAL")
        connection.execute("PRAGMA synchronous = NORMAL")
        column_rows = connection.execute("PRAGMA table_info(players)").fetchall()
        columns = [row[1] for row in column_rows]
        unexpected_columns = set(columns) - set(cls.PLAYER_STORAGE_COLUMNS)
        expected_columns = set(cls.PLAYER_STORAGE_COLUMNS)
        if columns and (
            cls.STATE_COLUMNS.intersection(columns)
            or unexpected_columns
            or set(columns) != expected_columns
        ):
            cls._migrate_json_columns(connection, columns)
        else:
            connection.executescript(cls.PLAYER_SCHEMA)
        connection.executescript(cls.CLUB_SCHEMA)
        connection.executescript(cls.SOCIAL_SCHEMA)
        friend_columns = {
            row[1] for row in connection.execute("PRAGMA table_info(friend_relations)")
        }
        if "origin" not in friend_columns:
            connection.execute(
                "ALTER TABLE friend_relations ADD COLUMN origin INTEGER NOT NULL DEFAULT 0"
            )
        connection.executescript(cls.BATTLE_SCHEMA)
        connection.executescript(cls.DAILY_REWARD_SCHEMA)
        schema_version = connection.execute("PRAGMA user_version").fetchone()[0]
        if schema_version < cls.EXPERIENCE_MIGRATION_VERSION:
            connection.execute(
                "UPDATE players SET playerExp = ? WHERE playerExp <> ?",
                (cls.PLAYER_EXPERIENCE, cls.PLAYER_EXPERIENCE),
            )
        if schema_version < cls.RELATIONAL_SCHEMA_VERSION:
            connection.execute(
                f"PRAGMA user_version = {cls.RELATIONAL_SCHEMA_VERSION}"
            )
        connection.commit()

    def _connect():
        configured_path = DataBase._database_path()
        if configured_path == ":memory:":
            database_path = configured_path
        else:
            path = Path(configured_path).expanduser().resolve()
            path.parent.mkdir(parents=True, exist_ok=True)
            DataBase._migrate_legacy_database(path)
            database_path = str(path)

        connection = sql.connect(database_path, timeout=10)
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA busy_timeout = 10000")

        if database_path not in DataBase._initialized_paths:
            with DataBase._schema_lock:
                if database_path not in DataBase._initialized_paths:
                    DataBase._initialize_schema(connection, database_path)
                    DataBase._initialized_paths.add(database_path)
        return connection

    @contextmanager
    def _connection():
        connection = DataBase._connect()
        try:
            yield connection
        except Exception:
            connection.rollback()
            raise
        else:
            connection.commit()
        finally:
            connection.close()

    def _number(value, default=0):
        try:
            return int(value)
        except (TypeError, ValueError):
            return default

    def _apply_row(player, row):
        player.id = row[0]
        player.token = row[1] or ""
        player.name = row[2] or "Guest"

        numeric_fields = (
            ("trophy_road", 3),
            ("low_id", 4),
            ("tgid", 5),
            ("club_low_id", 6),
            ("club_role", 7),
            ("player_experience", 8),
            ("solo_wins", 9),
            ("duo_wins", 10),
            ("ThreeVSThree_wins", 11),
            ("gems", 12),
            ("gold", 13),
            ("tokensdoubler", 14),
            ("battle_tokens", 15),
            ("tickets", 16),
            ("brawler_id", 17),
            ("skin_id", 18),
            ("trophies", 19),
            ("highest_trophies", 20),
            ("profile_icon", 21),
            ("name_color", 22),
            ("brawl_boxes", 23),
            ("big_boxes", 24),
            ("starpower", 25),
            ("do_not_distrub", 26),
            ("online", 36),
            ("room_id", 39),
        )
        for attribute, index in numeric_fields:
            setattr(player, attribute, DataBase._number(row[index]))

        state_fields = (
            ("brawlers_skins", 27, "brawlersSkins"),
            ("brawlers_trophies", 28, "brawlersTrophies"),
            ("brawlers_trophies_in_rank", 29, "brawlersTrophiesForRank"),
            ("brawlers_upgradium", 30, "brawlersUpgradePoints"),
            ("Brawler_level", 31, "brawlerPowerLevel"),
            ("Brawler_starPower", 32, "brawlerStarPower"),
            ("BrawlersUnlockedState", 33, "UnlockedBrawlers"),
            ("UnlockedSkins", 34, "UnlockedSkins"),
            ("Friends", 35, "Friends"),
            ("Notifications", 37, "Notifications"),
            ("progression", 38, "progression"),
        )
        for attribute, index, column in state_fields:
            setattr(player, attribute, DataBase._decode_legacy_json(row[index], column))

        progression = getattr(player, "progression", {})
        if not isinstance(progression, dict):
            progression = {}
            player.progression = progression
        player.tokensAnim = DataBase._number(progression.get("keyReward", 0))
        player.trophiesAnim = DataBase._number(
            progression.get("trophyReward", 0)
        )
        player.bigTokensAnim = DataBase._number(
            progression.get("starKeyReward", 0)
        )
        player.star_points = DataBase._number(
            progression.get("starPoints", getattr(player, "star_points", 0))
        )
        player.IsFacebookLinked = int(bool(progression.get("isFBLinked", False)))
        player.FacebookID = str(progression.get("facebookID", "") or "")
        player.FacebookToken = str(progression.get("facebookToken", "") or "")

                                                                            
                                                                        
                                                        
        power_level_version = DataBase._number(
            progression.get("powerLevelWireVersion", 0)
        )
        migrate_power_levels = (
            power_level_version < DataBase.POWER_LEVEL_WIRE_VERSION
        )
        stored_levels = getattr(player, "Brawler_level", {})
        normalized_levels = copy.deepcopy(Players.Brawler_level)
        if isinstance(stored_levels, dict):
            for key, value in stored_levels.items():
                level = DataBase._number(value, 0)
                if migrate_power_levels:
                    level -= 1
                normalized_levels[str(key)] = max(0, level)
        player.Brawler_level = normalized_levels
        if migrate_power_levels:
            progression["powerLevelWireVersion"] = (
                DataBase.POWER_LEVEL_WIRE_VERSION
            )

        stored_points = getattr(player, "brawlers_upgradium", {})
        if not isinstance(stored_points, dict):
            stored_points = copy.deepcopy(Players.brawlers_upgradium)
        player.brawlers_upgradium = {
            str(key): min(
                DataBase.MAX_POWER_POINTS,
                max(0, DataBase._number(value)),
            )
            for key, value in stored_points.items()
        }
        player.trophy_road = min(
            DataBase.TROPHY_ROAD_COMPLETE,
            max(1, player.trophy_road),
        )
        return migrate_power_levels

    def _load_account_from_connection(connection, player):
        row = DataBase._select_player(connection, "token", player.token)
        if row is None:
            return False

        stored_points = copy.deepcopy(row[30])
        stored_position = DataBase._number(row[3])
        migrate_power_levels = DataBase._apply_row(player, row)
        if migrate_power_levels:
            DataBase._write_state(
                connection,
                player.low_id,
                "brawlerPowerLevel",
                player.Brawler_level,
            )
            DataBase._write_state(
                connection,
                player.low_id,
                "progression",
                player.progression,
            )
        if stored_points != player.brawlers_upgradium:
            DataBase._write_state(
                connection,
                player.low_id,
                "brawlersUpgradePoints",
                player.brawlers_upgradium,
            )
        if stored_position != player.trophy_road:
            connection.execute(
                "UPDATE players SET leagueReward = ? WHERE token = ?",
                (player.trophy_road, player.token),
            )
        if player.trophies >= player.highest_trophies:
            player.highest_trophies = player.trophies
            connection.execute(
                "UPDATE players SET highest_trophies = ? WHERE token = ?",
                (player.highest_trophies, player.token),
            )
        return True

    def loadAccount(self):
        with DataBase._connection() as connection:
            return DataBase._load_account_from_connection(
                connection, self.player
            )

    def createAccount(self):
        player = self.player
        player.BrawlersUnlockedState = Players.CreateNewBrawlersList()
        progression = getattr(player, "progression", {})
        if not isinstance(progression, dict):
            progression = {}
        progression["powerLevelWireVersion"] = DataBase.POWER_LEVEL_WIRE_VERSION
        player.progression = progression
        player.highest_trophies = max(
            getattr(player, "trophies", 0),
            getattr(player, "highest_trophies", 0),
        )

        data = {
            "token": str(player.token),
            "name": str(getattr(player, "name", "Guest")),
            "leagueReward": DataBase._number(getattr(player, "trophy_road", 1)),
            "lowID": DataBase._number(player.low_id),
            "tgid": DataBase._number(getattr(player, "tgid", 0)),
            "clubID": DataBase._number(getattr(player, "club_low_id", 0)),
            "clubRole": DataBase._number(getattr(player, "club_role", 0)),
            "playerExp": DataBase._number(
                getattr(player, "player_experience", DataBase.PLAYER_EXPERIENCE)
            ),
            "soloWins": DataBase._number(getattr(player, "solo_wins", 0)),
            "duoWins": DataBase._number(getattr(player, "duo_wins", 0)),
            "TvsTWins": DataBase._number(getattr(player, "ThreeVSThree_wins", 0)),
            "gems": DataBase._number(getattr(player, "gems", 0)),
            "gold": DataBase._number(getattr(player, "gold", 0)),
            "tokensdoubler": DataBase._number(getattr(player, "tokensdoubler", 0)),
            "battleTokens": DataBase._number(getattr(player, "battle_tokens", 0)),
            "tickets": DataBase._number(getattr(player, "tickets", 0)),
            "brawlerID": DataBase._number(getattr(player, "brawler_id", 0)),
            "skinID": DataBase._number(getattr(player, "skin_id", 0)),
            "trophies": DataBase._number(getattr(player, "trophies", 0)),
            "highest_trophies": DataBase._number(
                max(
                    getattr(player, "trophies", 0),
                    getattr(player, "highest_trophies", 0),
                )
            ),
            "profileIcon": DataBase._number(getattr(player, "profile_icon", 0)),
            "namecolor": DataBase._number(getattr(player, "name_color", 0)),
            "brawlBoxes": DataBase._number(getattr(player, "brawl_boxes", 0)),
            "bigBoxes": DataBase._number(getattr(player, "big_boxes", 0)),
            "starpower": DataBase._number(getattr(player, "starpower", 0)),
            "DoNotDistrub": DataBase._number(getattr(player, "do_not_distrub", 0)),
            "brawlersSkins": getattr(player, "brawlers_skins", {}),
            "brawlersTrophies": getattr(player, "brawlers_trophies", {}),
            "brawlersTrophiesForRank": getattr(player, "brawlers_trophies_in_rank", {}),
            "brawlersUpgradePoints": getattr(player, "brawlers_upgradium", {}),
            "brawlerPowerLevel": getattr(player, "Brawler_level", {}),
            "brawlerStarPower": getattr(player, "Brawler_starPower", {}),
            "UnlockedBrawlers": player.BrawlersUnlockedState,
            "UnlockedSkins": getattr(player, "UnlockedSkins", {"Skins": []}),
            "Friends": getattr(player, "Friends", {}),
            "online": DataBase._number(getattr(player, "online", 0)),
            "Notifications": getattr(player, "Notifications", {}),
            "progression": getattr(player, "progression", {}),
            "roomID": DataBase._number(getattr(player, "room_id", 0)),
        }

        columns = DataBase.PLAYER_STORAGE_COLUMNS[1:]
        quoted_columns = ", ".join(f'"{column}"' for column in columns)
        placeholders = ", ".join("?" for _ in columns)
        values = [data[column] for column in columns]

        with DataBase._connection() as connection:
            connection.execute(
                f"INSERT INTO players ({quoted_columns}) VALUES ({placeholders})",
                values,
            )
            for column in DataBase.PLAYER_COLUMNS:
                if column in DataBase.STATE_COLUMNS:
                    DataBase._write_state(
                        connection, player.low_id, column, data[column]
                    )
        return player.low_id

    def _update_value(where_column, where_value, value_name, new_value):
        return DataBase._update_values(
            where_column, where_value, {value_name: new_value}
        )

    def _write_values(connection, low_id, values):
        if not values:
            return True
        for column in values:
            if column not in DataBase.PLAYER_COLUMNS or column in {"id", "lowID"}:
                raise ValueError(f"Unsupported player column: {column}")
        account = connection.execute(
            "SELECT lowID FROM players WHERE lowID = ?", (low_id,)
        ).fetchone()
        if account is None:
            return False
        scalar = {
            column: value for column, value in values.items()
            if column not in DataBase.STATE_COLUMNS
        }
        if scalar:
            assignments = ", ".join(f'"{column}" = ?' for column in scalar)
            parameters = list(scalar.values())
            parameters.append(low_id)
            cursor = connection.execute(
                f"UPDATE players SET {assignments} WHERE lowID = ?",
                parameters,
            )
            if cursor.rowcount != 1:
                return False
        for column, value in values.items():
            if column in DataBase.STATE_COLUMNS:
                DataBase._write_state(connection, low_id, column, value)
        return True

    def _update_values(where_column, where_value, values):
        if where_column not in {"token", "lowID"}:
            raise ValueError(f"Unsupported lookup column: {where_column}")
        for column in values:
            if column not in DataBase.PLAYER_COLUMNS or column in {"id", "lowID"}:
                raise ValueError(f"Unsupported player column: {column}")
        if not values:
            return True
        with DataBase._connection() as connection:
            if where_column == "lowID":
                low_id = int(where_value)
            else:
                account = connection.execute(
                    "SELECT lowID FROM players WHERE token = ?",
                    (where_value,),
                ).fetchone()
                if account is None:
                    return False
                low_id = int(account[0])
            return DataBase._write_values(connection, low_id, values)

    @classmethod
    def consume_home_reward_animations(cls, player, expected):
        keys = ("keyReward", "trophyReward", "starKeyReward")
        try:
            expected = tuple(int(value) for value in expected)
        except (TypeError, ValueError):
            raise ValueError("Recompensa de apresentação inválida") from None
        if len(expected) != 3:
            raise ValueError("Recompensa de apresentação inválida")
        if not any(expected):
            return expected
        low_id = int(getattr(player, "low_id", 0) or 0)
        token = getattr(player, "token", "")
        if low_id <= 0 or not isinstance(token, str) or not token or token == "None":
            return None
        with cls._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            account = connection.execute(
                "SELECT 1 FROM players WHERE lowID = ?", (low_id,)
            ).fetchone()
            if account is None:
                raise ValueError("Conta não encontrada ao concluir a apresentação")
            progression = cls._read_state(connection, low_id, "progression")
            if not isinstance(progression, dict):
                raise ValueError("Progresso inválido ao concluir a apresentação")
            current = tuple(
                cls._number(progression.get(key, 0)) for key in keys
            )
            if current != expected:
                return current
            updated = copy.deepcopy(progression)
            for key in keys:
                updated[key] = 0
            cls._write_state(connection, low_id, "progression", updated)
        return (0, 0, 0)

    def replaceValue(self, value_name, new_value):
        aliases = {
            "availableTokens": "battleTokens",
            "tokens": "battleTokens",
        }
        value_name = aliases.get(value_name, value_name)
        progression_fields = {
            "starpoints": "starPoints",
            "starPoints": "starPoints",
            "tokensAnim": "keyReward",
            "trophiesAnim": "trophyReward",
            "bigTokensAnim": "starKeyReward",
        }
        if value_name in progression_fields:
            progression = copy.deepcopy(getattr(self.player, "progression", {}))
            if not isinstance(progression, dict):
                progression = {}
            progression[progression_fields[value_name]] = DataBase._number(new_value)
            updated = DataBase._update_value(
                "token", self.player.token, "progression", progression
            )
            if updated:
                self.player.progression = progression
                attribute = progression_fields[value_name]
                if attribute == "starPoints":
                    self.player.star_points = DataBase._number(new_value)
                else:
                    animation_names = {
                        "keyReward": "tokensAnim",
                        "trophyReward": "trophiesAnim",
                        "starKeyReward": "bigTokensAnim",
                    }
                    setattr(
                        self.player, animation_names[attribute],
                        DataBase._number(new_value),
                    )
            return updated
        return DataBase._update_value(
            "token", self.player.token, value_name, new_value
        )

    def replaceValues(self, values):
        return DataBase._update_values("token", self.player.token, values)

    def replaceOtherValue(self, low_id, value_name, new_value):
        return DataBase._update_value("lowID", low_id, value_name, new_value)

    def DeleteTrash(self):
        with DataBase._connection() as connection:
            count = connection.execute(
                "SELECT COUNT(*) FROM players WHERE name = ?", ("Guest",)
            ).fetchone()[0]
            if count >= 15:
                connection.execute("DELETE FROM players WHERE name = ?", ("Guest",))

    def fixAccount(self):
        for column, value in (
            ("trophies", 0),
            ("highest_trophies", 0),
            ("clubID", 0),
            ("gold", 100),
            ("gems", 0),
            ("tickets", 5),
            ("bigBoxes", 0),
            ("brawlBoxes", 0),
            ("tokensdoubler", 0),
            ("tgid", 0),
            ("playerExp", 0),
        ):
            DataBase.replaceValue(self, column, value)

        self.player.brawlers_trophies[str(self.player.brawler_id)] = 0
        self.player.brawlers_trophies_in_rank[str(self.player.brawler_id)] = 0
        DataBase.replaceValue(
            self, "brawlersTrophies", self.player.brawlers_trophies
        )
        DataBase.replaceValue(
            self,
            "brawlersTrophiesForRank",
            self.player.brawlers_trophies_in_rank,
        )

    def checkID(self, new_id):
        with DataBase._connection() as connection:
            row = connection.execute(
                "SELECT 1 FROM players WHERE lowID = ?", (new_id,)
            ).fetchone()
            return 0 if row else 1

    def sendNotifData(self, lowID, ID, text, type):
        row = DataBase.loadMembersById(self, lowID)
        if row is None:
            return False
        notifications = copy.deepcopy(row[37])
        notifications[str(len(notifications))] = {
            "ID": ID,
            "Index": 3,
            "Read": False,
            "Time": datetime.datetime.timestamp(datetime.datetime.now()),
            "Text": text,
        }
        if ID == 81:
            notifications[str(len(notifications) - 1)]["Type"] = type
        return DataBase.replaceOtherValue(self, lowID, "Notifications", notifications)

    def loadOldAccount(self, nost_id):
        with DataBase._connection() as connection:
            cursor = connection.execute(
                "UPDATE players SET token = ? WHERE tgid = ?",
                (self.player.token, nost_id),
            )
            return cursor.rowcount > 0

    def resetOnlineStatus():
        with DataBase._connection() as connection:
            connection.execute("UPDATE players SET online = 0")

    def getLeaders(self):
        with DataBase._connection() as connection:
            return connection.execute(
                "SELECT lowID, name, trophies, profileIcon, namecolor, clubID, playerExp "
                "FROM players ORDER BY trophies DESC, lowID ASC LIMIT 100"
            ).fetchall()

    def loadById(self, ID):
        with DataBase._connection() as connection:
            row = DataBase._select_player(connection, "lowID", ID)
            return [] if row is None else [row]

    def loadMembersById(self, ID):
        with DataBase._connection() as connection:
            return DataBase._select_player(connection, "lowID", ID)
