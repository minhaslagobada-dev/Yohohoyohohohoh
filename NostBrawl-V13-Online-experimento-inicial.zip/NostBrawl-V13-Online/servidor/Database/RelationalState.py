import copy


class RelationalState:
    INSERT = """
        INSERT INTO player_state_entries (
            player_id, domain, path, parent_path, segment, position,
            node_type, value_integer, value_real, value_text
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """

    @staticmethod
    def _child_path(parent, kind, segment):
        text = str(segment)
        part = f"{kind}{len(text)}:{text}"
        return f"{parent}/{part}"

    @classmethod
    def rows(cls, player_id, domain, value):
        result = []

        def append(current, path, parent, segment, position):
            integer = None
            real = None
            text = None
            if current is None:
                node_type = "null"
            elif isinstance(current, bool):
                node_type = "boolean"
                integer = int(current)
            elif isinstance(current, int):
                node_type = "integer"
                if -(1 << 63) <= current < (1 << 63):
                    integer = current
                else:
                    text = str(current)
            elif isinstance(current, float):
                node_type = "real"
                real = current
            elif isinstance(current, str):
                node_type = "text"
                text = current
            elif isinstance(current, dict):
                node_type = "object"
            elif isinstance(current, (list, tuple)):
                node_type = "array"
            else:
                raise TypeError(f"Unsupported relational state value: {type(current).__name__}")
            result.append((
                int(player_id), str(domain), path, parent, segment,
                int(position), node_type, integer, real, text,
            ))
            if node_type == "object":
                for child_position, (key, child) in enumerate(current.items()):
                    child_segment = str(key)
                    child_path = cls._child_path(path, "k", child_segment)
                    append(child, child_path, path, child_segment, child_position)
            elif node_type == "array":
                for child_position, child in enumerate(current):
                    child_segment = str(child_position)
                    child_path = cls._child_path(path, "i", child_segment)
                    append(child, child_path, path, child_segment, child_position)

        append(value, "", None, None, 0)
        return result

    @classmethod
    def write(cls, connection, player_id, domain, value):
        connection.execute(
            "DELETE FROM player_state_entries WHERE player_id = ? AND domain = ?",
            (int(player_id), str(domain)),
        )
        connection.executemany(cls.INSERT, cls.rows(player_id, domain, value))

    @staticmethod
    def read(connection, player_id, domain, default):
        rows = connection.execute(
            "SELECT path, parent_path, segment, position, node_type, "
            "value_integer, value_real, value_text FROM player_state_entries "
            "WHERE player_id = ? AND domain = ?",
            (int(player_id), str(domain)),
        ).fetchall()
        if not rows:
            return copy.deepcopy(default)
        nodes = {row[0]: row for row in rows}
        if "" not in nodes:
            raise RuntimeError(f"Estado relacional sem raiz: {domain}")
        children = {}
        for row in rows:
            parent = row[1]
            if parent is not None:
                children.setdefault(parent, []).append(row)
        for group in children.values():
            group.sort(key=lambda row: (int(row[3]), row[0]))

        def build(path):
            row = nodes[path]
            node_type = row[4]
            if node_type == "null":
                return None
            if node_type == "boolean":
                return bool(row[5])
            if node_type == "integer":
                return int(row[5]) if row[5] is not None else int(row[7])
            if node_type == "real":
                return float(row[6])
            if node_type == "text":
                return str(row[7] or "")
            if node_type == "object":
                return {
                    str(child[2]): build(child[0])
                    for child in children.get(path, [])
                }
            if node_type == "array":
                return [build(child[0]) for child in children.get(path, [])]
            raise RuntimeError(f"Tipo relacional desconhecido: {node_type}")

        return build("")
